# address_faker.py
"""
Generates a unique, Solana-style fake contract address:
  - 44 characters
  - Base58 alphabet
  - Randomly generated from 32 bytes of entropy
Usage:
    from address_faker import generate_address
    addr = generate_address()
    # e.g. "4Ykq7e8W3R1vZ9h2qL6TjM5BnR8pC0Xf3D4sH2vQ6RtS"
"""

import os
import base58

def generate_address() -> str:
    """
    Returns a new 44-character Base58 string suitable
    for simulating a Solana contract address.
    """
    entropy = os.urandom(32)  # 32 bytes → 44 Base58 chars
    addr = base58.b58encode(entropy).decode("ascii")
    # Ensure fixed length (pad or trim if necessary)
    return addr.rjust(44, "1")[:44]