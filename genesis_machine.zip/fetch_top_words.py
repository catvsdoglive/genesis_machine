# fetch_top_words.py

import json
import requests
from memelogging import logger
from pathlib import Path
from config import USE_LIVE_WORDS, TOP_WORDS_ENDPOINT, TOP_WORDS_TIMEOUT

# Fallback file for dev mode
FALLBACK_FILE = Path(__file__).parent / "words.json"

def fetch_top_words() -> list[str]:
    """
    Return a flat list of trending words.
    Supports both payload shapes:
      1) {"words": [{"word": "dog", "count": 987}, ...]}
      2) {"words": ["coin", "useless", "boondoggle", ...]}
    In prod, fetch from TOP_WORDS_ENDPOINT with fallback to words.json.
    In dev, read words.json directly.
    """
    data = None
    
    # Try API first if in production mode
    if USE_LIVE_WORDS:
        try:
            resp = requests.get(TOP_WORDS_ENDPOINT, timeout=TOP_WORDS_TIMEOUT)
            resp.raise_for_status()
            data = resp.json()
            logger.debug("Successfully fetched words from API endpoint")
        except requests.exceptions.RequestException as e:
            logger.warning("API request failed: {} - will try fallback", e)
        except json.JSONDecodeError as e:
            logger.warning("Invalid JSON from API: {} - will try fallback", e)
        except Exception as e:
            logger.warning("Unexpected error fetching from API: {} - will try fallback", e)
    
    # Use fallback file if API failed or in dev mode
    if data is None:
        try:
            text = FALLBACK_FILE.read_text(encoding="utf-8")
            data = json.loads(text)
            source = "fallback file" if USE_LIVE_WORDS else "dev mode file"
            logger.info("Loaded words from {}: {}", source, FALLBACK_FILE.name)
        except FileNotFoundError:
            logger.error("Fallback file not found: {}", FALLBACK_FILE)
            return []
        except json.JSONDecodeError as e:
            logger.error("Invalid JSON in fallback file: {}", e)
            return []
        except Exception as e:
            logger.error("Failed to read fallback file: {}", e)
            return []
    
    # Parse the data structure – accept both object and string list forms
    raw = data.get("words", [])
    words: list[str] = []
    if isinstance(raw, list):
        if raw and isinstance(raw[0], dict):
            # Legacy: [{"word": "...", "count": ...}, ...]
            for entry in raw:
                w = entry.get("word") if isinstance(entry, dict) else None
                if isinstance(w, str):
                    words.append(w)
        else:
            # New: ["coin", "useless", ...]
            words = [w for w in raw if isinstance(w, str)]
    else:
        logger.warning("Unexpected payload shape for 'words': %r", type(raw))
    
    logger.debug("Loaded {} words", len(words))
    return words

if __name__ == "__main__":
    w = fetch_top_words()
    print(f"Loaded {len(w)} words:", w[:10])