# render_params.py
"""
Unbiased parameter sampling for image generation.
- LoRA scale: uniform on 0.01 grid in [LORA_SCALE_MIN, LORA_SCALE_MAX]
- CFG scale:  uniform on 0.01 grid in [CFG_MIN, CFG_MAX]
- Steps:      uniform integer in [STEPS_MIN, STEPS_MAX]

Negative-prompt policy:
- Randomly choose ONE of three profiles with equal probability (1/3 each):
  1) clean_glossy   – use NEGATIVE_PROMPT as-is (strict, glossy look)
  2) text_heavy     – allow text/logos/watermarks/signatures (posters/comics/UIs)
  3) degraded_retro – allow JPEG-style compression artifacts (VHS/glitch/deep-fried)
- DISABLE_NEGATIVE_PROMPT_PROB still takes precedence and can null out the prompt.

Runtime: Python 3.12, stdlib only.
"""

from __future__ import annotations

import random
import secrets
from typing import Iterable, List, Set, Tuple

from config import (
    # LoRA / CFG ranges
    LORA_SCALE_MIN, LORA_SCALE_MAX,
    CFG_MIN, CFG_MAX,
    # Independent steps
    STEPS_MIN, STEPS_MAX,
    # Prompt
    NEGATIVE_PROMPT,
    DISABLE_NEGATIVE_PROMPT_PROB,
)

# Optional metrics import
try:
    from metrics import log_event
except Exception:
    def log_event(*_args, **_kwargs):
        pass

# Sampling helpers

def _quantized_uniform(min_val: float, max_val: float, step: float = 0.01) -> float:
    """
    Sample uniformly from {min_val, min_val+step, ..., max_val} (inclusive).
    Uses integer space to avoid FP drift.
    """
    scale = int(round(1.0 / step))
    lo_i = int(round(min_val * scale))
    hi_i = int(round(max_val * scale))
    val_i = random.randint(lo_i, hi_i)
    return val_i / scale

# Negative-prompt profile implementation

_VARIANTS: Tuple[str, str, str] = ("clean_glossy", "text_heavy", "degraded_retro")

# Tokens removed in "text_heavy" profile (case-insensitive, spaces preserved)
_TEXT_TOKENS_TO_ALLOW: Set[str] = {
    "watermark", "text", "logo", "signature",
}

# Tokens removed in "degraded_retro" profile to allow compression/glitch flavor
# Intentionally do NOT remove 'lowres' or 'blurry' to protect subject fidelity.
_ARTIFACT_TOKENS_TO_ALLOW: Set[str] = {
    "jpeg artifacts", "compressed",
}

def _parse_neg_tokens(neg: str) -> List[str]:
    """
    Split a comma-separated negative prompt into a clean list of tokens,
    preserving original casing/spaces for reconstruction, but also enabling
    case-insensitive filtering.
    """
    if not neg:
        return []
    tokens = [p.strip() for p in neg.split(",")]
    return [t for t in tokens if t]

def _remove_tokens(tokens: Iterable[str], to_remove_lower: Set[str]) -> Tuple[List[str], List[str]]:
    """
    Return (kept, removed) lists after case-insensitive removal of specific tokens.
    """
    kept: List[str] = []
    removed: List[str] = []
    for t in tokens:
        if t.lower() in to_remove_lower:
            removed.append(t)
        else:
            kept.append(t)
    return kept, removed

def _apply_variant(base_neg: str, variant: str) -> Tuple[str | None, List[str]]:
    """
    Build the variant-specific negative prompt from the base NEGATIVE_PROMPT.

    Returns:
        (negative_prompt_string_or_None, removed_tokens_list)
    """
    tokens = _parse_neg_tokens(base_neg)

    if not tokens:
        return None, []

    removed: List[str] = []
    if variant == "clean_glossy":
        pass  # Keep as-is
    elif variant == "text_heavy":
        # Allow text/logos/watermarks/signatures
        tokens, removed = _remove_tokens(tokens, _TEXT_TOKENS_TO_ALLOW)
    elif variant == "degraded_retro":
        # Allow compression artifacts but keep structural safeguards
        tokens, removed = _remove_tokens(tokens, _ARTIFACT_TOKENS_TO_ALLOW)
    else:
        # Failsafe: fall back to clean_glossy if unknown variant
        variant = "clean_glossy"

    neg = ", ".join(tokens).strip()
    return (neg if neg else None), removed

def _choose_variant() -> str:
    """Equal probability (1/3 each) selection of negative prompt variant."""
    return random.choice(_VARIANTS)

# Public API

def sample_render_params() -> dict:
    """
    Return unbiased render parameters (independent, uniform).
    Each parameter is selected independently with no coupling or bias.
    """
    # LoRA: uniform random with 0.01 steps
    lora_scale = _quantized_uniform(LORA_SCALE_MIN, LORA_SCALE_MAX, 0.01)

    # CFG: uniform random with 0.01 steps
    cfg_scale = _quantized_uniform(CFG_MIN, CFG_MAX, 0.01)

    # Steps: uniform random integer
    steps = random.randint(STEPS_MIN, STEPS_MAX)

    # Random seed for each generation
    seed = int.from_bytes(secrets.token_bytes(4), "little")

    # Emit metrics for debugging/validation
    log_event("render_params_unbiased",
              cfg_scale=cfg_scale,
              lora_scale=lora_scale,
              steps=steps)

    # Negative prompt logic:
    # 1) With probability DISABLE_NEGATIVE_PROMPT_PROB, disable entirely.
    # 2) Otherwise, select one of the three profiles with equal probability,
    #    and apply the corresponding token removals.
    variant = None
    if random.random() < DISABLE_NEGATIVE_PROMPT_PROB:
        negative_prompt = None
        variant = "disabled"
        log_event("negative_prompt_mode", mode="disabled")
    else:
        variant = _choose_variant()
        negative_prompt, removed = _apply_variant(NEGATIVE_PROMPT, variant)
        log_event(
            "negative_prompt_variant",
            mode=variant,
            variant=variant,
            removed_tokens=removed,
        )

    return {
        "steps": steps,
        "cfg_scale": cfg_scale,
        "lora_scale": lora_scale,
        "seed": seed,
        "negative_prompt": negative_prompt,
        "negative_prompt_variant": variant,
    }
