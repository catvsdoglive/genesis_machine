# text_generator.py
"""
Generate one meme-token (name, ticker, description, animal) with
Mistral-7B-Instruct-v0.3 (Q4_K_M) via llama-cpp-python.

Enforces JSON Schema at generation time via
`response_format={"type": "json_object", "schema": SCHEMA}` (llama-cpp-python 0.3.14).
No legacy grammar fallback or JSON repair.
"""

from __future__ import annotations
import os, json, random, re
from pathlib import Path
from typing import List, Dict, Any, Tuple, Literal
from collections import deque
from memelogging import logger
import secrets

from pydantic import BaseModel, ValidationError, constr, field_validator, ConfigDict
from retry_policy import retryable
from template_library import build_user_prompt
from persona import COPYWRITER_PERSONAS
from dstyle import DESCRIPTION_STYLES
from config import (
    # Core + limits
    LLM_MODEL_PATH, LLM_THREADS, LLM_N_CTX, MAX_NAME_WORDS,
    DESCRIPTION_MAX_TOKENS, OUTPUT_DIR,

    # LLM randomization ranges (MIN/MAX)
    LLM_TEMPERATURE_MIN, LLM_TEMPERATURE_MAX,
    LLM_TOP_P_MIN, LLM_TOP_P_MAX,
    LLM_PRESENCE_PENALTY_MIN, LLM_PRESENCE_PENALTY_MAX,
    LLM_FREQUENCY_PENALTY_MIN, LLM_FREQUENCY_PENALTY_MAX,
    LLM_REPEAT_PENALTY_MIN, LLM_REPEAT_PENALTY_MAX,

    # Ticker knobs
    TICKER_MIN_LENGTH, TICKER_MAX_LENGTH,

    # Persona cache knobs
    PERSONA_CACHE_SIZE, PERSONA_CACHE_SAVE_FREQ,

    # Response headroom
    MAX_OVERHEAD,

    # Persona style knobs
    PERSONA_STYLE_MODE,
    PERSONA_STYLE_WEIGHT,
    PERSONA_STYLE_JITTER,
    PERSONA_STYLE_BETA_CONC,
)

# Optional metrics import with no hard dependency
try:
    from metrics import log_event
except Exception:
    def log_event(*_args, **_kwargs):
        pass

# JSON Schema used by llama-cpp's JSON mode (grammar-backed)
SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "name":   {"type": "string", "maxLength": 80},
        "ticker": {
            "type": "string",
            "minLength": TICKER_MIN_LENGTH,
            "maxLength": TICKER_MAX_LENGTH,
            "pattern": "^[A-Z]+$"
        },
        "description": {"type": "string"},
        "animal": {"type": "string", "enum": ["cat", "dog"]}
    },
    "required": ["name", "ticker", "description", "animal"]
}

# Threading / BLAS configuration
os.environ["OMP_NUM_THREADS"] = str(LLM_THREADS)

# Pydantic schema
class TokenMeta(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str
    ticker: constr(
        strip_whitespace=True,
        min_length=TICKER_MIN_LENGTH,
        max_length=TICKER_MAX_LENGTH,
        pattern=r"^[A-Z]+$",
    )
    description: str
    animal: str

    @field_validator("ticker", mode="before")
    @classmethod
    def _upper_and_sanitize(cls, v: str) -> str:
        """Remove non-alphanumerics, uppercase, and clamp to TICKER_MAX_LENGTH."""
        s = re.sub(r"[^A-Za-z]", "", str(v or "")).upper()
        return s[: TICKER_MAX_LENGTH]

    @field_validator("name", mode="before")
    @classmethod
    def _name_word_limit(cls, v: str) -> str:
        """
        Replace common punctuation with spaces, collapse whitespace,
        and keep the first MAX_NAME_WORDS tokens.
        """
        s = re.sub(r"[:\-]+", " ", str(v or ""))
        words = [w for w in s.strip().split() if w]
        words = words[: MAX_NAME_WORDS]
        return " ".join(words)

    @field_validator("animal")
    @classmethod
    def _catdog_only(cls, v: str) -> str:
        v = v.lower()
        if v not in {"cat", "dog"}:
            raise ValueError("animal must be 'cat' or 'dog'")
        return v

# LLM initialization (singleton)
_llm = None
def _init_llm():
    """Lazily create & cache the Llama() instance."""
    global _llm
    if _llm is None:
        from llama_cpp import Llama
        logger.info("Initializing llama.cpp with n_ctx={}", LLM_N_CTX)
        _llm = Llama(
            model_path=str(LLM_MODEL_PATH),
            n_threads=LLM_THREADS,
            n_ctx=LLM_N_CTX,
            chat_format="mistral-instruct",
            logits_all=False,
        )
    return _llm

# Persistent cache for variety across restarts
RECENT_COMBOS = deque(maxlen=PERSONA_CACHE_SIZE)
COMBO_CACHE_FILE = Path(OUTPUT_DIR) / "persona_cache.json"

def _load_combo_cache():
    """Load persisted combo cache from disk."""
    if COMBO_CACHE_FILE.exists():
        try:
            with open(COMBO_CACHE_FILE) as f:
                combos = json.load(f)
                RECENT_COMBOS.extend([tuple(x) for x in combos[-30:]])
        except Exception:
            pass

def _save_combo_cache():
    """Persist combo cache to disk."""
    try:
        with open(COMBO_CACHE_FILE, 'w') as f:
            json.dump(list(RECENT_COMBOS), f)
    except Exception:
        pass

# Load cache on module init
_load_combo_cache()

# Public API

def _sample_persona_style_weight() -> float:
    """
    Return persona weight in [0,1] according to env knobs:
      balanced → fixed PERSONA_STYLE_WEIGHT
      jitter   → base ± JITTER (clamped)
      random   → Beta(a,a) draw (Gamma sampling via random.gammavariate)
    """
    mode = (PERSONA_STYLE_MODE or "balanced").strip().lower()
    if mode == "balanced":
        w = float(PERSONA_STYLE_WEIGHT)
    elif mode == "jitter":
        base = float(PERSONA_STYLE_WEIGHT)
        j = float(PERSONA_STYLE_JITTER)
        w = base + random.uniform(-j, j)
    elif mode == "random":
        a = max(0.5, float(PERSONA_STYLE_BETA_CONC))
        x = random.gammavariate(a, 1.0)
        y = random.gammavariate(a, 1.0)
        w = x / (x + y) if (x + y) > 0 else 0.5
    else:
        w = 0.5
    return max(0.0, min(1.0, w))
    
@retryable
def generate_text(words: List[str]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Generates name/description and returns both token metadata and LLM parameters.
    Returns tuple of (meta, llm_params) for compatibility with existing code.
    """
    animal = random.choice(["cat", "dog"])
    
    # Get unique persona + style combo
    attempts = 0
    persona_idx = -1
    while attempts < 50:
        persona_idx = random.randrange(len(COPYWRITER_PERSONAS))
        persona = COPYWRITER_PERSONAS[persona_idx]
        style_idx = random.randrange(len(DESCRIPTION_STYLES))
        style_name, style_instruction = DESCRIPTION_STYLES[style_idx]
        combo = (persona[:50], style_name)
        
        if combo not in RECENT_COMBOS or attempts > 30:
            RECENT_COMBOS.append(combo)
            if len(RECENT_COMBOS) % PERSONA_CACHE_SAVE_FREQ == 0:
                _save_combo_cache()
            break
        attempts += 1
        
    logger.info(
        "LLM Generation Style → Persona: '{}' | Style: '{}'",
        persona[:50] + "..." if len(persona) > 50 else persona,
        style_name
    )
    
    # Compute VOICE:STYLE weights (persona vs style)
    persona_w = _sample_persona_style_weight()
    style_w = 1.0 - persona_w
    dominant = ("balanced" if abs(persona_w - style_w) < 0.05
                else ("persona" if persona_w > style_w else "style"))
    try:
        log_event("persona_style_weights", persona_weight=persona_w, style_weight=style_w, mode=PERSONA_STYLE_MODE, dominant=dominant)
    except Exception:
        pass

    # Build the user prompt using the FULL template system
    # This now properly returns 5 values
    user_prompt, trending_words_shown, trending_words_all, template_key, name_style_target = build_user_prompt(
        animal=animal,
        words=words,
        style_instruction=style_instruction,
        style_name=style_name,
        persona=persona,
        persona_weight=persona_w,
    )
    
    # Single-message chat
    messages = [
        {"role": "user", "content": user_prompt},
    ]

    # Per-generation randomization from config ranges
    temperature       = random.uniform(LLM_TEMPERATURE_MIN, LLM_TEMPERATURE_MAX)
    top_p             = random.uniform(LLM_TOP_P_MIN, LLM_TOP_P_MAX)
    presence_penalty  = random.uniform(LLM_PRESENCE_PENALTY_MIN, LLM_PRESENCE_PENALTY_MAX)
    frequency_penalty = random.uniform(LLM_FREQUENCY_PENALTY_MIN, LLM_FREQUENCY_PENALTY_MAX)
    repeat_penalty    = random.uniform(LLM_REPEAT_PENALTY_MIN, LLM_REPEAT_PENALTY_MAX)
    max_tokens        = DESCRIPTION_MAX_TOKENS + MAX_OVERHEAD
    model_name        = os.path.basename(str(LLM_MODEL_PATH))

    llm_seed = secrets.randbits(32)

    log_event("llm_parameters",
        temperature=temperature,
        top_p=top_p,
        presence_penalty=presence_penalty,
        frequency_penalty=frequency_penalty,
        repeat_penalty=repeat_penalty,
        seed=llm_seed
    )

    llm = _init_llm()
    # llama-cpp-python JSON Schema mode
    result = llm.create_chat_completion(
        messages=messages,
        response_format={"type": "json_object", "schema": SCHEMA},
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        presence_penalty=presence_penalty,
        frequency_penalty=frequency_penalty,
        repeat_penalty=repeat_penalty,
        seed=llm_seed
    )

    raw_json = result["choices"][0]["message"]["content"]
    
    logger.debug("Raw LLM output (first 500 chars): {}", raw_json[:500])

    try:
        data = json.loads(raw_json)
        logger.debug("Parsed JSON keys: {}", list(data.keys()))
        logger.debug(
            "Ticker value: {!r}, Name value: {!r}",
            data.get('ticker', 'MISSING'),
            data.get('name', 'MISSING')
        )
    except json.JSONDecodeError as e:
        logger.error("JSON decode failed at position {}: {}", e.pos, e.msg)
        logger.error(
            "Raw JSON around error (±50 chars): ...{}...",
            raw_json[max(0, e.pos-50):min(len(raw_json), e.pos+50)]
        )
        raise ValueError(f"Model produced invalid JSON: {e}") from e
            
    try:
        result = TokenMeta(**data).model_dump()
    except ValidationError as e:
        logger.error("Pydantic validation failed:")
        for error in e.errors():
            logger.error("  Field '{}': {} (got value: {})", 
                        error['loc'][0], 
                        error['msg'],
                        error.get('input', 'N/A'))
        logger.debug("Full data that failed validation: {}", json.dumps(data, indent=2))
        raise ValueError(f"JSON schema error: {e}") from e

    # Name post-processing functions
    def _case_like(src: str, repl: str) -> str:
        """Match replacement case to source token for aesthetics."""
        return repl.upper() if src.isupper() else (repl.capitalize() if src[:1].isupper() else repl)

    def _suppress_bark(name: str) -> tuple[str, bool]:
        """Replace occurrences of the CamelCase root 'Bark'."""
        choices = [
            # Actions & Behaviors
            "Paw", "Claw", "Fang", "Snout", "Tail", "Fur", "Whisker", "Nose",
            "Wag", "Howl", "Growl", "Chomp", "Fetch", "Dig", "Sniff", "Bite",
            "Leap", "Bound", "Sprint", "Chase", "Hunt", "Track", "Guard", "Heel",
            "Shake", "Roll", "Pant", "Drool", "Lick", "Nuzzle", "Cuddle", "Play",
            
            # Pack & Social Terms
            "Pup", "Hound", "Alpha", "Beta", "Pack", "Wolf", "Mutt", "Stray",
            "Scout", "Lead", "Omega", "Buddy", "Pal", "Friend", "Loyal", "Trust",
            
            # Objects & Items
            "Bone", "Leash", "Collar", "Bowl", "Stick", "Ball", "Treat", "Kennel",
            "Chew", "Toy", "Bed", "Tag", "Vest", "Harness", "Crate", "Yard",
            
            # Sounds
            "Woof", "Yap", "Arf", "Ruff", "Grr", "Whine", "Yelp", "Bay",
            "Yip", "Bark", "Growl", "Snarl", "Whimper", "Cry", "Call",
            
            # Breeds & Types
            "Lab", "Pug", "Doge", "Shiba", "Husky", "Beagle", "Boxer", "Dane",
            "Corgi", "Poodle", "Bulldog", "Terrier", "Spaniel", "Retriever",
            
            # Anatomy
            "Muzzle", "Jowl", "Scruff", "Pelt", "Coat", "Ear", "Spot", "Patch",
            "Tooth", "Pad", "Dewclaw", "Flank", "Rump", "Chest", "Belly",
            
            # Personality & Traits
            "Good", "Best", "Smart", "Fast", "Brave", "Bold", "Fierce", "Wild",
            "Happy", "Jolly", "Peppy", "Zippy", "Lucky", "Noble", "Proud"
        ]
        
        pat = re.compile(r"(?:(?<![A-Za-z])[Bb][Aa][Rr][Kk]|(?<=[a-z])Bark)")
        changed = False
        def _sub(m):
            nonlocal changed
            changed = True
            rep = random.choice(choices)
            return _case_like(m.group(0), rep)
        new = pat.sub(_sub, name)
        return new, changed

    def _suppress_feline(name: str) -> tuple[str, bool]:
        """Replace occurrences of common feline roots like 'Meow', 'Kitty', 'Purr'."""
        choices = [
            # Actions & Behaviors
            "Paw", "Claw", "Fang", "Whisker", "Tail", "Fur", "Pounce", "Leap",
            "Stalk", "Hunt", "Climb", "Scratch", "Stretch", "Prowl", "Slink", "Crouch",
            "Spring", "Swat", "Bat", "Nuzzle", "Groom", "Lounge", "Perch", "Watch",
            
            # Cat Types & Terms
            "Feline", "Tom", "Queen", "Lynx", "Lion", "Tiger", "Panther", "Jaguar",
            "Leopard", "Cheetah", "Ocelot", "Bobcat", "Cougar", "Puma", "Wildcat",
            
            # Objects & Items
            "Collar", "Bell", "Tower", "Post", "Nip", "Toy", "Bed", "Tree",
            "Litter", "Bowl", "Yarn", "Feather", "Mouse", "Bird", "Fish",
            
            # Sounds (alternatives)
            "Hiss", "Growl", "Chirp", "Trill", "Chatter", "Yowl", "Cry", "Call",
            
            # Personality & Traits
            "Sleek", "Stealth", "Grace", "Agile", "Swift", "Silent", "Mystic", "Noble",
            "Proud", "Fierce", "Wild", "Clever", "Sly", "Zen", "Regal", "Elite",
            "Shadow", "Phantom", "Ghost", "Ninja", "Sphinx", "Oracle", "Sage"
        ]
        
        # Pattern matches: Meow, Kitty, Purr, Cat (as standalone or in CamelCase)
        # Avoiding "Cat" might be too aggressive, so focusing on the most cliché ones
        pat = re.compile(
            r"(?:(?<![A-Za-z])[Mm][Ee][Oo][Ww]|"
            r"(?<=[a-z])Meow|"
            r"(?<![A-Za-z])[Kk][Ii][Tt][Tt][Yy]|"
            r"(?<=[a-z])Kitty|"
            r"(?<![A-Za-z])[Pp][Uu][Rr][Rr]|"
            r"(?<=[a-z])Purr)"
        )
        
        changed = False
        def _sub(m):
            nonlocal changed
            changed = True
            rep = random.choice(choices)
            return _case_like(m.group(0), rep)
        
        new = pat.sub(_sub, name)
        return new, changed

    def _split_camel(s: str) -> list[str]:
        """Split CamelCase/PascalCase sensibly."""
        tokens = re.findall(r"[A-Z]+(?=[A-Z][a-z]|[0-9]|$)|[A-Z]?[a-z]+|[0-9]+", s)
        return [t for t in tokens if t]

    def _to_pascal(tokens: list[str]) -> str:
        return "".join(w[:1].upper() + w[1:] for w in tokens if w)

    def _enforce_name_style(name: str, target: str, max_words: int) -> tuple[str, bool]:
        """Enforce name style: 'oneword' | 'spaced' | 'camel'."""
        if target == "oneword":
            base = re.sub(r"[^A-Za-z]", "", name or "")
            if not base:
                return name, False
            pretty = base[:1].upper() + base[1:].lower()
            return pretty, (pretty != name)
        elif target == "spaced":
            if " " in name:
                return name, False
            parts = _split_camel(name)
            if len(parts) >= 2:
                parts = parts[:max_words]
                pretty = " ".join(p[:1].upper() + p[1:] for p in parts)
                return pretty, True
            return name, False
        else:  # target == "camel"
            if " " not in name:
                return name, False
            words = [w for w in re.split(r"\s+", name.strip()) if w]
            if not words:
                return name, False
            words = words[:max_words]
            return _to_pascal(words), True

    # Apply animal-specific suppression then style enforcement
    _orig_name = result["name"]
    _suppression_changed = False
    _name1 = _orig_name

    # Apply appropriate suppression based on animal type
    if result["animal"] == "dog":
        _name1, _suppression_changed = _suppress_bark(_orig_name)
        if _suppression_changed:
            log_event("name_bark_suppressed", before=_orig_name, after=_name1)
    elif result["animal"] == "cat":
        _name1, _suppression_changed = _suppress_feline(_orig_name)
        if _suppression_changed:
            log_event("name_feline_suppressed", before=_orig_name, after=_name1)

    # Apply style enforcement
    _name2, _style_changed = _enforce_name_style(_name1, name_style_target, MAX_NAME_WORDS)
    if _style_changed:
        log_event("name_style_enforced", mode=name_style_target, before=_name1, after=_name2)
    result["name"] = _name2

    # Re-validate after adjustments
    try:
        result = TokenMeta(**result).model_dump()
    except ValidationError as e:
        result["name"] = _orig_name
        result = TokenMeta(**result).model_dump()

    log_event("ticker_source", source="llm")
    
    # Final validation
    try:
        result = TokenMeta(**result).model_dump()
    except ValidationError as e:
        logger.error("Post-override validation failed: {}", e)
        raise ValueError(f"Post-override validation error: {e}") from e
    
    # Build the metadata dictionary
    meta = {
        "name": result["name"],
        "ticker": result["ticker"],
        "description": result["description"],
        "animal": result["animal"],
    }
    
    # Build the LLM parameters dictionary with all context
    llm_params = {
        "model": model_name,
        "temperature": temperature,
        "top_p": top_p,
        "presence_penalty": presence_penalty,
        "frequency_penalty": frequency_penalty,
        "repeat_penalty": repeat_penalty,
        "max_tokens": max_tokens,
        "seed": llm_seed, 
        # Context fields for database storage
        "trending_words_shown": trending_words_shown,
        "trending_words_all": trending_words_all,
        "user_prompt": user_prompt,
        "template_key": template_key,
        "trending_words_count": len(trending_words_shown),
        "name_style_target": name_style_target,
        "persona_text": persona if isinstance(persona, str) else str(persona),
        "persona_index": persona_idx,
        "persona_style_mode": PERSONA_STYLE_MODE,
        "description_style": style_name,
        "persona_weight": persona_w,
        "style_weight": style_w,
    }
    
    # Return as tuple for compatibility with existing code
    return meta, llm_params
