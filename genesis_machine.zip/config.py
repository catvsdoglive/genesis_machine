# config.py
"""
Loads configuration from environment variables via .env file.
Raises exceptions for missing or invalid values at import time.

Python: 3.12
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env once per process (prefer repo-root .env next to this file; fallback to CWD search)
if not os.environ.get("_MEMEFACTORY_ENV_LOADED"):
    _ENV_PATH = Path(__file__).parent / ".env"
    if _ENV_PATH.exists():
        load_dotenv(_ENV_PATH)
    else:
        load_dotenv()
    os.environ["_MEMEFACTORY_ENV_LOADED"] = "1"

# Validation helpers
def _require(key: str) -> str:
    v = os.getenv(key)
    if v is None:
        raise KeyError(f"Missing required environment variable: {key}")
    if isinstance(v, str) and v.strip() == "":
        raise ValueError(f"Environment variable {key} must not be empty")
    return v

def _as_bool(key: str) -> bool:
    v = _require(key).strip().lower()
    if v in ("1", "true", "yes", "y", "on"):
        return True
    if v in ("0", "false", "no", "n", "off"):
        return False
    raise ValueError(f"Environment variable {key} must be a boolean (got: {v!r})")

def _as_int(key: str) -> int:
    v = _require(key)
    try:
        return int(v)
    except Exception as e:
        raise ValueError(f"Environment variable {key} must be an int (got: {v!r})") from e

def _as_float(key: str) -> float:
    v = _require(key)
    try:
        return float(v)
    except Exception as e:
        raise ValueError(f"Environment variable {key} must be a float (got: {v!r})") from e

def _as_path(key: str) -> Path:
    return Path(_require(key))

# Execution flags
SKIP_WARMUP = _as_bool("SKIP_WARMUP")
SKIP_LORA = _as_bool("SKIP_LORA")

# Persistence & output
DB_PATH = _as_path("DB_PATH")
OUTPUT_DIR = _as_path("OUTPUT_DIR")
IMAGE_DIR = _as_path("IMAGE_DIR")

# Logging
LOG_PATH = _as_path("LOG_PATH")

# Metrics
METRICS_PATH = _as_path("METRICS_PATH")

# Model files
LORA_FILE = _as_path("LORA_FILE")
LORA_VERSION = _require("LORA_VERSION")
SD_V1_5_PATH = _as_path("SD_V1_5_PATH")
SD_V1_4_PATH = _as_path("SD_V1_4_PATH")
SD_V2_1_PATH = _as_path("SD_V2_1_PATH")

# LLM runtime
LLM_MODEL_PATH = _as_path("LLM_MODEL_PATH")
LLM_THREADS = _as_int("LLM_THREADS")
LLM_N_CTX = _as_int("LLM_N_CTX")

# LLM parameter ranges
LLM_TEMPERATURE_MIN = _as_float("LLM_TEMPERATURE_MIN")
LLM_TEMPERATURE_MAX = _as_float("LLM_TEMPERATURE_MAX")
LLM_TOP_P_MIN = _as_float("LLM_TOP_P_MIN")
LLM_TOP_P_MAX = _as_float("LLM_TOP_P_MAX")
LLM_PRESENCE_PENALTY_MIN = _as_float("LLM_PRESENCE_PENALTY_MIN")
LLM_PRESENCE_PENALTY_MAX = _as_float("LLM_PRESENCE_PENALTY_MAX")
LLM_FREQUENCY_PENALTY_MIN = _as_float("LLM_FREQUENCY_PENALTY_MIN")
LLM_FREQUENCY_PENALTY_MAX = _as_float("LLM_FREQUENCY_PENALTY_MAX")
LLM_REPEAT_PENALTY_MIN = _as_float("LLM_REPEAT_PENALTY_MIN")
LLM_REPEAT_PENALTY_MAX = _as_float("LLM_REPEAT_PENALTY_MAX")
MAX_OVERHEAD = _as_int("MAX_OVERHEAD")

# Trending words API
TOP_WORDS_ENDPOINT = _require("TOP_WORDS_ENDPOINT")
TOP_WORDS_TIMEOUT = _as_int("TOP_WORDS_TIMEOUT")

# Retry policy
RETRY_MAX_ATTEMPTS = _as_int("RETRY_MAX_ATTEMPTS")
RETRY_BACKOFF_SEC = _as_float("RETRY_BACKOFF_SEC")

# Main loop
LOOP_DELAY_SEC = _as_float("LOOP_DELAY_SEC")

# Stable Diffusion parameters
STEPS_MIN = _as_int("STEPS_MIN")
STEPS_MAX = _as_int("STEPS_MAX")
SD_SEED = _as_int("SD_SEED")
IMG_HEIGHT = _as_int("IMG_HEIGHT")
IMG_WIDTH = _as_int("IMG_WIDTH")

# SD1.5 prompt weights
TRIGGER_WEIGHT = _as_float("TRIGGER_WEIGHT")
BREED_WEIGHT = _as_float("BREED_WEIGHT")

# Text generation
MAX_NAME_WORDS = _as_int("MAX_NAME_WORDS")
MAX_INSPIRATION_WORDS = _as_int("MAX_INSPIRATION_WORDS")
RANDOM_INSPIRATION_WORDS = _as_bool("RANDOM_INSPIRATION_WORDS")
INSPIRATION_WORDS_MIN = _as_int("INSPIRATION_WORDS_MIN")
INSPIRATION_WORDS_MAX = _as_int("INSPIRATION_WORDS_MAX")
TICKER_MIN_LENGTH = _as_int("TICKER_MIN_LENGTH")
TICKER_MAX_LENGTH = _as_int("TICKER_MAX_LENGTH")
DESCRIPTION_MAX_TOKENS = _as_int("DESCRIPTION_MAX_TOKENS")
NAME_ONEWORD_PROB = _as_float("NAME_ONEWORD_PROB")

# LoRA configuration
LORA_SCALE_MIN = _as_float("LORA_SCALE_MIN")
LORA_SCALE_MAX = _as_float("LORA_SCALE_MAX")
RANDOM_LORA_DISABLE_PROB = _as_float("RANDOM_LORA_DISABLE_PROB")

# CFG scale range
CFG_MIN = _as_float("CFG_MIN")
CFG_MAX = _as_float("CFG_MAX")

# Negative prompt
NEGATIVE_PROMPT = _require("NEGATIVE_PROMPT")
DISABLE_NEGATIVE_PROMPT_PROB = _as_float("DISABLE_NEGATIVE_PROMPT_PROB")

# Persona cache
PERSONA_CACHE_SIZE = _as_int("PERSONA_CACHE_SIZE")
PERSONA_CACHE_SAVE_FREQ = _as_int("PERSONA_CACHE_SAVE_FREQ")

# Hardware
DEVICE = _require("DEVICE")

# Live words toggle
USE_LIVE_WORDS = _as_bool("USE_LIVE_WORDS")

# SQLite configuration
SQLITE_JOURNAL_MODE = _require("SQLITE_JOURNAL_MODE")
SQLITE_SYNCHRONOUS = _require("SQLITE_SYNCHRONOUS")
SQLITE_BUSY_TIMEOUT_MS = _as_int("SQLITE_BUSY_TIMEOUT_MS")
SQLITE_WAL_AUTOCHECKPOINT = _as_int("SQLITE_WAL_AUTOCHECKPOINT")

# Persona/style blending
PERSONA_STYLE_MODE = _require("PERSONA_STYLE_MODE")
PERSONA_STYLE_WEIGHT = _as_float("PERSONA_STYLE_WEIGHT")
PERSONA_STYLE_JITTER = _as_float("PERSONA_STYLE_JITTER")
PERSONA_STYLE_BETA_CONC = _as_float("PERSONA_STYLE_BETA_CONC")

# Operator messages
OPERATOR_MSG_MIN_INTERVAL = _as_float("OPERATOR_MSG_MIN_INTERVAL")
OPERATOR_MSG_MAX_INTERVAL = _as_float("OPERATOR_MSG_MAX_INTERVAL")
OPERATOR_MSG_ENABLED = _as_bool("OPERATOR_MSG_ENABLED")

# WebSocket configuration
MEME_WS_HOST = os.getenv("MEME_WS_HOST", "127.0.0.1")
MEME_WS_PORT = int(os.getenv("MEME_WS_PORT", "8767"))

# Textual Inversion embeddings
TI_DIR = _as_path("TI_DIR")
TI_EMBEDDINGS = _require("TI_EMBEDDINGS")

# === Multi-model SD config ===
# If ENABLE_MULTI_MODEL=false we fall back to legacy sd-v1-5 only.
ENABLE_MULTI_MODEL = _as_bool("ENABLE_MULTI_MODEL")
# Optional override for testing: "", "sd15", "sd14", or "sd21"
SD_FORCE_MODEL = os.getenv("SD_FORCE_MODEL", "").strip()
# Directory checkpoints for SD v1.4 and SD v2.1 are configured above.
# LRU size for pipeline cache (count of resident StableDiffusionPipeline instances)
SD_PIPELINE_CACHE_SIZE = _as_int("SD_PIPELINE_CACHE_SIZE")

# --- Model switch & recovery policy ---
MODEL_FALLBACK_POLICY = os.getenv("MODEL_FALLBACK_POLICY", "last_good").strip().lower()
# last_good | sd15 | none
MODEL_QUARANTINE_SEC = int(os.getenv("MODEL_QUARANTINE_SEC", "900"))  # 15 min
MODEL_SWITCH_COALESCE_MS = int(os.getenv("MODEL_SWITCH_COALESCE_MS", "250"))

# ===== End: config.py =====