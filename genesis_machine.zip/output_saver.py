# output_saver.py
"""
Saves meme token images and metadata to disk and SQLite database.
Uses atomic writes and WAL mode for concurrent access.
"""

import os
import sqlite3
import tempfile
from datetime import datetime, timezone
import json
from pathlib import Path, PurePath
from typing import Any, Dict, Tuple, Optional

from config import (
    IMAGE_DIR,
    DB_PATH,
    LORA_VERSION,
    SQLITE_JOURNAL_MODE,
    SQLITE_SYNCHRONOUS,
    SQLITE_BUSY_TIMEOUT_MS,
    SQLITE_WAL_AUTOCHECKPOINT,
    TICKER_MIN_LENGTH,
    TICKER_MAX_LENGTH,
)
from memelogging import logger
import re

_NEW_COLS = [("sd_model_key", "TEXT"), ("ti_mode", "TEXT"), ("ti_tokens", "TEXT")]

def configure_sqlite_connection(conn: sqlite3.Connection, busy_ms: int = SQLITE_BUSY_TIMEOUT_MS) -> None:
    """Configure SQLite for concurrent access."""
    cur = conn.cursor()
    try:
        cur.execute(f"PRAGMA journal_mode={SQLITE_JOURNAL_MODE};")
        cur.execute(f"PRAGMA synchronous={SQLITE_SYNCHRONOUS};")
        cur.execute(f"PRAGMA busy_timeout={int(busy_ms)};")
        if SQLITE_JOURNAL_MODE.upper() == "WAL" and SQLITE_WAL_AUTOCHECKPOINT > 0:
            cur.execute(f"PRAGMA wal_autocheckpoint={int(SQLITE_WAL_AUTOCHECKPOINT)};")
    finally:
        cur.close()

def _to_json(value: Any) -> Optional[str]:
    """Helper to serialize lists/dicts to JSON TEXT for database storage."""
    if value is None:
        return None
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False)
    return json.dumps(value, ensure_ascii=False) if not isinstance(value, str) else value

def _ensure_additional_columns(conn: sqlite3.Connection) -> None:
    """
    Online, idempotent migration to add new columns if an existing DB is present.
    """
    try:
        cur = conn.execute("PRAGMA table_info(meme_tokens);")
        have = {row[1] for row in cur.fetchall()}  # name is col 2
        for name, ctype in _NEW_COLS:
            if name not in have:
                logger.info("Altering table to add column {} {}", name, ctype)
                conn.execute(f"ALTER TABLE meme_tokens ADD COLUMN {name} {ctype};")
        conn.commit()
    except Exception:
        logger.exception("Failed to ensure additional columns")
        conn.rollback()
        
# Initialize database on module import
Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
_init_conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
try:
    configure_sqlite_connection(_init_conn, busy_ms=SQLITE_BUSY_TIMEOUT_MS)
    _init_conn.execute(
        """
        CREATE TABLE IF NOT EXISTS meme_tokens (
            id                INTEGER PRIMARY KEY,
            name              TEXT,
            ticker            TEXT,
            description       TEXT,
            contract_address  TEXT,
            animal_class      TEXT,
            image_filename    TEXT,
            image_path        TEXT,
            created_at        TEXT,
            lora_id           TEXT,

            -- Stable Diffusion parameters
            cfg_scale         REAL,
            lora_scale        REAL,
            steps             INTEGER,
            seed              INTEGER,
            sampler           TEXT,
            model             TEXT,
            width             INTEGER,
            height            INTEGER,

            -- Prompts
            prompt                 TEXT,
            negative_prompt        TEXT,        -- effective WITH TI
            negative_prompt_base   TEXT,        -- base WITHOUT TI

            -- LLM parameters
            llm_model             TEXT,
            llm_temperature       REAL,
            llm_top_p             REAL,
            llm_presence_penalty  REAL,
            llm_frequency_penalty REAL,
            llm_repeat_penalty    REAL,
            llm_max_tokens        INTEGER,
            llm_seed              INTEGER,
            -- Structured image generation metadata (JSON)
            generation_meta       TEXT,
            
            -- === LLM generation context ===
            trending_words_shown TEXT,            -- JSON List[str]
            trending_words_all TEXT,              -- JSON List[str]
            user_prompt TEXT,
            template_key TEXT,
            trending_words_count INTEGER,
            name_style_target TEXT,
            persona_text TEXT,
            persona_index INTEGER,
            description_style TEXT,
            persona_weight REAL,
            style_weight REAL,
            -- === SD generation context ===
            negative_prompt_variant TEXT,
            lora_disabled INTEGER,                -- bool as 0/1
            prompt_truncated INTEGER,             -- bool as 0/1
            truncated_components TEXT             -- JSON List[str]
            ,
            -- === New tracking fields (multi-model + TI) ===
            sd_model_key TEXT,                    -- 'sd15' | 'sd14' | 'sd21'
            ti_mode TEXT,                         -- e.g. 'sd15:EasyNegative', 'sd21:plain'
            ti_tokens TEXT                        -- JSON List[str]
        );
        """
    )
     
    _init_conn.execute("CREATE INDEX IF NOT EXISTS idx_meme_tokens_created_at ON meme_tokens(created_at DESC);")
    _init_conn.execute("CREATE INDEX IF NOT EXISTS idx_meme_tokens_contract ON meme_tokens(contract_address);")
    _init_conn.commit()
finally:
    try: _ensure_additional_columns(_init_conn)
    except Exception: pass
    _init_conn.close()


def _extract_knobs(token_meta: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract canonical image generation parameters from metadata.
    Accepts only modern keys from token_meta['params'].
    """
    params = dict(token_meta.get("params") or {})
    return {
        "cfg_scale": params.get("cfg_scale"),
        "lora_scale": params.get("lora_scale"),
        "steps": params.get("steps"),
        "seed": params.get("seed"),
        "sampler": params.get("sampler"),
        "model": params.get("model"),
        "width": params.get("width"),
        "height": params.get("height"),
        "prompt": token_meta.get("prompt") or params.get("prompt"),
        "negative_prompt": params.get("negative_prompt"),
        "negative_prompt_base": params.get("negative_prompt_base") or token_meta.get("negative_prompt_base"),
        # New tracking fields
        "sd_model_key": params.get("sd_model_key"),
        "ti_mode": params.get("ti_mode"),
        "ti_tokens": params.get("ti_tokens"),
    }


def _extract_llm_knobs(token_meta: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract LLM parameters from token_meta['llm_params'] using canonical keys only.
    """
    llm = dict(token_meta.get("llm_params") or {})
    return {
        "llm_model": llm.get("model"),
        "llm_temperature": llm.get("temperature"),
        "llm_top_p": llm.get("top_p"),
        "llm_presence_penalty": llm.get("presence_penalty"),
        "llm_frequency_penalty": llm.get("frequency_penalty"),
        "llm_repeat_penalty": llm.get("repeat_penalty"),
        "llm_max_tokens": llm.get("max_tokens"),
        "llm_seed": llm.get("seed"),
    }


def save(token_meta: dict, img_bytes: bytes) -> Tuple[int, datetime]:
    """
    Save image file and database record atomically.
    
    Returns:
        Tuple of (id, created_at) from the inserted row
    
    Args:
        token_meta: Token metadata including name, ticker, description, etc.
        img_bytes: PNG image data
    """
    # Validate ticker format
    ticker_val = str(token_meta.get("ticker") or "")
    if not re.fullmatch(rf"^[A-Z]{{{TICKER_MIN_LENGTH},{TICKER_MAX_LENGTH}}}$", ticker_val):
        raise ValueError(f"Invalid ticker (letters only, {TICKER_MIN_LENGTH}-{TICKER_MAX_LENGTH} chars): {ticker_val!r}")

    # Write image atomically
    os.makedirs(IMAGE_DIR, exist_ok=True)

    filename = token_meta.get("filename")
    if not filename:
        base = (token_meta.get("ticker") or token_meta.get("name") or "meme").replace(" ", "_")
        filename = f"{base}_{int(datetime.now(timezone.utc).timestamp())}.png"
    
    # Sanitize filename to prevent directory traversal
    filename = PurePath(str(filename)).name

    tmp_fd, tmp_path = tempfile.mkstemp(dir=str(IMAGE_DIR), suffix=".png")
    final_path = Path(IMAGE_DIR) / filename
    try:
        os.fchmod(tmp_fd, 0o640)
        with os.fdopen(tmp_fd, "wb") as tmp_file:
            tmp_file.write(img_bytes)
        os.replace(tmp_path, str(final_path))
        os.chmod(str(final_path), 0o640)
    except Exception:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        logger.exception("Failed to write image file")
        raise

    web_path = f"/images/memefactory/{filename}"

    # Extract parameters for database
    knobs = _extract_knobs(token_meta)
    llm_flat = _extract_llm_knobs(token_meta)

    # Insert database record
    created_at = datetime.now(timezone.utc)
    created_at_str = created_at.isoformat()
    
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
    try:
        configure_sqlite_connection(conn, busy_ms=SQLITE_BUSY_TIMEOUT_MS)
        cur = conn.cursor()
        
        cur.execute(
            """
            INSERT INTO meme_tokens (
                name, ticker, description, contract_address, animal_class,
                image_filename, image_path, created_at, lora_id,
                cfg_scale, lora_scale, steps, seed, sampler, model, width, height,
                prompt, negative_prompt, negative_prompt_base,
                llm_model, llm_temperature, llm_top_p, llm_presence_penalty,
                llm_frequency_penalty, llm_repeat_penalty, llm_max_tokens, llm_seed,
                generation_meta,
                trending_words_shown, trending_words_all, user_prompt, template_key,
                trending_words_count, name_style_target, persona_text, persona_index, description_style,
                persona_weight, style_weight,
                negative_prompt_variant, lora_disabled, prompt_truncated, truncated_components
                ,
                -- New tracking fields
                sd_model_key, ti_mode, ti_tokens
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                token_meta.get("name"),
                token_meta.get("ticker"),
                token_meta.get("description"),
                token_meta.get("contract_address"),
                token_meta.get("animal_class"),
                filename,
                web_path,
                created_at_str,
                LORA_VERSION,
                knobs.get("cfg_scale"),
                knobs.get("lora_scale"),
                knobs.get("steps"),
                knobs.get("seed"),
                knobs.get("sampler"),
                knobs.get("model"),
                knobs.get("width"),
                knobs.get("height"),
                knobs.get("prompt"),
                knobs.get("negative_prompt"),
                knobs.get("negative_prompt_base"),
                llm_flat.get("llm_model"),
                llm_flat.get("llm_temperature"),
                llm_flat.get("llm_top_p"),
                llm_flat.get("llm_presence_penalty"),
                llm_flat.get("llm_frequency_penalty"),
                llm_flat.get("llm_repeat_penalty"),
                llm_flat.get("llm_max_tokens"),
                llm_flat.get("llm_seed"),
                (json.dumps(token_meta.get("generation_meta"), ensure_ascii=False)
                 if token_meta.get("generation_meta") is not None else None),
                # LLM generation context
                _to_json(token_meta.get("trending_words_shown", [])),
                _to_json(token_meta.get("trending_words_all", [])),
                token_meta.get("user_prompt"),
                token_meta.get("template_key"),
                int(token_meta.get("trending_words_count", 0)),
                token_meta.get("name_style_target"),
                token_meta.get("persona_text"),
                int(token_meta.get("persona_index", 0)),
                token_meta.get("description_style"),
                float(token_meta.get("persona_weight", 0.0)),
                float(token_meta.get("style_weight", 0.0)),
                # SD generation context
                token_meta.get("negative_prompt_variant"),
                1 if token_meta.get("lora_disabled") else 0,
                1 if token_meta.get("prompt_truncated") else 0,
                _to_json(token_meta.get("truncated_components", [])),
                # New tracking fields
                knobs.get("sd_model_key"),
                knobs.get("ti_mode"),
                _to_json(knobs.get("ti_tokens")),
            ),
        )
        
        token_id = cur.lastrowid
        conn.commit()
        
        logger.info(f"Saved token with ID: {token_id}, created_at: {created_at_str}")
        return (token_id, created_at)
        
    except Exception:
        logger.exception("Failed to insert metadata into database")
        conn.rollback()
        raise
    finally:
        conn.close()
# ===== End: output_saver.py =====