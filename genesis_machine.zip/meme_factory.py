# meme_factory.py
"""
Main loop for continuous meme token generation.
Fetches words, generates text, creates images, saves to database.
"""

from __future__ import annotations

import os
import sqlite3
import time
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, Any, Mapping, Optional
from output_saver import configure_sqlite_connection

from config import IMAGE_DIR, LOOP_DELAY_SEC, DB_PATH, SQLITE_BUSY_TIMEOUT_MS, SQLITE_JOURNAL_MODE, SQLITE_SYNCHRONOUS, SQLITE_WAL_AUTOCHECKPOINT

import memelogging
from loguru import logger
from metrics import log_event, token_scope, set_trace_meta

from address_faker import generate_address
from fetch_top_words import fetch_top_words
from text_generator import generate_text
from prompt_builder import build_prompt
from image_generator import generate_image, select_model_key
from output_saver import save as save_output
from render_params import sample_render_params

from ws_server import (
    start_ws_server_in_thread,
    broadcast_pipeline_stage,
    broadcast_token,
    broadcast_metrics as ws_broadcast_metrics,
    broadcast_top_words,
    broadcast_log,
)

Path(IMAGE_DIR).mkdir(parents=True, exist_ok=True)

def serialize_token_for_wire(row: Mapping[str, Any]) -> Dict[str, Any]:
    """
    Convert DB row/ORM object to the unified wire format for WebSocket/REST.
    This is the single source of truth for outward-facing payloads.
    """
    o = dict(row)
    # Decode booleans (stored as INTEGER 0/1)
    lora_disabled = bool(o.get("lora_disabled")) if "lora_disabled" in o else False
    prompt_truncated = bool(o.get("prompt_truncated")) if "prompt_truncated" in o else False

    # Handle created_at formatting
    created_at = o.get("created_at")
    if created_at:
        if isinstance(created_at, str):
            # Already ISO format
            created_at_str = created_at
        elif isinstance(created_at, datetime):
            created_at_str = created_at.isoformat()
        else:
            created_at_str = str(created_at)
    else:
        created_at_str = datetime.now(timezone.utc).isoformat()

    # Helper for JSON field decoding (inlined from _maybe_json)
    def decode_json(value):
        if value is None:
            return None
        if isinstance(value, (list, dict, bool, int, float)):
            return value
        if isinstance(value, (bytes, bytearray)):
            value = value.decode("utf-8", errors="ignore")
        try:
            return json.loads(value)
        except Exception:
            return value


    # Handle id field
    token_id = o.get("id")
    if token_id is not None:
        token_id = int(token_id)

    return {
        # core
        "id": token_id,
        "created_at": created_at_str,
        "name": o.get("name"),
        "ticker": o.get("ticker"),
        "description": o.get("description"),
        "contract_address": o.get("contract_address"),
        "animal_class": o.get("animal_class"),
        "image_filename": o.get("image_filename"),
        "image_path": o.get("image_path"),
        "lora_id": o.get("lora_id"),
        "prompt": o.get("prompt"),
        "model_name": o.get("model_name"),
        "ti_embeddings_used": o.get("ti_embeddings_used"),
        "negative_prompt": o.get("negative_prompt"), 
        "negative_prompt_base": o.get("negative_prompt_base"),
        "sampler": o.get("sampler"),
        
        # SD parameters
        "cfg_scale": o.get("cfg_scale"),
        "lora_scale": o.get("lora_scale"),
        "steps": o.get("steps"),
        "seed": o.get("seed"),
        "model": o.get("model"),
        "width": o.get("width"),
        "height": o.get("height"),
        
        # LLM parameters
        "llm_model": o.get("llm_model"),
        "llm_temperature": o.get("llm_temperature"),
        "llm_top_p": o.get("llm_top_p"),
        "llm_presence_penalty": o.get("llm_presence_penalty"),
        "llm_frequency_penalty": o.get("llm_frequency_penalty"),
        "llm_repeat_penalty": o.get("llm_repeat_penalty"),
        "llm_max_tokens": o.get("llm_max_tokens"),
        "llm_seed": o.get("llm_seed"),
        
        # LLM context
        "trending_words_shown": decode_json(o.get("trending_words_shown")) or [],
        "trending_words_all": decode_json(o.get("trending_words_all")) or [],
        "user_prompt": o.get("user_prompt"),
        "template_key": o.get("template_key"),
        "trending_words_count": int(o.get("trending_words_count") or 0),
        "name_style_target": o.get("name_style_target"),
        "persona_text": o.get("persona_text"),
        "persona_index": int(o.get("persona_index") or 0),
        "description_style": o.get("description_style"),
        "persona_weight": float(o.get("persona_weight") or 0.0),
        "style_weight": float(o.get("style_weight") or 0.0),
        
        # SD context
        "negative_prompt_variant": o.get("negative_prompt_variant"),
        "lora_disabled": lora_disabled,
        "prompt_truncated": prompt_truncated,
        "truncated_components": decode_json(o.get("truncated_components")) or [],
        
        # Keep generation_meta if present
        "generation_meta": decode_json(o.get("generation_meta")) if "generation_meta" in o else None,
    }

# Database helpers

def _compute_metrics() -> Dict[str, Any]:
    """Calculate generation metrics for WebSocket broadcast."""
    db = sqlite3.connect(str(DB_PATH), timeout=5.0)
    db.row_factory = sqlite3.Row
    configure_sqlite_connection(db, busy_ms=SQLITE_BUSY_TIMEOUT_MS)
    cur = db.cursor()
    try:
        # Total tokens
        cur.execute("SELECT COUNT(*) FROM meme_tokens")
        total = int(cur.fetchone()[0] or 0)
        
        # Last 24h
        since = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
        cur.execute("SELECT COUNT(*) FROM meme_tokens WHERE created_at >= ?", (since,))
        last_24h = int(cur.fetchone()[0] or 0)
        
        # Cat/Dog ratio
        cur.execute("SELECT lower(animal_class) ac, COUNT(*) c FROM meme_tokens GROUP BY lower(animal_class)")
        counts = {row["ac"] or "": int(row["c"] or 0) for row in cur.fetchall()}
        cats, dogs = counts.get("cat", 0), counts.get("dog", 0)
        denom = cats + dogs
        ratio = f"{round(cats*100/denom)}% / {round(dogs*100/denom)}%" if denom else "0% / 0%"
        
        # Average generation time
        N = 20
        cur.execute("""
            SELECT created_at FROM meme_tokens
            ORDER BY datetime(created_at) DESC LIMIT ?
        """, (N,))
        times = [datetime.fromisoformat(row[0]) for row in cur.fetchall() if row[0]]
        avg_gap = None
        if len(times) >= 2:
            gaps = [(times[i] - times[i+1]).total_seconds() for i in range(len(times)-1)]
            avg_gap = sum(map(abs, gaps)) / len(gaps)
        
        return {
            "tokens_generated": total,
            "gen_rate_per_24h": last_24h,
            "cat_dog_ratio": ratio,
            "avg_gen_time": round(avg_gap, 1) if avg_gap is not None else None,
        }
    finally:
        cur.close()
        db.close()

def _normalize_generation_meta(gm: Mapping[str, Any] | None) -> Dict[str, Any] | None:
    """Ensure a stable wire shape with nulls for the non-selected medium group."""
    if not gm:
        return None
    return {
        "trigger": gm.get("trigger"),
        "breed": gm.get("breed"),
        "action": gm.get("action"),
        "environment": gm.get("environment"),
        "attribute": gm.get("attribute"),
        "colour": gm.get("colour"),
        "lighting": gm.get("lighting"),
        "camera": gm.get("camera"),
        "quality": gm.get("quality"),
        "seed": gm.get("seed"),
        "medium_source": gm.get("medium_source"),
        # Style branch (or nulls)
        "style_name": gm.get("style_name"),
        "style_modifiers": gm.get("style_modifiers"),
        # Artist branch (or nulls)
        "artist_medium": gm.get("artist_medium"),
        "artist_name": gm.get("artist_name"),
    }

def generate_one() -> None:
    """Generate a single meme token."""
    start_ts = time.time()
    logger.debug("Starting new token generation cycle...")

    with token_scope():
        # Fetch trending words
        broadcast_pipeline_stage("fetch")
        broadcast_log("info", "fetching trending words...")
        words = fetch_top_words()
        if not words:
            logger.error("No words fetched - skipping this cycle")
            log_event("failure", error="no words fetched")
            return
        broadcast_top_words(words[:9])
        broadcast_log("info", f"trending words: {', '.join(words[:9])}")
        log_event("fetched_words", count=len(words))

        # Generate text with LLM
        broadcast_pipeline_stage("llm")
        broadcast_log("info", "generating token text with Mistral...")
        meta, llm_params = generate_text(words)
        
        logger.info(
            "Generated token -> Name: '{}' | Ticker: {} | Animal: {}",
            meta["name"], meta["ticker"], meta["animal"]
        )
        logger.info("Description: {}", meta["description"])
        set_trace_meta(name=meta["name"], ticker=meta["ticker"], animal=meta["animal"].lower())
        log_event(
            "generated_text",
            name=meta["name"],
            ticker=meta["ticker"],
            animal=meta["animal"].lower()
        )

        # Build SD prompt
        broadcast_pipeline_stage("prompt")
        broadcast_log("info", "building SD prompt...")
        animal = meta["animal"].lower()
        render_kwargs = sample_render_params()

        # SELECT MODEL EARLY (before build_prompt)
        model_key = select_model_key()
        logger.info("Pre-selected SD model: {}", model_key)
        log_event("model_pre_selected", model_key=model_key)

        # Extract negative prompt info from render_params
        negative_prompt_from_render = render_kwargs.get("negative_prompt")
        negative_variant_from_render = render_kwargs.get("negative_prompt_variant")
        
        # Pass model_key to build_prompt
        prompt_result = build_prompt(
            animal, 
            render_kwargs.get("seed"),
            negative_prompt=negative_prompt_from_render,
            negative_prompt_variant=negative_variant_from_render,
            model_key=model_key  # ADD THIS
        )
        
        # Extract values from prompt_result
        prompt = prompt_result["prompt"]
        negative_prompt_variant = prompt_result.get("negative_prompt_variant")
        prompt_truncated = prompt_result.get("prompt_truncated", False)
        truncated_components = prompt_result.get("truncated_components", [])       
       
        # Extract prompt_meta for generation_meta (if build_prompt is updated to return it)
        prompt_meta = prompt_result.get("generation_meta", {})
        
        set_trace_meta(
            breed=prompt_meta.get("breed"),
            medium_source=prompt_meta.get("medium_source"),
        )

        # Generate image
        broadcast_pipeline_stage("render")
        broadcast_log("info", "rendering image...")
        contract = generate_address()
        filename = f"{animal}_{meta['ticker']}_{contract}.png"
        image_path = Path(IMAGE_DIR) / filename
        set_trace_meta(contract_address=contract, filename=filename)

        logger.info(
            "Image generation params:\n"
            "  Model: {}\n"
            "  Positive: {}\n"
            "  Negative: {}\n"
            "  Steps: {}, CFG: {:.1f}, LoRA: {:.2f}",
            model_key,
            prompt,
            render_kwargs['negative_prompt'],
            render_kwargs['steps'],
            render_kwargs['cfg_scale'],
            render_kwargs['lora_scale']
        )

        log_event("built_prompt", prompt=prompt, model_key=model_key)
        log_event("render_params", **render_kwargs)
        
        # Filter parameters for image generation
        _render_keys = {"cfg_scale", "lora_scale", "steps", "seed", "negative_prompt"}
        render_call_kwargs = {k: v for k, v in render_kwargs.items() if k in _render_keys}
        
        # Pass the pre-selected model to generate_image
        used = generate_image(
            prompt, 
            str(image_path), 
            model_key=model_key,  # ADD THIS
            **render_call_kwargs
        )
        logger.info("Model used: {} | TI mode: {} | TI tokens: {}", used.get("sd_model_key"), used.get("ti_mode"), used.get("ti_tokens"))
        log_event("generated_image", filename=filename, contract_address=contract, sampler=used.get("sampler"))

        # Save to database
        broadcast_pipeline_stage("save")
        broadcast_log("info", "saving image + metadata...")
        
        # Merge render params with what was actually used
        params = {**render_kwargs, **(used or {})}
        # Ensure both base (variant) and effective (TI-prepended) negative prompts are captured
        # - negative_prompt_base: what render_params/build_prompt chose (may be None when disabled)
        # - negative_prompt: what SD actually used (with TI tokens prepended)
        params["negative_prompt_base"] = negative_prompt_from_render
        params["negative_prompt"] = used.get("negative_prompt_used", params.get("negative_prompt"))
        # Multi-model tracking
        params["sd_model_key"] = used.get("sd_model_key")
        params["ti_mode"] = used.get("ti_mode"); params["ti_tokens"] = used.get("ti_tokens")
        
        # Build generation_meta
        generation_meta: Dict[str, Any] = dict(prompt_meta or {})
        generation_meta = _normalize_generation_meta(generation_meta)
        
        # Add persona style mode to generation_meta
        generation_meta["persona_style_mode"] = llm_params.get("persona_style_mode")
        
        # Build complete token metadata with REAL values from all components
        token_meta = {
            # Core token data
            **meta,  # name, ticker, description, animal
            "animal_class": animal,
            "contract_address": contract,
            "filename": filename,
            "prompt": prompt,
            "params": params,
            "llm_params": {
                "model": llm_params.get("model"),
                "temperature": llm_params.get("temperature"),
                "top_p": llm_params.get("top_p"),
                "presence_penalty": llm_params.get("presence_penalty"),
                "frequency_penalty": llm_params.get("frequency_penalty"),
                "repeat_penalty": llm_params.get("repeat_penalty"),
                "max_tokens": llm_params.get("max_tokens"),
                "seed": llm_params.get("seed"),
            },
            "image_path": f"/images/memefactory/{filename}",
            "generation_meta": generation_meta,
            
            # LLM generation context - from llm_params
            "trending_words_shown": llm_params.get("trending_words_shown", []),
            "trending_words_all": llm_params.get("trending_words_all", words),
            "user_prompt": llm_params.get("user_prompt"),
            "template_key": llm_params.get("template_key"),
            "trending_words_count": llm_params.get("trending_words_count", 0),
            "name_style_target": llm_params.get("name_style_target"),
            "persona_text": llm_params.get("persona_text"),
            "persona_index": llm_params.get("persona_index", 0),
            "description_style": llm_params.get("description_style"),
            "persona_weight": llm_params.get("persona_weight", 0.5),
            "style_weight": llm_params.get("style_weight", 0.5),
            
            # SD generation context - from build_prompt and generate_image
            "negative_prompt_variant": negative_prompt_variant,  # Now consistent from render_params
            "lora_disabled": used.get("lora_disabled", False),
            "prompt_truncated": prompt_truncated,
            "truncated_components": truncated_components,
        }
        
        # Save to database
        token_id, created_at = save_output(token_meta, image_path.read_bytes())
        log_event("saved_output", name=meta["name"], ticker=meta["ticker"])

        logger.success(
            "Token created: {} ({}) - {} - Contract: {}",
            meta["name"], meta["ticker"], animal, contract[:8]
        )

        # Fetch the complete token from database to ensure consistency
        conn = sqlite3.connect(str(DB_PATH), timeout=5.0)
        conn.row_factory = sqlite3.Row
        configure_sqlite_connection(conn, busy_ms=SQLITE_BUSY_TIMEOUT_MS)
        try:
            cur = conn.cursor()
            cur.execute(
                """
                SELECT
                    id, name, ticker, description, contract_address, animal_class,
                    image_filename, image_path, created_at, lora_id,
                    cfg_scale, lora_scale, steps, seed, sampler, model, width, height,
                    prompt, negative_prompt, negative_prompt_base,
                    llm_model, llm_temperature, llm_top_p, llm_presence_penalty,
                    llm_frequency_penalty, llm_repeat_penalty, llm_max_tokens, llm_seed,
                    generation_meta,
                    trending_words_shown, trending_words_all, user_prompt, template_key,
                    trending_words_count, name_style_target, persona_text, persona_index, description_style,
                    persona_weight, style_weight,
                    negative_prompt_variant, lora_disabled, prompt_truncated, truncated_components
                FROM meme_tokens
                WHERE id = ?
                """,
                (token_id,)
            )
            token_row = cur.fetchone()
            
            if token_row:
                # Broadcast complete token data from database
                token_payload = serialize_token_for_wire(token_row)
                broadcast_token(token_payload)
                broadcast_log("info", f"token generated: {token_payload['ticker']} ({token_payload['animal_class']})")
            else:
                logger.error("Failed to fetch newly created token with ID: {}", token_id)
                broadcast_log("error", f"Failed to broadcast token {meta['ticker']}")
        finally:
            cur.close()
            conn.close()

        ws_broadcast_metrics(_compute_metrics())
        broadcast_pipeline_stage("idle")

        log_event("completion", duration=time.time() - start_ts)

def run_forever() -> None:
    """Main loop."""
    print("Starting Meme-Factory...  Press Ctrl+C to stop.")
    
    try:
        start_ws_server_in_thread()
    except Exception:
        logger.warning("WS server thread could not be started here; assuming external WS service.")

    while True:
        try:
            generate_one()
        except Exception as e:
            logger.exception("Generation failed: {}", e)
            broadcast_log("error", f"generation error: {e}")
            time.sleep(2.0)
        time.sleep(LOOP_DELAY_SEC)


if __name__ == "__main__":
    run_forever()