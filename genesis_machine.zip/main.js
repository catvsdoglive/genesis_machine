// main.js
import { WebSocketManager } from './websocket.js';
import { UIManager } from './ui.js';
import { APIClient } from './api.js';

class MemeFactoryApp {
   constructor() {
     this.ui = null;
     this.api = null;
     this.ws = null;
     
     this.currentFilter = 'all';
     
     this.initialized = false;
   }

   bootstrap(ui, api, ws) {
     this.ui = ui;
     this.api = api;
     this.ws = ws;
    
     this.ui.setApiClient(api);
     this.ws.onTokenReceived = (token) => this.handleIncomingToken(token);
   }

  handleIncomingToken(token) {
    this.ui.upsertTokenCard(token);
  }

  async init() {
    if (!this.ui || !this.api || !this.ws) {
      throw new Error('App not properly bootstrapped');
    }

    this.ui.initialize();
    
    this.ui.addTerminalLine('ui: genesis_machine initialized');
    
    this.ui.initializePipelineState();
    
    this.setupFilters();
		
    this.ui.initBinaryStream();
    
    this.ws.setBuffering(true);
    
    this.ws.connect();
    
    await this.loadInitialData();
    
    await this.loadSystemMetrics();
    
    this.ws.setBuffering(false);
    
    this.initialized = true;
    
    setInterval(async () => {
      if (!this.ws.isConnected()) {
        this.ui.addTerminalLine('ws: disconnected - polling fallback active', 'warning');
        
        await Promise.allSettled([
          this.loadTrendingWords(),
          this.loadMetrics(),
          this.loadRecentTokens(12),
          this.loadSystemMetrics()
        ]);
      }
    }, 60000);
    
    setInterval(async () => {
      if (!this.ws.isConnected()) {
        await this.loadSystemMetrics();
      }
    }, 5000);
       
    this.ui.hideLoading();
    this.ui.addTerminalLine('ui: consciousness loaded', 'info');
  }

  setupFilters() {
    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.filter-btn').forEach(b => 
          b.classList.remove('active')
        );
        e.target.classList.add('active');
        this.currentFilter = e.target.dataset.filter;
        this.filterTokens();
      });
    });
  }

  filterTokens() {
    const cards = document.querySelectorAll('.token-card');
    cards.forEach(card => {
      const show = this.currentFilter === 'all' || 
                   card.dataset.class === this.currentFilter;
      card.style.display = show ? '' : 'none';
    });
    
    const visibleCount = Array.from(cards).filter(c => c.style.display !== 'none').length;
    this.ui.addTerminalLine(`filter: ${this.currentFilter} (${visibleCount} tokens visible)`);
  }

  async loadInitialData() {
    try {
      const startTime = performance.now();
      
      let metrics = null;
      try {
        metrics = await this.api.getMetrics();
      } catch (e) {
        this.ui.addTerminalLine('api: metrics snapshot unavailable (HTTP)', 'warning');
      }
      
      if (metrics) {
        try {
          this.ui.renderMetrics(metrics);
        } catch (e) {
          console.error('Metrics render failed:', e);
          this.ui.addTerminalLine('metrics: render failed', 'error');
        }
      }

      const tokens = await this.api.getTokens(24, 0);
      if (Array.isArray(tokens)) {
        tokens.slice().reverse().forEach(token => {
          this.ui.upsertTokenCard(token);
        });
               
        const tokenStats = this.ui.getTokenStats();
        if (tokenStats.totalStored !== tokens.length) {
          this.ui.addTerminalLine(
            `Deduplication: ${tokens.length} REST tokens → ${tokenStats.totalStored} unique tokens`,
            'info'
          );
        }
      }
      
      await this.loadTrendingWords();
      
      const loadTime = Math.round(performance.now() - startTime);
      this.ui.addTerminalLine(`initial data loaded in ${loadTime}ms`);
      
    } catch (error) {
      this.ui.addTerminalLine(`error loading initial data: ${error.message}`, 'error');
    }
  }

  async loadTrendingWords() {
    try {
      const words = await this.api.getTrendingWords(9);
      this.ui.renderWordPool(words);
    } catch (error) {
      console.error('Failed to load trending words:', error);
      if (!this.initialized) {
        this.ui.addTerminalLine('api: failed to load trending words', 'warning');
      }
    }
  }

  async loadSystemMetrics() {
    try {
      const systemData = await this.api.getSystemStatus();
      this.ui.renderSystemMetrics(systemData);
    } catch (error) {
      console.error('Failed to load system metrics:', error);
      if (!this.initialized) {
        this.ui.addTerminalLine('metrics: system metrics unavailable', 'warning');
      }
    }
  }

  async loadMetrics() {
    try {
      const metrics = await this.api.getMetrics();
      this.ui.renderMetrics(metrics);
    } catch (error) {
      console.error('Failed to load metrics:', error);
    }
  }

  async loadRecentTokens(limit = 24) {
    try {
      const tokens = await this.api.getTokens(limit, 0);
      if (Array.isArray(tokens)) {
        let newCount = 0;
        tokens.forEach(token => {
          const key = this.ui._getTokenKey(token);
          const isNew = !this.ui.tokenStore.has(key);
          
          this.ui.upsertTokenCard(token);
          
          if (isNew) newCount++;
        });
        
        if (newCount > 0) {
          this.ui.addTerminalLine(`polling: ${newCount} new tokens found`);
        }
      }
    } catch (error) {
      console.error('Failed to load recent tokens:', error);
    }
  }

  getStats() {
    const cards = document.querySelectorAll('.token-card');
    const withId = Array.from(cards).filter(c => c._tokenId).length;
  
    return {
      totalCards: cards.length,
      cardsWithId: withId,
      filter: this.currentFilter,
      wsConnected: this.ws.isConnected(),
      initialized: this.initialized,
      uiStats: this.ui.getTokenStats()
    };
  }

  async refresh() {
    this.ui.addTerminalLine('manual refresh triggered');
    
    this.ui.tokenStore.clear();
    this.ui.cardsByKey.clear();
    this.ui.elements.tokenGrid.innerHTML = '';
    
    await this.loadInitialData();
    
    if (this.ws.tokenBuffer.length > 0) {
      this.ws.flushBuffer();
    }
    
    this.ui.addTerminalLine('refresh complete');
  }
}

window.addEventListener('DOMContentLoaded', () => {
  // Mobile detection and configuration
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
                   window.matchMedia("(max-width: 768px)").matches;
  
  if (isMobile) {
    document.body.classList.add('is-mobile');
    
    // Disable all description tooltips globally on mobile
    const style = document.createElement('style');
    style.textContent = '#global-description-tooltip { display: none !important; }';
    document.head.appendChild(style);
  }

  try {
    const ui = new UIManager();
    const api = new APIClient();
    const ws = new WebSocketManager(ui, api);
    
    const app = new MemeFactoryApp();
    app.bootstrap(ui, api, ws);
    
    window.memeApp = app;
    
    app.init().catch(error => {
      console.error('App initialization failed:', error);
      const loading = document.getElementById('loading');
      if (loading) {
        loading.innerHTML = '<div class="loading-text">INITIALIZATION FAILED - PLEASE REFRESH</div>';
      }
    });
    
  } catch (error) {
    console.error('Bootstrap failed:', error);
  }
  
  const aboutBtn = document.getElementById('btn-about');
  const aboutPopup = document.getElementById('about-popup');
  const closeBtn = document.getElementById('close-about');
  
  if (aboutBtn && aboutPopup && closeBtn) {
    aboutBtn.addEventListener('click', () => {
      aboutPopup.classList.add('active');
    });
    
    closeBtn.addEventListener('click', () => {
      aboutPopup.classList.remove('active');
    });
    
    aboutPopup.addEventListener('click', (e) => {
      if (e.target === aboutPopup) {
        aboutPopup.classList.remove('active');
      }
    });
    
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && aboutPopup.classList.contains('active')) {
        aboutPopup.classList.remove('active');
      }
    });
	
	}

  // Image viewer modal functionality
  const imageViewerModal = document.getElementById('image-viewer-modal');
  if (imageViewerModal) {
    // Handle clicks on token images
    document.addEventListener('click', (e) => {
      const tokenImage = e.target.closest('.token-image img');
      if (tokenImage && tokenImage.src) {
        const fullSizeImg = imageViewerModal.querySelector('.full-size-image');
        const modalTitle = imageViewerModal.querySelector('.image-modal-title');
        
        if (fullSizeImg) {
          fullSizeImg.src = tokenImage.src;
          
          // Get token name and ticker from the card
          const card = tokenImage.closest('.token-card');
          if (card) {
            const name = card.querySelector('.token-name')?.textContent || '';
            const ticker = card.querySelector('.token-ticker')?.textContent || '';
            if (modalTitle) {
              modalTitle.textContent = name && ticker ? `${name} (${ticker})` : 'Full Image';
            }
          }
          
          imageViewerModal.showModal();
        }
      }
    });
    
    // Close on click outside image
    imageViewerModal.addEventListener('click', (e) => {
      if (e.target === imageViewerModal || e.target.classList.contains('image-modal-body')) {
        imageViewerModal.close();
      }
    });
    
    // Close on Escape key
    imageViewerModal.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        imageViewerModal.close();
      }
    });
  }
  
  const detailsModal = document.getElementById('token-details-modal');
  if (detailsModal) {
    detailsModal.addEventListener('click', (e) => {
      if (e.target === detailsModal) {
        detailsModal.close();
      }
    });
    
	detailsModal.addEventListener('close', () => {
	  if (window.memeApp && window.memeApp.ui && window.memeApp.ui.currentModalCard) {
		window.memeApp.ui.currentModalCard = null;
	  }
	});

	detailsModal.addEventListener('keydown', (e) => {
	  if (e.key === 'Escape' && window.memeApp && window.memeApp.ui && window.memeApp.ui.currentModalCard) {
		window.memeApp.ui.currentModalCard = null;
	  }
	});
  }
  
  function makeDraggable(element, handleSelector) {
    const handle = element.querySelector(handleSelector);
    if (!handle) return;
    
    let isDragging = false;
    let startX, startY;
    let initialLeft, initialTop;
    
    const storageKey = `position_${element.className.split(' ')[0]}`;
    
    const savedPosition = localStorage.getItem(storageKey);
    if (savedPosition) {
      try {
        const { left, top } = JSON.parse(savedPosition);
        const leftNum = parseInt(left);
        const topNum = parseInt(top);
        
        const rect = element.getBoundingClientRect();
        const maxLeft = window.innerWidth - rect.width;
        const maxTop = window.innerHeight - rect.height;
        
        if (!isNaN(leftNum) && !isNaN(topNum) && 
            leftNum >= 0 && topNum >= 0 && 
            leftNum <= maxLeft && topNum <= maxTop) {
          element.style.left = left;
          element.style.top = top;
          element.style.right = 'auto';
          element.style.bottom = 'auto';
        } else {
          localStorage.removeItem(storageKey);
          console.warn(`Invalid saved position for ${storageKey}, using defaults`);
        }
      } catch (e) {
        localStorage.removeItem(storageKey);
        console.error(`Corrupted position data for ${storageKey}:`, e);
      }
    }
    
    handle.addEventListener('mousedown', (e) => {
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      
      const rect = element.getBoundingClientRect();
      initialLeft = rect.left;
      initialTop = rect.top;
      
      element.style.left = initialLeft + 'px';
      element.style.top = initialTop + 'px';
      element.style.right = 'auto';
      element.style.bottom = 'auto';
      
      element.style.zIndex = '10000';
      element.style.opacity = '0.9';
      handle.style.cursor = 'grabbing';
      
      e.preventDefault();
    });
    
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      
      const deltaX = e.clientX - startX;
      const deltaY = e.clientY - startY;
      
      let newLeft = initialLeft + deltaX;
      let newTop = initialTop + deltaY;
      
      const rect = element.getBoundingClientRect();
      const maxLeft = window.innerWidth - rect.width;
      const maxTop = window.innerHeight - rect.height;
      
      newLeft = Math.max(0, Math.min(newLeft, maxLeft));
      newTop = Math.max(0, Math.min(newTop, maxTop));
      
      element.style.left = newLeft + 'px';
      element.style.top = newTop + 'px';
    });
    
    document.addEventListener('mouseup', () => {
      if (!isDragging) return;
      
      isDragging = false;
      
      element.style.zIndex = '';
      element.style.opacity = '';
      handle.style.cursor = 'move';
      
      const finalLeft = parseInt(element.style.left);
      const finalTop = parseInt(element.style.top);
      
      if (!isNaN(finalLeft) && !isNaN(finalTop) && 
          finalLeft >= 0 && finalTop >= 0) {
        const position = {
          left: element.style.left,
          top: element.style.top
        };
        localStorage.setItem(storageKey, JSON.stringify(position));
      } else {
        console.warn(`Invalid position detected, not saving: left=${finalLeft}, top=${finalTop}`);
      }
    });
  }
  
  const resourceMonitor = document.querySelector('.resource-monitor');
  const trendingWords = document.querySelector('.trending-words');
  
  if (resourceMonitor) {
    makeDraggable(resourceMonitor, '.resource-header');
  }
  
  if (trendingWords) {
    makeDraggable(trendingWords, '.trending-header');
  }
  
  document.addEventListener('keydown', (e) => {
    if (e.key === 'F5' && (e.shiftKey || e.ctrlKey)) {
      localStorage.removeItem('position_resource-monitor');
      localStorage.removeItem('position_trending-words');
      console.log('Window positions cleared - reloading...');
    }
  });
  
  window.addEventListener('resize', () => {
    const resourceMonitor = document.querySelector('.resource-monitor');
    const trendingWords = document.querySelector('.trending-words');
    
    [resourceMonitor, trendingWords].forEach(element => {
      if (!element) return;
      
      const rect = element.getBoundingClientRect();
      
      if (rect.right < 0 || rect.bottom < 0 || 
          rect.left > window.innerWidth || rect.top > window.innerHeight) {
        element.style.left = '';
        element.style.top = '';
        element.style.right = '20px';
        element.style.bottom = '20px';
        
        const storageKey = `position_${element.className.split(' ')[0]}`;
        localStorage.removeItem(storageKey);
        
        console.warn(`Reset ${element.className} position due to window resize`);
      }
    });
  });
  
  document.addEventListener('click', (e) => {
    if (e.target.closest('#token-details-modal')) {
      const el = e.target.closest('.expandable');
      if (el) el.classList.toggle('expanded');
    }
    
	const detailsBtn = e.target.closest('.token-details-btn');
	if (detailsBtn) {
	  const card = detailsBtn.closest('.token-card');
	  if (card && card._tokenFields) {
		window.memeApp.ui.openDetailsModal(card, card._tokenFields);  // Use window.memeApp
	  }
	}
  });
});