# system_monitor.py
"""Shared system monitoring utilities."""

import os
import time
from typing import Dict, Tuple, Any

def read_proc_meminfo() -> Dict[str, int]:
    """Read /proc/meminfo and return parsed values."""
    data: Dict[str, int] = {}
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as f:
            for line in f:
                if ":" not in line:
                    continue
                k, v = line.split(":", 1)
                try:
                    data[k] = int(v.strip().split()[0]) * 1024  # kB to bytes
                except Exception:
                    continue
    except Exception:
        pass
    return data

def get_memory_stats() -> Dict[str, Any]:
    """Get memory statistics."""
    mi = read_proc_meminfo()
    total = mi.get("MemTotal", 0)
    available = mi.get("MemAvailable", mi.get("MemFree", 0) + mi.get("Buffers", 0) + mi.get("Cached", 0))
    used = max(0, total - available)
    used_pct = float((used / total) * 100.0) if total else 0.0
    return {
        "total_bytes": int(total),
        "used_bytes": int(used),
        "available_bytes": int(available),
        "used_percent": used_pct
    }

def read_cpu_times() -> Tuple[int, int]:
    """Read CPU times from /proc/stat."""
    try:
        with open("/proc/stat", "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("cpu "):
                    parts = line.split()
                    vals = [int(x) for x in parts[1:]]
                    user, nice, system, idle, iowait, irq, softirq = vals[:7]
                    steal = vals[7] if len(vals) >= 8 else 0
                    idle_all = idle + iowait
                    nonidle = user + nice + system + irq + softirq + steal
                    total = idle_all + nonidle
                    return (idle_all, total)
    except Exception:
        pass
    return (0, 0)

def get_cpu_usage_percent(interval: float = 0.1) -> float:
    """Calculate CPU usage percentage."""
    i1, t1 = read_cpu_times()
    time.sleep(max(0.0, interval))
    i2, t2 = read_cpu_times()
    d_idle = i2 - i1
    d_total = t2 - t1
    if d_total <= 0:
        return 0.0
    return float(100.0 * (1.0 - (d_idle / d_total)))

def get_uptime_seconds() -> float:
    """Get system uptime in seconds."""
    try:
        with open("/proc/uptime", "r", encoding="utf-8") as f:
            return float(f.read().split()[0])
    except Exception:
        return 0.0

def get_load_average() -> Tuple[float, float, float]:
    """Get system load averages."""
    try:
        return os.getloadavg()
    except Exception:
        return (0.0, 0.0, 0.0)