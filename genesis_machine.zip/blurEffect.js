// blurEffect.js

// Add the necessary CSS styles dynamically
const style = document.createElement('style');
style.textContent = `
    /* Blur effect styles */
    .blurred {
        filter: blur(11px);
        transition: filter 0.5s ease;
    }
    body.blurred {
        pointer-events: none; /* Disable interaction while blurred */
    }

    /* Reset button styles */
    #reset-blur {
        display: none;
        position: fixed;
        top: 10px;
        right: 10px;
        padding: 10px 20px;
        font-size: 16px;
        background-color: rgba(255, 255, 255, 0.8);
        color: #333;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        z-index: 1000;
        transition: background-color 0.3s ease;
    }
    #reset-blur:hover {
        background-color: rgba(200, 200, 200, 0.8);
    }
`;
document.head.appendChild(style);

// Function to blur everything after 1 minute
setTimeout(() => {
    document.body.classList.add('blurred');

    // Show reset button when blur is applied
    const resetButton = document.getElementById('reset-blur');
    if (resetButton) {
        resetButton.style.display = 'block';
    }
}, 10000); // 1 minute

// Reset blur functionality
document.addEventListener('DOMContentLoaded', () => {
    const resetButton = document.createElement('button');
    resetButton.id = 'reset-blur';
    resetButton.textContent = 'Reset Blur';
    document.body.appendChild(resetButton);

    resetButton.addEventListener('click', () => {
        document.body.classList.remove('blurred');
        resetButton.style.display = 'none'; // Hide the button after reset
    });
});
