# ws_server.py
"""
WebSocket server for real-time updates to frontend clients.
Broadcasts pipeline status, tokens, metrics, and operator messages.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from typing import Set

import websockets
from websockets.server import WebSocketServerProtocol
import random
from operator_messages import get_random_operator_message

from config import (
    OPERATOR_MSG_MIN_INTERVAL,
    OPERATOR_MSG_MAX_INTERVAL,
    OPERATOR_MSG_ENABLED,
    MEME_WS_HOST, 
    MEME_WS_PORT 
)

from system_monitor import (
    get_memory_stats,
    get_cpu_usage_percent, 
    get_uptime_seconds,
    get_load_average
)

# Server configuration
WS_HOST = MEME_WS_HOST
WS_PORT = MEME_WS_PORT
WS_PATHS = {"/ws", "/ws/"}

# Heartbeat configuration (ms)
APP_HEARTBEAT_MS = int(float(os.getenv("MEME_WS_HEARTBEAT_MS", "25000")))
PING_INTERVAL = 25
PING_TIMEOUT = 30

# Global state
_clients: Set[WebSocketServerProtocol] = set()
_broadcast_queue: asyncio.Queue = asyncio.Queue(maxsize=2000)
_loop: asyncio.AbstractEventLoop | None = None
_last_pipeline_stage: str | None = None

logger = logging.getLogger("memefactory.ws")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

# Broadcasting functions (thread-safe)
def publish_nowait(message: dict) -> None:
    """Queue message for broadcast. Drops silently if queue full."""
    try:
        if _loop and _loop.is_running():
            _loop.call_soon_threadsafe(_broadcast_queue.put_nowait, message)
        else:
            _broadcast_queue.put_nowait(message)
    except asyncio.QueueFull:
        logger.warning("Broadcast queue full; dropping message: %s", message.get("type"))

def broadcast_pipeline_stage(stage: str) -> None:
    global _last_pipeline_stage
    _last_pipeline_stage = stage
    publish_nowait({"type": "pipeline", "stage": stage})

def broadcast_token(data: dict) -> None:
    publish_nowait({"type": "token", "data": data})

def broadcast_metrics(data: dict) -> None:
    publish_nowait({"type": "metrics", "data": data})

def broadcast_system_metrics(data: dict) -> None:
    """Send system metrics with 'kind' discriminator."""
    publish_nowait({"type": "metrics", "data": {"kind": "system", **data}})

def broadcast_top_words(words: list[str]) -> None:
    publish_nowait({"type": "top_words", "words": list(words or [])})

def broadcast_log(level: str, message: str) -> None:
    publish_nowait({"type": "log", "level": level, "message": str(message)})

async def _system_metrics_loop(period: float = 2.0) -> None:
    """Periodically broadcast system metrics."""
    while True:
        try:
            l1, l5, l15 = get_load_average()
            payload = {
                "cpu": {"usage_percent": round(get_cpu_usage_percent(0.1), 2)},
                "mem": get_memory_stats(),
                "load": {"load_avg_1m": l1, "load_avg_5m": l5, "load_avg_15m": l15},  # ← Remove float()
                "uptime_seconds": get_uptime_seconds(),
            }
            broadcast_system_metrics(payload)
        except Exception:
            pass
        await asyncio.sleep(period)

async def _operator_message_loop() -> None:
    """Send operator consciousness messages at random intervals."""
    if not OPERATOR_MSG_ENABLED:
        logger.info("Operator consciousness messages disabled")
        return
    
    await asyncio.sleep(10)
    logger.info("Operator consciousness activated")
    
    while True:
        # Mood-based timing variation
        mood_factor = random.random()
        if mood_factor < 0.1:  # Rapid thoughts
            wait_time = random.uniform(5, 15)
        elif mood_factor < 0.3:  # Contemplative
            wait_time = random.uniform(
                OPERATOR_MSG_MAX_INTERVAL, 
                OPERATOR_MSG_MAX_INTERVAL * 1.5
            )
        else:  # Normal
            wait_time = random.uniform(
                OPERATOR_MSG_MIN_INTERVAL, 
                OPERATOR_MSG_MAX_INTERVAL
            )
        
        await asyncio.sleep(wait_time)
        
        try:
            message = get_random_operator_message()
            publish_nowait({"type": "log", "level": "info", "message": message, "file": "operator_messages.py"})
        except Exception as e:
            logger.error(f"Error in operator message loop: {e}")

async def _broadcast_worker() -> None:
    """Fan out queued messages to all connected clients."""
    while True:
        msg = await _broadcast_queue.get()
        data = json.dumps(msg, ensure_ascii=False)
        dead: list[WebSocketServerProtocol] = []
        for ws in list(_clients):
            try:
                await ws.send(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            try:
                await ws.close()
            finally:
                _clients.discard(ws)
        _broadcast_queue.task_done()

async def _handle_client(ws: WebSocketServerProtocol) -> None:
    """Handle individual WebSocket client connection."""
    path = ws.path if hasattr(ws, 'path') else '/ws'
    
    if path not in WS_PATHS:
        await ws.close(code=1008, reason="Invalid WS path")
        return

    _clients.add(ws)
    logger.info("WebSocket connected: %s", getattr(ws, "remote_address", "-"))

    try:
        # Send hello with current state
        hello_msg = {
            "type": "hello",
            "pong_capable": True,
            "heartbeat_ms": APP_HEARTBEAT_MS,
            "current_stage": _last_pipeline_stage
        }
        
        if _last_pipeline_stage and _last_pipeline_stage != "idle":
            hello_msg["message"] = f"hello, this is the genesis_machine operator speaking. the current production phase is {_last_pipeline_stage.upper()}"
        else:
            hello_msg["message"] = "hello, this is the genesis_machine operator speaking. production pipeline is idle."
        
        await ws.send(json.dumps(hello_msg))
        
        # Sync pipeline state
        if _last_pipeline_stage:
            await ws.send(json.dumps({
                "type": "pipeline",
                "stage": _last_pipeline_stage,
                "replayed": True
            }))

        # Handle incoming messages
        async for raw in ws:
            try:
                payload = json.loads(raw)
            except Exception:
                continue

            if isinstance(payload, dict) and payload.get("type") == "ping":
                try:
                    client_t = payload.get("t")
                    await ws.send(json.dumps({
                        "type": "pong",
                        "t": client_t,
                        "server_ts": int(time.time() * 1000)
                    }))
                except Exception:
                    pass
    except Exception:
        pass
    finally:
        _clients.discard(ws)
        logger.info("WebSocket disconnected: %s", getattr(ws, "remote_address", "-"))

async def _serve(host: str | None = None, port: int | None = None) -> None:
    """Main server loop."""
    global _loop
    h = host or WS_HOST
    p = port or WS_PORT    
    _loop = asyncio.get_running_loop()    
    async with websockets.serve(
        _handle_client,
        h,
        p,        
        ping_interval=PING_INTERVAL,
        ping_timeout=PING_TIMEOUT,
        max_queue=64,
    ):
        logger.info("WS server listening on %s:%d (paths: %s)", h, p, ", ".join(WS_PATHS))
        bw = asyncio.create_task(_broadcast_worker())
        sysloop = asyncio.create_task(_system_metrics_loop())
        oploop = asyncio.create_task(_operator_message_loop())
        try:
            await asyncio.Future()  # Run forever
        finally:
            bw.cancel()
            sysloop.cancel()
            oploop.cancel()

def start_ws_server_in_thread(host: str | None = None, port: int | None = None) -> None:
    """Start WebSocket server in a background thread."""
    import threading

    h = host or WS_HOST
    p = port or WS_PORT

    def _runner():
        asyncio.run(_serve(host, port))

    t = threading.Thread(target=_runner, name="ws-server", daemon=True)
    t.start()
    logger.info("WS server thread started on %s:%d", h, p)

if __name__ == "__main__":
    asyncio.run(_serve())