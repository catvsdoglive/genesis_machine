# metrics.py
"""
Emits per-run metrics (counts, failures, timings) as JSON Lines to a .jsonl file.
Adds:
  - trace_id (per-token) using contextvars
  - generation_start / generation_end events
  - token-scoped context via set_trace_meta(**kv) replicated onto all events
  - optional pretty sidecar log for humans (no impact on strict JSONL)
"""

import json, os, secrets, time
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from memelogging import logger
from config import METRICS_PATH

# Per-token context
_TRACE_ID: ContextVar[str | None] = ContextVar("trace_id", default=None)
_TRACE_META: ContextVar[dict] = ContextVar("trace_meta", default={})

def set_trace_meta(**kv) -> None:
    """
    Attach stable fields (e.g., name/ticker/animal/adjective/style/composition/colour/contract_address/filename)
    to all subsequent events in the current token scope.
    """
    cur = dict(_TRACE_META.get() or {})
    cur.update({k: v for k, v in kv.items() if v is not None})
    _TRACE_META.set(cur)

def _get_trace_id() -> str | None:
    return _TRACE_ID.get()

def _get_trace_meta() -> dict:
    return dict(_TRACE_META.get() or {})

# Optional human-friendly pretty log (keeps JSONL untouched)
_PRETTY_PATH = Path(os.getenv("METRICS_PRETTY_PATH") or (str(METRICS_PATH) + ".pretty.log"))

def _write_pretty(entry: dict) -> None:
    try:
        _PRETTY_PATH.parent.mkdir(parents=True, exist_ok=True)
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(entry["timestamp"]))
        rid = entry.get("trace_id", "-")
        with open(_PRETTY_PATH, "a", encoding="utf-8") as pf:
            pf.write(f"\n--- {ts} • {entry['event']} • {rid} ---\n")
            pf.write(json.dumps(entry, indent=2, ensure_ascii=False))
            pf.write("\n")
    except Exception:
        logger.exception("Failed to write pretty metrics line")

def log_event(event: str, **data) -> None:
    """
    Append a JSON line metric to METRICS_PATH.
    Args:
        event: name of the event (e.g., 'token_generated', 'failure')
        **data: additional key/value pairs to include in the metric
    """
    entry = {
        "timestamp": time.time(),
        "event": event,
        **_get_trace_meta(),
        **data,
    }
    rid = _get_trace_id()
    if rid:
        entry["trace_id"] = rid
    
    try:
        with open(METRICS_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        logger.exception("Failed to write metric: {}", entry)
    
    # Sidecar pretty log for humans (non-blocking if it fails)
    try:
        _write_pretty(entry)
    except Exception:
        pass

@contextmanager
def token_scope(run_id: str | None = None, **initial_meta):
    """
    Context manager marking the boundaries of a single token generation cycle.
    Every event inside will carry the same trace_id and merged meta.
    """
    rid = run_id or secrets.token_hex(8)
    tok = f"run:{rid}"
    prev_id = _TRACE_ID.set(tok)
    prev_meta = _TRACE_META.set(initial_meta or {})
    try:
        log_event("generation_start")
        yield tok
        log_event("generation_end")
    finally:
        _TRACE_ID.reset(prev_id)
        _TRACE_META.reset(prev_meta)