# image_generator.py

from __future__ import annotations

import gc
import os
import random
import time
import threading
from pathlib import Path
from collections import OrderedDict

import torch
from diffusers import StableDiffusionPipeline
from diffusers import (
    DPMSolverMultistepScheduler,
    EulerAncestralDiscreteScheduler
)
from memelogging import logger

# Compel TI manager
from compel import Compel
from compel import DiffusersTextualInversionManager 

# Optional metrics import with fallback
try:
    from metrics import log_event
except Exception:
    def log_event(*args, **kwargs):
        pass

from config import (
    LORA_FILE,
    SD_V1_5_PATH, SD_V1_4_PATH, SD_V2_1_PATH,
    SD_SEED,
    IMG_HEIGHT,
    IMG_WIDTH,
    SKIP_WARMUP,
    SKIP_LORA,
    DEVICE,
    RANDOM_LORA_DISABLE_PROB
)
from config import (
    ENABLE_MULTI_MODEL,
    SD_PIPELINE_CACHE_SIZE,
    SD_FORCE_MODEL,
    MODEL_FALLBACK_POLICY, 
    MODEL_QUARANTINE_SEC, 
    MODEL_SWITCH_COALESCE_MS
)

# -------------------------------------------------------------------
# Textual inversion configuration + cache
# -------------------------------------------------------------------
from config import TI_DIR, TI_EMBEDDINGS

# DEBUG: Log TI config loaded from config.py
logger.info("=== TI CONFIG LOADED FROM CONFIG ===")
logger.info("  TI_DIR: {}", TI_DIR)
logger.info("  TI_EMBEDDINGS: {}", TI_EMBEDDINGS)

_TI_SPEC_ENV = TI_EMBEDDINGS

def _parse_ti_spec(spec: str) -> list[tuple[str, Path]]:
    out: list[tuple[str, Path]] = []
    for part in (p.strip() for p in spec.split(";") if p.strip()):
        token, filename = (s.strip() for s in part.split(":", 1))
        out.append((token, TI_DIR / filename))
    return out

_TI_SPECS: list[tuple[str, Path]] = _parse_ti_spec(_TI_SPEC_ENV)

# DEBUG: Log parsed TI specs
logger.info("=== PARSED {} TI SPECS ===", len(_TI_SPECS))
for token, path in _TI_SPECS:
    logger.info("  {} -> {} (exists: {})", token, path, path.exists())

# Per-pipeline guard to avoid re-loading
_TI_PIPE_IDS_LOADED: set[int] = set()
_TI_LOCK = threading.Lock()

def _ensure_textual_inversions_loaded(pipe: StableDiffusionPipeline) -> None:
    """
    Load all TI embeddings into the given pipeline exactly once.
    Safe for repeated calls across threads.
    """
    # Skip TI loading for non-CLIP-L/14 encoders (e.g., SD 2.x uses OpenCLIP with hidden_size=1024)
    try:
        enc_cfg = getattr(getattr(pipe, "text_encoder", None), "config", None)
        hidden_size = getattr(enc_cfg, "hidden_size", None)
        if hidden_size is not None and int(hidden_size) != 768:
            logger.info("Skipping TI load: encoder hidden_size={} (expected 768 for SD1.x)", hidden_size)
            return
    except Exception:
        # Best-effort guard; fall through to old behavior if detection fails
        pass

    logger.info("=== _ensure_textual_inversions_loaded CALLED ===")
    pid = id(pipe)
    logger.info("  Pipeline ID: {}", pid)
    logger.info("  Already loaded IDs: {}", _TI_PIPE_IDS_LOADED)
    
    if pid in _TI_PIPE_IDS_LOADED:
        logger.info("  Pipeline {} already has TI loaded, skipping", pid)
        return
    with _TI_LOCK:
        if pid in _TI_PIPE_IDS_LOADED:
            return

        logger.info("  Loading TI embeddings for pipeline {}", pid)
        loaded: list[str] = []
        for token, path in _TI_SPECS:
            logger.info("  Attempting to load {} from {}", token, path)
            if not path.exists():
                logger.warning("TI file missing: %s (token=%s) – skipping", path, token)
                continue

            try:
                pipe.load_textual_inversion(
                    str(path),
                    token=token,
                    local_files_only=True,
                )
                loaded.append(token)
                logger.info("    Successfully loaded {}", token)
            except Exception as e:
                logger.exception("Failed to load TI %s from %s: %s", token, path, e)

        _TI_PIPE_IDS_LOADED.add(pid)
        if loaded:
            logger.info("=== LOADED TEXTUAL INVERSIONS: {} ===", ", ".join(loaded))
        else:
            logger.warning("=== NO TEXTUAL INVERSIONS WERE LOADED ===")

# -------------------------------------------------------------------
# Existing globals
# -------------------------------------------------------------------
# Per-pipeline Compel cache (keyed by id(pipe))
_COMPEL_BY_PIPE_ID: dict[int, Compel] = {}
# LRU cache for multi-model pipelines
_PIPE_CACHE: OrderedDict[str, StableDiffusionPipeline] = OrderedDict()
_PIPE_LOCK = threading.Lock()

# Singleflight coordination globals
_SWITCH_CV = threading.Condition(_PIPE_LOCK)
_SWITCH_INPROGRESS = False
_SWITCH_TARGET: str | None = None
_SWITCH_STARTED_AT = 0.0
_LAST_GOOD: tuple[str | None, object | None] = (None, None)  # (model_key, pipe)
_BROKEN_UNTIL: dict[str, float] = {}  # model_key -> unix_ts

# Scheduler options with accurate naming
_SCHEDULERS = (
    ("dpm_solver_multistep", DPMSolverMultistepScheduler),
    ("euler_a", EulerAncestralDiscreteScheduler),
)

# -------------------------------------------------------------------
# Helper functions for singleflight/quarantine
# -------------------------------------------------------------------
def _now() -> float:
    return time.monotonic()

def _is_quarantined(model_key: str) -> bool:
    until = _BROKEN_UNTIL.get(model_key, 0.0)
    return until > time.time()

def _quarantine(model_key: str) -> None:
    _BROKEN_UNTIL[model_key] = time.time() + MODEL_QUARANTINE_SEC
    logger.warning("Quarantined model %s for %d sec", model_key, MODEL_QUARANTINE_SEC)

# -------------------------------------------------------------------
# MODIFIED: Compel factory – now always attaches a TI manager
# -------------------------------------------------------------------
def _get_compel(pipe: StableDiffusionPipeline) -> Compel:
    """
    Return a Compel instance bound to THIS pipeline's tokenizer/text_encoder.
    Cached per-pipeline-id to avoid cross-pipe misuse when models switch.
    """
    pid = id(pipe)
    inst = _COMPEL_BY_PIPE_ID.get(pid)
    if inst is not None:
        return inst
    logger.info("=== Creating Compel with TI manager (pipe id={}) ===", pid)
    ti_mgr = DiffusersTextualInversionManager(pipe)
    inst = Compel(
        tokenizer=pipe.tokenizer,
        text_encoder=pipe.text_encoder,
        textual_inversion_manager=ti_mgr,
        truncate_long_prompts=True,   # Let Compel split/limit correctly for each text encoder
    )
    _COMPEL_BY_PIPE_ID[pid] = inst
    return inst

def _select_scheduler_random(pipe: StableDiffusionPipeline) -> str:
    """
    Randomly select scheduler with 50/50 probability (independent of CFG).
    Pure chaos - no dependency on any parameter values.
    """
    name, cls = random.choice(_SCHEDULERS)
    try:
        pipe.scheduler = cls.from_config(pipe.scheduler.config)
        logger.debug("Random scheduler selected: {}", name)
    except Exception as e:
        logger.warning("Scheduler swap failed: %s", e)
        name = "default"
    return name

def _compile_module(module: torch.nn.Module) -> torch.nn.Module:
    """CPU-only compile helper; returns the (possibly) compiled module."""
    try:
        return torch.compile(module, backend="inductor", mode="max-autotune")
    except Exception as err:
        logger.warning("torch.compile failed – running unoptimised: {}", err)
        return module

# Compose negative prompt with a chosen subset of TI tokens
def _prepend_ti_tokens(neg: str | None, selected_tokens: list[str]) -> str:
    """Prepend SELECTED TI tokens to the negative prompt."""
    logger.info("=== _prepend_ti_tokens CALLED (selected: {}) ===", selected_tokens)
    ti_prefix = ", ".join([t for t in selected_tokens if isinstance(t, str) and t.strip()])
    neg = (neg or "").strip()
    if not ti_prefix:
        return neg
    result = f"{ti_prefix}, {neg}" if neg else ti_prefix
    logger.info("  FINAL negative with TI: {}", result[:150])
    return result

_TI_AVAILABLE = {token for token, path in _TI_SPECS if path.exists()}

def _select_model_key() -> str:
    """Return 'sd15' | 'sd14' | 'sd21' according to env and uniform rule."""
    if not ENABLE_MULTI_MODEL:
        return "sd15"
    forced = (SD_FORCE_MODEL or "").strip().lower()
    if forced in {"sd15", "sd14", "sd21"}:
        return forced
    return random.choice(("sd15", "sd14", "sd21"))

def _select_ti_tokens_for_model(model_key: str) -> tuple[list[str], str]:
    """Model-aware TI selection policy."""
    if model_key in {"sd15", "sd14"}:
        use_easy = (random.random() < 0.5) and ("EasyNegative" in _TI_AVAILABLE)
        return (["EasyNegative"] if use_easy else []), ("sd15:EasyNegative" if use_easy else "sd15:plain")
    # SD 2.1 uses OpenCLIP; 1.x TI embeddings are not compatible → do not use TI
    if model_key == "sd21":
        return [], "sd21:plain"
    return [], f"{model_key}:plain"

def _warm_up(pipe: StableDiffusionPipeline, device: torch.device) -> None:
    """Run a tiny 64×64 inference to trigger compilation then free memory."""
    try:
        logger.debug("Warm-up compile pass (64 × 64 latent)…")
        with torch.inference_mode():
            pipe("warm-up", num_inference_steps=1, height=64, width=64)
        
        gc.collect()
        if device.type == "cuda":
            torch.cuda.empty_cache()
        logger.debug("Warm-up done; cache cleared")
    except Exception as err:
        logger.warning("Warm-up failed (non-critical): {}", err)

# SD pipeline builder from a directory checkpoint with optional LoRA
def _build_pipe_dir(base_path: Path, *, with_lora: bool, allow_lora: bool) -> StableDiffusionPipeline:
    """Internal: build a SD pipeline from a directory checkpoint; optionally load LoRA (when allowed)."""
    device = torch.device(DEVICE)
    dtype = torch.float16 if device.type == "cuda" else torch.float32

    logger.info("Loading SD checkpoint ▸ {} …", base_path)
    pipe = StableDiffusionPipeline.from_pretrained(
        Path(base_path),
        torch_dtype=dtype,
        safety_checker=None,
        local_files_only=True,
    ).to(device)

    # Optionally apply LoRA weights
    if with_lora and allow_lora:
        if SKIP_LORA:
            logger.info("SKIP_LORA=true → forcing base pipe without LoRA")
        elif LORA_FILE and Path(LORA_FILE).is_file():
            logger.info("Applying LoRA weights ▸ {}", LORA_FILE)
            pipe.load_lora_weights(str(LORA_FILE))
        else:
            logger.warning("LoRA not available (file missing) → using base pipe")

    # Load TI weights *once per pipeline instance*
    logger.info("=== CALLING _ensure_textual_inversions_loaded from _build_pipe_dir ===")
    _ensure_textual_inversions_loaded(pipe)

    # CPU optimizations (same for both pipes)
    if device.type == "cpu" and not SKIP_WARMUP:
        pipe.unet = _compile_module(pipe.unet)
        pipe.vae = _compile_module(pipe.vae)
        logger.info("torch.compile CPU optimisations enabled")
        _warm_up(pipe, device)
    else:
        logger.debug("SKIP_WARMUP=true → skipping compile & warm-up on CPU")
    return pipe

def _cache_key(model_key: str, with_lora: bool) -> str:
    return f"{model_key}{'+lora' if (model_key=='sd15' and with_lora) else ''}"

def _dispose_pipe(pipe: StableDiffusionPipeline) -> None:
    """Best-effort disposal for a pipeline instance (observable, non-crashing)."""
    pid = id(pipe)
    was_loaded = (pid in _TI_PIPE_IDS_LOADED)
    _TI_PIPE_IDS_LOADED.discard(pid)   # discard never raises
    logger.debug("Disposed pipe %s (ti_was_loaded=%s)", pid, was_loaded)
    
    _COMPEL_BY_PIPE_ID.pop(pid, None)
    
    try:
        del pipe
    except Exception as e:
        logger.warning("Pipe deletion raised (ignored): %s", e, exc_info=True)
    
    gc.collect()
    if torch.cuda.is_available():
        try:
            torch.cuda.empty_cache()
        except Exception:
            pass

def _build_model_specific_pipe(model_key: str, with_lora: bool = False) -> StableDiffusionPipeline:
    """Build pipeline for specific model key."""
    if model_key == "sd15":
        return _build_pipe_dir(Path(SD_V1_5_PATH), with_lora=with_lora, allow_lora=True)
    elif model_key == "sd14":
        # SD 1.4: base pipe from directory; do not apply SD1.5 LoRA
        return _build_pipe_dir(Path(SD_V1_4_PATH), with_lora=False, allow_lora=False)
    elif model_key == "sd21":
        # SD 2.1: base pipe from directory; OpenCLIP encoder, no TI/LoRA
        return _build_pipe_dir(Path(SD_V2_1_PATH), with_lora=False, allow_lora=False)
    else:
        raise ValueError(f"Unknown model_key: {model_key}")

def _fallback_or_raise(bad_key: str, cause: Exception):
    """Handle fallback when model loading fails."""
    policy = MODEL_FALLBACK_POLICY
    if policy == "last_good" and _LAST_GOOD[1] is not None:
        logger.error("FALLBACK last_good → %s (from %s)", _LAST_GOOD[0], bad_key)
        return _LAST_GOOD[1]
    if policy == "sd15":
        try:
            logger.error("FALLBACK sd15 (from %s)", bad_key)
            return _build_model_specific_pipe("sd15")
        except Exception as e:
            logger.exception("Fallback sd15 failed: %s", e)
    # none or no fallback available
    raise cause

def _get_or_build_pipe(model_key: str, *, with_lora: bool) -> StableDiffusionPipeline:
    """
    Singleflight + coalescing + bounded fallback.
    Ensures only one expensive build per target model; others wait & share.
    """
    global _LAST_GOOD, _SWITCH_INPROGRESS, _SWITCH_TARGET, _SWITCH_STARTED_AT
    
    # 1) Honor quarantine early
    if _is_quarantined(model_key):
        logger.error("Model %s is quarantined; refusing to load", model_key)
        return _fallback_or_raise(model_key, RuntimeError("model quarantined"))

    # 2) Check cache first
    key = _cache_key(model_key, with_lora)
    
    with _PIPE_LOCK:
        # If pipe already in cache, return it
        pipe = _PIPE_CACHE.get(key)
        if pipe is not None:
            _PIPE_CACHE.move_to_end(key)
            return pipe
        
        # 3) Coalesce if a switch is already running
        if _SWITCH_INPROGRESS:
            # Same target → wait until switch completes
            if _SWITCH_TARGET == key:
                logger.debug("Coalescing: waiting for in-flight switch to %s", key)
                _SWITCH_CV.wait(timeout=MODEL_SWITCH_COALESCE_MS / 1000.0)
                # Recheck cache
                pipe = _PIPE_CACHE.get(key)
                if pipe is not None:
                    _PIPE_CACHE.move_to_end(key)
                    return pipe
            else:
                # Different target → brief wait to avoid flip-flop
                _SWITCH_CV.wait(timeout=MODEL_SWITCH_COALESCE_MS / 1000.0)
                pipe = _PIPE_CACHE.get(key)
                if pipe is not None:
                    _PIPE_CACHE.move_to_end(key)
                    return pipe
        
        # 4) Promote this caller to leader to perform the switch
        _SWITCH_INPROGRESS = True
        _SWITCH_TARGET = key
        _SWITCH_STARTED_AT = _now()
    
    # 5) Build outside the lock (expensive)
    try:
        pipe = _build_model_specific_pipe(model_key, with_lora)
        err = None
    except Exception as e:
        logger.exception("Model load failed for %s: %s", model_key, e)
        _quarantine(model_key)
        pipe = _fallback_or_raise(model_key, e)
        err = e
    
    # 6) Publish result & notify waiters
    with _PIPE_LOCK:
        if pipe and err is None:
            _PIPE_CACHE[key] = pipe
            _PIPE_CACHE.move_to_end(key)
            # Remember last good for fallback policy
            _LAST_GOOD = (key, pipe)
            
            # Evict oldest if capacity exceeded
            while len(_PIPE_CACHE) > max(1, int(SD_PIPELINE_CACHE_SIZE)):
                old_key, old_pipe = _PIPE_CACHE.popitem(last=False)
                logger.info("Evicting pipeline from cache: {}", old_key)
                _dispose_pipe(old_pipe)
        
        _SWITCH_INPROGRESS = False
        _SWITCH_TARGET = None
        _SWITCH_CV.notify_all()
    
    if pipe is None and err:
        raise err
    return pipe

# Export the model selection function for early selection
def select_model_key() -> str:
    """Public interface to select model key for early selection."""
    return _select_model_key()

# MODIFIED: generate_image with optional model_key parameter
def generate_image(
    prompt: str,
    output_file: str,
    *,
    cfg_scale: float,
    lora_scale: float | None = None,
    steps: int,
    seed: int | None = None,
    negative_prompt: str | None = None,
    model_key: str | None = None,  # ADD THIS PARAMETER
) -> dict:
    """
    Generate an image with random scheduler and MODEL selection.
    Models: sd15 | sd14 | sd21 (uniform by default; override with env).
    Scheduler is chosen randomly with 50/50 probability, independent of all parameters.
    
    Args:
        prompt: The positive prompt
        output_file: Path to save the image
        cfg_scale: Classifier-free guidance scale
        lora_scale: Optional LoRA scale
        steps: Number of inference steps
        seed: Optional random seed
        negative_prompt: Optional negative prompt
        model_key: Optional pre-selected model key ("sd14", "sd15", or "sd21")
    
    Returns:
        Dictionary with generation metadata
    """
    logger.info("=== GENERATE_IMAGE CALLED ===")
    logger.info("  Negative prompt input: {}", negative_prompt[:100] if negative_prompt else "None")

    # --- Model selection (use provided or select new) ---
    if model_key:
        logger.info("Using pre-selected SD model key: {}", model_key)
    else:
        model_key = _select_model_key()  # "sd15" | "sd14" | "sd21"
        logger.info("Selected SD model key: {}", model_key)
    
    log_event("sd_model_selected", model_key=model_key)

    # --- LoRA: only applies to sd15 ---
    has_lora = False
    use_lora = False
    if model_key == "sd15":
        lora_available = (not SKIP_LORA) and LORA_FILE and Path(LORA_FILE).is_file()
        use_lora = lora_available and (random.random() >= RANDOM_LORA_DISABLE_PROB)
        if use_lora:
            logger.info("LoRA mode: ENABLED for sd15")
            log_event("lora_mode_selected", mode="enabled")
        else:
            reason = "random_disabled" if (not SKIP_LORA and LORA_FILE and Path(LORA_FILE).is_file()) else \
                     ("skip_lora_env" if SKIP_LORA else "file_missing_or_non_sd15")
            logger.info("LoRA mode: DISABLED ({})", reason)
            log_event("lora_mode_selected", mode="disabled", reason=reason)

    # --- Pipeline: get/build via LRU (strict memory bound) ---
    pipe = _get_or_build_pipe(model_key, with_lora=use_lora)
    has_lora = (model_key == "sd15" and use_lora)

    # RNG setup
    if seed is None and SD_SEED >= 0:
        seed = SD_SEED
    gen = (
        torch.Generator(device=pipe.device).manual_seed(seed)
        if seed is not None else None
    )

    # LoRA scaling - only pass when adapters are actually present on the selected pipe
    ca_kwargs = {"scale": lora_scale} if (lora_scale is not None and has_lora) else None

    # Random 50/50 scheduler selection (independent of CFG or any other parameter)
    scheduler_used = _select_scheduler_random(pipe)
    logger.info("Using {} scheduler (random selection)", scheduler_used)
    
    log_event("scheduler_selected", scheduler=scheduler_used)

    # Build embeddings
    with torch.inference_mode():
        # Ensure TIs are present (no-op if already loaded)
        logger.info("=== Calling _ensure_textual_inversions_loaded in generate_image ===")
        _ensure_textual_inversions_loaded(pipe)

        # Attach Compel with TI manager bound to *this* pipe
        compel = _get_compel(pipe)

        # Choose model-aware TI tokens and prepend
        ti_tokens, ti_mode = _select_ti_tokens_for_model(model_key)
        logger.info("=== TI policy resolved: mode={} tokens={} ===", ti_mode, ti_tokens)
        neg_text = _prepend_ti_tokens(negative_prompt, ti_tokens)
        logger.info("=== neg_text AFTER PREPENDING: {} ===", neg_text[:150] if neg_text else "None")

        # Build embeddings from your weighted string prompt
        pos = compel(prompt)
        neg = compel(neg_text)  # includes model-aware TI choice or plain

        # Ensure equal sequence length for pos/neg (required when truncate_long_prompts=False)
        pos, neg = compel.pad_conditioning_tensors_to_same_length([pos, neg])

        # Choose resolution per model: SD2.1 (768-v) at 768, SD1.x at 512
        _h, _w = (768, 768) if model_key == "sd21" else (IMG_HEIGHT, IMG_WIDTH)
        
        result = pipe(
            prompt_embeds=pos,
            negative_prompt_embeds=neg,
            num_inference_steps=steps,
            height=_h,
            width=_w,
            guidance_scale=cfg_scale,
            generator=gen,
            cross_attention_kwargs=ca_kwargs,
        )

        image = result.images[0]

    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    image.save(output_file)
    logger.info("Saved image -> {}", output_file)

    # Human-friendly model label
    model_label = {
        "sd15": "sd-v1.5",
        "sd14": "sd-v1.4",
        "sd21": "sd-v2.1",
    }.get(model_key, model_key)
    if has_lora:
        model_label += "+lora"

    # Return the actual render characteristics so callers can persist them.
    return {
        "sampler": scheduler_used,
        "model": model_label,
        "sd_model_key": model_key,
        "width": _w,  # Return actual width used
        "height": _h,  # Return actual height used
        "seed": seed,
        "lora_disabled": (not has_lora),
        "negative_prompt_used": neg_text,  # Includes TI tokens for DB storage
        "ti_mode": ti_mode,
        "ti_tokens": ti_tokens,
    }