#!/usr/bin/env python3
"""
PumpPortal token-trade subscriber (Windows-compatible version)

Runtime  : Python 3.8+
Depends  : websockets>=12.0
Endpoint : wss://pumpportal.fun/api/data

Cross-platform compatible with Windows signal handling.
"""

from __future__ import annotations

import asyncio
import json
import logging
import signal
import sys
import time
from typing import Optional

import websockets

# === USER EDIT THIS: paste your token mint (SPL contract) address here ===
TOKEN_MINT = "6XfSrY8UP1mUfRimA9QuxgYDdwV3hF75m3ajX7g6YNUS"
# Example: TOKEN_MINT = "91WNez8D22NwBssQbkzjy4s2ipFrzpmn5hfvWVe2aY5p"

PUMPPORTAL_WS_URL = "wss://pumpportal.fun/api/data"

# Backoff settings
INITIAL_BACKOFF_S = 1.0
MAX_BACKOFF_S = 30.0

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s.%(msecs)03d %(levelname)s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("pumpportal-subscriber")


def _subscription_payload(token_mint: str) -> str:
    """
    Build the JSON message for `subscribeTokenTrade` for a single token.
    """
    payload = {
        "method": "subscribeTokenTrade",
        "keys": [token_mint],  # array of token CAs to watch (per docs)
    }
    return json.dumps(payload)


async def _recv_loop(ws: websockets.WebSocketClientProtocol) -> None:
    """
    Receive and pretty-print messages until the connection closes.
    """
    async for raw in ws:
        try:
            msg = json.loads(raw)
        except Exception:
            # If it's not valid JSON, print raw
            print(raw, flush=True)
            continue
        # Pretty print one line per message to keep it grep-friendly
        print(json.dumps(msg, ensure_ascii=False), flush=True)


async def run_once(token_mint: str, shutdown_event: asyncio.Event) -> None:
    """
    Open a single connection, send subscription, then stream.
    """
    # Tune ping intervals/timeouts if you want; defaults are fine for most cases.
    async with websockets.connect(
        PUMPPORTAL_WS_URL,
        open_timeout=15,
        ping_interval=20,
        ping_timeout=20,
        max_queue=128,
    ) as ws:
        log.info("Connected to %s", PUMPPORTAL_WS_URL)

        # Subscribe to token trades
        await ws.send(_subscription_payload(token_mint))
        log.info("Subscribed to trades for token mint: %s", token_mint)

        # Stream until shutdown or socket closes
        recv_task = asyncio.create_task(_recv_loop(ws))
        stop_task = asyncio.create_task(shutdown_event.wait())
        done, pending = await asyncio.wait(
            {recv_task, stop_task}, return_when=asyncio.FIRST_COMPLETED
        )

        # If shutdown requested, attempt a clean close
        if stop_task in done:
            log.info("Shutdown requested, closing WebSocket...")
            try:
                await ws.close(code=1000, reason="client shutdown")
            except Exception:
                pass
        # Ensure tasks are cleaned up
        for t in pending:
            t.cancel()


async def main(token_mint: str) -> int:
    if not token_mint or token_mint.startswith("ENTER_"):
        log.error("Please set TOKEN_MINT to a valid SPL token mint address.")
        return 2

    shutdown_event = asyncio.Event()

    # Platform-specific signal handling
    try:
        if sys.platform != "win32":
            # Unix/Linux/Mac: Use asyncio signal handlers
            loop = asyncio.get_running_loop()
            for sig in (signal.SIGINT, signal.SIGTERM):
                loop.add_signal_handler(sig, shutdown_event.set)
        else:
            # Windows: Use traditional signal handler
            def signal_handler(signum, frame):
                shutdown_event.set()
                log.info("Shutdown signal received...")
            
            signal.signal(signal.SIGINT, signal_handler)
            if hasattr(signal, 'SIGTERM'):
                signal.signal(signal.SIGTERM, signal_handler)
    except Exception as e:
        log.warning("Could not set up signal handlers: %s", e)
        # Continue anyway - KeyboardInterrupt will still work

    backoff = INITIAL_BACKOFF_S

    while not shutdown_event.is_set():
        try:
            await run_once(token_mint, shutdown_event)
            if shutdown_event.is_set():
                break
            # If we fell out without shutdown, treat as disconnect and retry.
            log.warning("Disconnected. Reconnecting soon...")
        except (websockets.ConnectionClosed, websockets.InvalidStatusCode) as e:
            log.warning("WebSocket closed: %s", e)
        except KeyboardInterrupt:
            log.info("Keyboard interrupt received...")
            shutdown_event.set()
            break
        except Exception as e:
            log.exception("Unexpected error: %s", e)

        if not shutdown_event.is_set():
            # Exponential backoff between reconnect attempts
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, MAX_BACKOFF_S)
            log.info("Reconnecting (backoff=%.1fs)...", backoff)

    log.info("Exited.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(asyncio.run(main(TOKEN_MINT)))
    except KeyboardInterrupt:
        # Fallback for environments without signal handlers
        print("\nInterrupted.", file=sys.stderr)
        sys.exit(130)