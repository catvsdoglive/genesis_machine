# attribute.py
"""
Attribute Module for Stable Diffusion 1.5 Prompt Generation (Optimized)

Compressed visual attributes using SD1.5 tag format.
All descriptors reduced to essential keywords without articles/prepositions.

Position in prompt: After ENVIRONMENT
Token budget: 2-3 tokens per attribute
"""

from __future__ import annotations
from typing import Final

__all__ = ["ATTRIBUTES"]

ATTRIBUTES: Final[list[str]] = [
    # === VISUAL EFFECTS/OVERLAYS ===
    "laser eyes",
    "clown nose",
    "tinfoil hat",
    "grin overlay",
    "stonks arrow",
    
    # === EMOTIONAL/PHYSICAL STATES ===
    "sweating",
    "red eyes crying",
    "shaking nervous",
    "glowing confident",
    "exhausted",
    "manic expression",
    
    # === VISUAL MODIFIERS ===
    "centered white background",
    "silhouetted sky",
    "motion blur",
    "soft vignette",
    "high contrast silhouette",
    
    # === UI/OVERLAY ELEMENTS ===
    "liquidity lock padlock",
    "contract renounced stamp",
    "honeypot warning",
    "rug pull siren",
    "lp drain button",
    "presale whitelist",
    "fair launch countdown",
    "anti-bot captcha",
    "community takeover banner",
    "slippage slider",
    "slippage warning",
    "sniper bot crosshair",
    "pending transaction",
    "wallet balance zero",
    "block explorer magnifying",
    
    # === MARKET VISUALIZATION ATTRIBUTES ===
    "candlestick forest",
    "red wick waterfall",
    "green candle staircase",
    "charting dashboard",
    "token logo wallpaper",
    "supply demand graph",
    
    # === MEME DESCRIPTORS ===
    "moon landing",
    "meme stash",
    "sell wall meltdown",
    "shadow cabal",
    "telegram ping storm",
    "discord ping avalanche",
    "copypasta wall",
    "roadmap napkin",
    "open-source repo",
    
    # === ATMOSPHERIC ATTRIBUTES ===
    "quantum superposition",
    "matrix rain",
    "void spotlight",
    "fractal patterns",
    "kaleidoscope reflection",
    "broken mirror",
    "venetian blinds",

    # === VISUAL EFFECTS/OVERLAYS (continued) ===
    "glowing aura",
    "speed lines",
    "lens flare",
    "chromatic aberration",
    "pixelated censorship",
    "spotlight above",
    "shadow clone",
    "particle swirling",
    "holographic projection",
    "glitch artifacts",
    "scan lines",
    "static noise",
    "rainbow prism",
    "x-ray skeleton",
    "heat vision",
    
    # === EMOTIONAL/PHYSICAL STATES (continued) ===
    "drooling",
    "eyes wide shock",
    "trembling rage",
    "frozen fear",
    "radiating smug",
    "visibly confused",
    "contemplative",
    "barely laughing",
    "seething jealousy",
    "overwhelmed joy",
    "dead inside",
    "thousand yard stare",
    "enlightenment",
    "transcendent bliss",
    "maximum cope",
    
    # === VISUAL MODIFIERS (continued) ===
    "double exposure",
    "fish eye lens",
    "tilt shift miniature",
    "split screen",
    "picture picture",
    "recursive mirror",
    "forced perspective",
    "low poly",
    "ascii art",
    "mosaic pixels",
    "newspaper halftone",
    "comic ben day",
    "watercolor bleed",
    "oil painting texture",
    "chalk drawing",
    
    # === UI/OVERLAY ELEMENTS (continued) ===
    "loading 99%",
    "buffering circle",
    "404 error",
    "blue screen death",
    "connection lost",
    "low battery",
    "achievement unlocked",
    "level up",
    "critical hit",
    "health bar depleted",
    "mana bar overflow",
    "quest marker",
    "dialogue box",
    "inventory open",
    "skill tree",
    
    # === MARKET VISUALIZATION ATTRIBUTES (continued) ===
    "bollinger bands squeeze",
    "rsi oversold",
    "macd crossing",
    "volume bars exploding",
    "order book walls",
    "heat map red",
    "depth chart cliff",
    "fibonacci lines",
    "support level",
    "resistance ceiling",
    "moving average",
    "ichimoku cloud",
    "elliott wave",
    "wedge formation",
    "head shoulders chart",
    
    # === MEME DESCRIPTORS (continued) ===
    "wojak mask",
    "pepe hands",
    "chad chin",
    "virgin walk",
    "doomer hood",
    "bloomer flowers",
    "coomer brain",
    "giga chad jaw",
    "npc dialogue",
    "soyjak mouth",
    "based department",
    "cringe compilation",
    "ratio'd oblivion",
    "quote tweet dunk",
    "screenshot preserved",
    
    # === ATMOSPHERIC ATTRIBUTES (continued) ===
    "time loop",
    "dimensional rift",
    "reality tearing",
    "simulation breaking",
    "astral projection",
    "parallel universe",
    "temporal distortion",
    "gravity well",
    "event horizon",
    "singularity emerging",
    "void staring",
    "entropy increasing",
    "chaos magic",
    "liminal space",
    "backrooms clipping",
    
    # === CRYPTO/DEFI SPECIFIC ===
    "metamask fox",
    "phantom wallet",
    "ledger connected",
    "seed phrase tattoo",
    "private key exposed",
    "gas mask fees",
    "yield farming tools",
    "liquidity pool gear",
    "bridge construction",
    "validator node",
    "staking rewards",
    "impermanent loss",
    "slippage exceeded",
    "sandwich attack",
    "flashloan executing",
    
    # === ACCESSORIES/ITEMS ===
    "golden monocle",
    "diamond grill",
    "paper hands",
    "rocket boots",
    "moon boots",
    "bear spray",
    "bull horns",
    "whale tail",
    "shark fin",
    "crab claws",
    "ape strong",
    "hodl shield",
    "fud armor",
    "fomo goggles",
    "copium tank",
    
    # === TRANSFORMATION STATES ===
    "evolving pokemon",
    "super saiyan",
    "werewolf changing",
    "zombie spreading",
    "cyborg upgrades",
    "mutant powers",
    "ascending godhood",
    "descending madness",
    "final form",
    "breaking limits",
    "power 9000",
    "ultra instinct",
    "sage mode",
    "bankai released",
    "gear fifth",
]