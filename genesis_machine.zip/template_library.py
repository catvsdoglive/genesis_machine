# template_library.py
from __future__ import annotations

import random
from typing import List, Tuple, Callable, Dict

# Metrics import (no hard dependency)
try:
    from metrics import log_event
except Exception:
    def log_event(*_a, **_k): pass

from config import (
    MAX_NAME_WORDS,
    TICKER_MIN_LENGTH, TICKER_MAX_LENGTH,
    DESCRIPTION_MAX_TOKENS,
    MAX_INSPIRATION_WORDS,
    RANDOM_INSPIRATION_WORDS, 
    INSPIRATION_WORDS_MIN,     
    INSPIRATION_WORDS_MAX,
    NAME_ONEWORD_PROB 
)

TemplateKey = str
TemplateFn = Callable[[str, List[str], str, str], str]

# Helpers

def _sample_trending(words: List[str], k: int) -> List[str]:
    """Sample k trending words from the list."""
    if not words:
        return []
    if k <= 0:
        return []
    k = min(k, len(words))
    return random.sample(words, k)

def _trending_line(sampled: List[str], k_max: int) -> str:
    """
    Show the trending candidates and state the *effective* cap,
    i.e., min(MAX_INSPIRATION_WORDS, MAX_NAME_WORDS, len(sampled)).
    """
    if not sampled or k_max <= 0:
        return ""
    if _NAME_STYLE_CTX == "oneword":
        return (
          f"Trending words (use at most {k_max}; "
          "ALL of them go to DESCRIPTION; NONE in NAME): "
          f"{', '.join(sampled)}\n"
        )
    else:
        return f"Trending words (use at most {k_max}): {', '.join(sampled)}\n"

def _ticker_constraints() -> str:
    return (
        f"- ticker: UPPERCASE letters A–Z ONLY. length {TICKER_MIN_LENGTH}-{TICKER_MAX_LENGTH}. "
        "Never place trending words in ticker. "
        "No digits. No emoji, no hashtags (#), no @ mentions, no $, /, or hyphens.\n"
    )

def _desc_line(style_instruction: str, style_name: str, animal: str) -> str:
    """
    Single authoritative place that prints the DESCRIPTION instruction,
    now enriched with persona voice + explicit blend weights.
    """
    persona = _PERSONA_CTX
    pw, sw = (_VOICE_STYLE_WEIGHTS if _VOICE_STYLE_WEIGHTS else (0.5, 0.5))
    persona_clause = f"Write explicitly in the voice of: {persona}. " if persona else ""
    blend_clause = (
        f"Blend persona vs style ≈ {pw:.2f}:{sw:.2f} (persona:style). "
        "If conflict: allocate vocabulary/cadence to persona share; structure/tropes/formatting to style share. "
    )
    return (
        f"- description: {persona_clause}"
        f"{style_instruction.format(animal=animal)} "
        f"(Style: {style_name}). {blend_clause}"
        f"ASCII only, NO EMOJIS. Max {DESCRIPTION_MAX_TOKENS} tokens.\n"
    )

def _canonical_json_rules() -> str:
    return (
        "STRICT JSON RULES:\n"
        "• Output MUST be a single JSON object with keys: name, ticker, description, animal.\n"
        "• No code fences, no extra commentary.\n"
        "• The description may contain paragraph breaks; represent newlines as \\n (exactly one backslash + n). Do not double-escape them.\n"
        "• Do not hand-escape quotes/backslashes elsewhere; simply return valid JSON.\n"
        "• NEVER use single quotes in JSON strings; use double quotes only.\n"
        "• JSON correctness overrides all other instructions—if anything conflicts, produce valid JSON.\n"
        "Return JSON only.\n"
    )

def _open_line(animal: str) -> str:
    return f"Create one meme-token. Its mascot/theme is a {animal}.\n"

_NAME_STYLE_CTX: str | None = None
def _set_name_style_ctx(v: str | None) -> None:
    global _NAME_STYLE_CTX
    _NAME_STYLE_CTX = v

# Voice/Style blend context (set once per prompt build)
_PERSONA_CTX: str | None = None
_VOICE_STYLE_WEIGHTS: tuple[float, float] | None = None
def _set_voice_style_ctx(persona: str | None, weights: tuple[float, float] | None) -> None:
    global _PERSONA_CTX, _VOICE_STYLE_WEIGHTS
    _PERSONA_CTX = persona
    _VOICE_STYLE_WEIGHTS = weights

def _name_line_base(extra: str = "") -> str:
    """
    Core naming constraints + dynamic style rule (from _NAME_STYLE_CTX)
    and Bark-root suppression guidance.
    """
    base = f"- name: at most {MAX_NAME_WORDS} words; NO colons (:) or hyphens (-)"
    if extra:
        base += f"; {extra}"
    out = [base]
    if _NAME_STYLE_CTX == "oneword":
        out.append(
          "- name style: ONE WORD ONLY (letters A–Z). "
          "No spaces, no underscores, no hyphens, no CamelCase. "
          "Prefer 4–12 letters. Examples: Bob, Jesus, Hidalgo, Doggo, Dogelord, Eloncat, Jamesbondcat, Catecysm, Luke, Vader."
        )
        out.append(
          "- Trending words MUST NOT appear in NAME when style=oneword; "
          "put them in DESCRIPTION instead."
        )
    elif _NAME_STYLE_CTX == "spaced":
        out.append(f"- name style: use SPACED words (1–{MAX_NAME_WORDS} words). Do NOT use CamelCase, underscores, or slashes.")
    elif _NAME_STYLE_CTX == "camel":
        out.append("- name style: use CamelCase with NO spaces and NO underscores/hyphens; Capitalize EachWord.")
    out.append("- avoid cliché animal sounds in the NAME (bark/woof for dogs, meow/purr for cats). Choose more creative alternatives.")
    return "\n".join(out) + "\n"
    
def _choose_name_style() -> str:
    """Tri-modal: 'oneword' with configurable probability, else 50/50 spaced|camel."""
    r = random.random()
    if r < NAME_ONEWORD_PROB:
        mode = "oneword"
    else:
        mode = "spaced" if random.random() < 0.5 else "camel"
    try: log_event("name_style_target", mode=mode)
    except Exception: pass
    return mode

def _animal_line(animal: str) -> str:
    return f"- animal: \"{animal}\"\n"

# Template 1 (Baseline: MUST use trending words in NAME)
def t01_baseline(animal: str, words: List[str], style_instruction: str, style_name: str) -> str:
    inspiration_count = _get_effective_inspiration_words()
    
    shown = _sample_trending(words, inspiration_count)
    k_feasible = min(inspiration_count, MAX_NAME_WORDS, len(shown)) if shown else 0
    
    extra = ""
    if k_feasible > 0:
        extra = f"must incorporate at least {k_feasible} trending word(s) from the list below in the NAME"
    else:
        extra = "if trending words are available, prefer using them in the NAME"
    
    parts = [
        _open_line(animal),
        _name_line_base(extra),
        _ticker_constraints(),
        _desc_line(style_instruction, style_name, animal),
        _animal_line(animal),
        _trending_line(shown, k_feasible),
        _canonical_json_rules(),
    ]
    return "".join(parts)

# Templates 2–50 (prefer name else description)
def _prefer_name_else_desc(animal: str, words: List[str], style_instruction: str, style_name: str,
                           name_extra: str) -> str:
    inspiration_count = _get_effective_inspiration_words()
    
    shown = _sample_trending(words, inspiration_count)
    k_feasible = min(inspiration_count, MAX_NAME_WORDS, len(shown)) if shown else 0
    
    trending_requirement = ""
    if k_feasible > 0:
        if _NAME_STYLE_CTX == "oneword":
            trending_requirement = (
              f"MANDATORY: Use all {k_feasible} trending word(s) in DESCRIPTION only. "
              "Do NOT include any trending word in NAME. NEVER in ticker. "
            )
        else:
            trending_requirement = (
              f"MANDATORY: You must use all {k_feasible} trending word(s) listed below. "
              "Put them in NAME if possible, otherwise in DESCRIPTION. "
              "NEVER in ticker. "
            )
    
    parts = [
        _open_line(animal),
        _name_line_base(f"{name_extra}. {trending_requirement}"),
        _ticker_constraints(),
        _desc_line(style_instruction, style_name, animal),
        _animal_line(animal),
        _trending_line(shown, k_feasible),
        _canonical_json_rules(),
    ]
    return "".join(parts)

def _get_effective_inspiration_words() -> int:
    """
    Return the number of inspiration words to use with optional logging.
    If RANDOM_INSPIRATION_WORDS is true, randomly choose between MIN and MAX.
    Otherwise, use MAX_INSPIRATION_WORDS as before.
    """
    if RANDOM_INSPIRATION_WORDS:
        value = random.randint(INSPIRATION_WORDS_MIN, INSPIRATION_WORDS_MAX)
        try:
            from metrics import log_event
            log_event(
                "inspiration_words_dynamic",
                value=value,
                min=INSPIRATION_WORDS_MIN,
                max=INSPIRATION_WORDS_MAX
            )
        except Exception:
            pass
        return value
    else:
        return MAX_INSPIRATION_WORDS

def t02_minimal_oneword(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra="prefer a single compact word with no animal references"
    )

def t03_adj_noun(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra="use 'Adjective + Noun' or 'Noun + Noun' pattern with space"
    )

def t04_defi_native(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra="use protocol names with space; tone: credible DeFi protocol naming (e.g., validators, liquidity, zk, l2, DAO)"
    )

def t05_cult_chant(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra="optimize NAME for chantability in crowds"
    )

def t06_minimal_zen(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra="simple, clean, minimal; one or two plain words with spaces"
    )

def t07_lore_epic(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra="evoke legends/mythology/moon missions; 1–3 words with spaces"
    )

def t08_regional_flavor(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra="may reflect regional/cultural flavor (keep respectful and generic); 1–3 words"
    )

def t09_math_quant(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "hint at math/quant vibes (alpha, beta, sigma, gamma, model, lab, desk, signal, factor). "
            "Do NOT always start the name with the word 'Quant'. If you include 'quant', place it in the middle or as a suffix "
            "(e.g., 'HaiTelau Quant' or 'HaiTelauQuant')."
        )
    )

def t10_utility_parody(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra="parody 'serious utility' names while staying readable"
    )
    
def t11_internet_slang(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use internet slang/zoomer speak in NAME (e.g., 'Based Protocol', 'No Cap Finance', "
            "'Bussin Token', 'Touch Grass DAO'). Keep it 1-3 words with spaces"
        )
    )

def t12_corporate_buzzword(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "parody corporate buzzwords (e.g., 'Synergy Labs', 'Disrupt Protocol', "
            "'Pivot Finance', 'Agile Solutions'). Use 1-2 words with space between"
        )
    )

def t13_retro_gaming(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "reference retro gaming culture (e.g., 'Speedrun Protocol', 'Boss Battle', "
            "'Extra Life', 'Power Up'); 1-2 words with spaces"
        )
    )

def t14_culinary_themed(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use food/culinary terminology creatively (e.g., 'Wagyu Protocol', 'Umami Labs', "
            "'Fork Tender', 'Gas Fee Grill'). Keep appetizing; 1-3 words with spaces"
        )
    )

def t15_academic_pretentious(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use pretentious academic/scientific terms (e.g., 'Quantum Flux', 'Entropy Lab', "
            "'Paradigm Shift', 'Thesis Protocol'). Sound smart but accessible; 1-2 words with spaces"
        )
    )

def t16_ct_kol(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "reference Crypto Twitter KOL culture (e.g., 'Anon Capital', 'Thread Guy', "
            "'Alpha Caller', 'Shill Master', 'Cope Network'). Keep it 1-2 words with spaces; "
        )
    )

def t17_inu_suffix(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "MUST end with 'Inu' (Japanese for dog/meme tradition). "
            "Format: '[Word] Inu' with space before Inu (e.g., 'Rocket Inu', 'Based Inu', "
            "'Degen Inu', 'Moon Inu'). Maximum 2 words before 'Inu'"
        )
    )

def t18_rugpull_dark_humor(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use dark humor about rugpulls/scams (e.g., 'Exit Liquidity', 'Honeypot Labs', "
            "'Slow Rug', 'Trust Protocol', 'Safe Moon'). Ironic but not too obvious; "
            "1-2 words with spaces"
        )
    )

def t19_emotional_states(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "name after emotional/psychological states (e.g., 'FOMO Network', 'Euphoria Labs', "
            "'Panic Protocol', 'Greed Index', 'Hope Machine'). Capture trader psychology; "
            "1-2 words with spaces"
        )
    )

def t20_time_based(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "reference time/temporal concepts (e.g., 'Late Night', 'Dawn Protocol', "
            "'Forever Hold', 'Never Sell', 'Soon Labs'). Evoke timing/patience themes; "
            "1-2 words with spaces"
        )
    )
    
def t21_conspiracy_parody(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "light, tongue-in-cheek 'conspiracy board' vibes (e.g., 'Tin Foil Research', "
            "'Red String Labs', 'Hidden Alpha'). Avoid real persons, brands, and politics; "
            "keep it playful and fictional. 1-2 words with spaces"
        )
    )

def t22_space_cosmic(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "space/astronomy motifs (e.g., 'Nebula Hound', 'Lunar Whisker', 'Cosmic Collars'); "
            "evoke exploration/cosmos; 1-2 words with spaces"
        )
    )

def t23_sports_action(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "sports/action energy (e.g., 'Rally Mode', 'Overtime Labs', 'Turbo Fetch'); "
            "no team names or athlete names; 1-2 words with spaces"
        )
    )

def t24_music_audio(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "music/audio concepts (e.g., 'LoFi Pup', 'Bass Drop', 'Vinyl Cat'); "
            "sound/beat/vibe cues welcome; 1-2 words with spaces"
        )
    )

def t25_gadget_maker(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "maker/tools/gadgets vibe (e.g., 'Wrench Works', 'Solder Pup', 'Toolchain Cat'); "
            "avoid brand names; 1-2 words with spaces"
        )
    )

def t26_weather_seasonal(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "weather/season themes (e.g., 'Monsoon Doge', 'Sunbeam Cat', 'Aurora Hound'); "
            "1-2 words with spaces"
        )
    )

def t27_tradfi_satire(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "TradFi jargon satire (e.g., 'Basis Paws', 'Yield Curve', 'Alpha Beta'); "
            "playful finance tone (not advice); 1-2 words with spaces"
        )
    )

def t28_art_movement(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "art movements/visual styles (e.g., 'Bauhaus Cat', 'Cubist Doge', 'Pop Art Pup'); "
            "concise and aesthetic; 1-2 words with spaces"
        )
    )

def t29_travel_places(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "travel/location vibes without real addresses (e.g., 'Island Cat', 'Metro Doge', "
            "'Harbor Hound'); 1-2 words with spaces"
        )
    )

def t30_sci_fi_gizmo(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "sci‑fi gadgets/tech (e.g., 'Quantum Collar', 'Laser Whisker', 'Neon Reactor'); "
            "futuristic/optimistic; 1-2 words with spaces"
        )
    )
    
def t31_occult_runic(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "draw on occult/esoteric vocabulary (e.g., 'Talisman Node', 'Runic Ledger', "
            "'Hermetic Gate'); 1-2 words with spaces"
        )
    )

def t32_intel_codenames(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use playful 'signals-intelligence' style codenames (e.g., 'PRISM Node', "
            "'XKey Vault', 'Boundless Index', 'Tempora Mesh', 'Muscular Mirror'); 1-2 words with spaces. "
        )
    )

def t33_hermetic_geometry(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "hermetic geometry & sacred-math vibes (e.g., 'Tessellation Lab', 'Torus Gate', "
            "'Theta Temple', 'Tomography Forge', 'Macrocosm Ledger'); 1-2 words with spaces"
        )
    )

def t34_fringe_physics(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "fringe physics & cosmology memes (e.g., 'Boltzmann Brain', 'Zero Point', "
            "'Aether Forge', 'Gravity Lens', 'Accretion Disk'); fictional/non-claiming tone; "
            "1-3 words with spaces"
        )
    )

def t35_megastructure_space(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "space megastructures & astro-oddities (e.g., 'Dyson Sphere', 'Accretion Disk', "
            "'Orbital Ring', 'Star Forge'); 1-2 words with spaces"
        )
    )

def t36_panopticon_surveillance(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "panopticon/surveillance metaphors (e.g., 'Panopticon', 'Stingray Mesh', "
            "'Telemetry Vault', 'Watchtower Grid'). Avoid real system/agency claims; "
            "1-2 words with spaces"
        )
    )

def t37_sys_glitch_codes(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "glitch/system codes & mnemonics (e.g., 'SYS64738', 'Kernel Panic', "
            "'Segfault Oracle', 'Checksum Shrine'); no profanity; 1-2 words with spaces"
        )
    )

def t38_liminal_retro_paranormal(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "liminal TV/retro-paranormal vibes (e.g., 'Twilight Zone', 'Outer Zone', "
            "'Darkside Labs'); avoid trademarks in name; 1-3 words with spaces"
        )
    )

def t39_labyrinth_topology(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "labyrinths, tessellations & topology (e.g., 'Labyrinth Protocol', 'Kaleidoscope Swap', "
            "'Torus Grid'); 1-2 words with spaces"
        )
    )

def t40_eldritch_cryptozoology(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "cryptids & eldritch/paranormal themes (e.g., 'Eldritch Cat', 'Liminal Hound', "
            "'Extradimensional Node'); no gore; 1-2 words with spaces"
        )
    )
    
def t41_chemistry_compound(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use chemistry/element terminology (e.g., 'Helium Hound', 'Carbon Chain', "
            "'Ionic Bond', 'Catalyst Protocol', 'Entropy Engine'). Sound scientific but accessible; "
            "1-2 words with spaces"
        )
    )

def t42_vintage_internet(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "reference vintage internet culture (e.g., 'Dial Up', 'Flash Player', "
            "'Netscape Navigator', 'AIM Status', 'Limewire Legacy'). Nostalgic early web vibes; "
            "1-2 words with spaces"
        )
    )

def t43_mythology_deity(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "reference mythological deities/creatures subtly (e.g., 'Olympus Protocol', 'Valhalla Vault', "
            "'Phoenix Rising', 'Titan Trade', 'Oracle Network'). Epic but not literal gods; "
            "1-2 words with spaces"
        )
    )

def t44_market_mechanics(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use market mechanics terminology (e.g., 'Limit Order', 'Spread Hunter', "
            "'Volume Spike', 'Bid Wall', 'Fill Zone'). Trading desk energy; "
            "1-2 words with spaces"
        )
    )

def t45_social_dynamics(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "reference social dynamics/network effects (e.g., 'Viral Load', 'Echo Chamber', "
            "'Signal Boost', 'Trend Setter', 'Hive Mind'). Social contagion vibes; "
            "1-2 words with spaces"
        )
    )
    
def t46_military_tactical(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use military/tactical terminology (e.g., 'Strike Force', 'Recon Unit', "
            "'Breach Protocol', 'Extraction Point', 'Zero Hour'). Strategic ops energy; "
            "1-2 words with spaces"
        )
    )

def t47_natural_phenomena(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "reference natural phenomena (e.g., 'Aurora Surge', 'Tidal Lock', "
            "'Solar Flare', 'Frost Pattern', 'Thunder Cell'). Forces of nature vibe; "
            "1-2 words with spaces"
        )
    )

def t48_casino_gambling(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use casino/gambling terminology (e.g., 'High Roller', 'House Edge', "
            "'Lucky Seven', 'All In', 'Double Down'). Vegas energy but crypto native; "
            "1-2 words with spaces"
        )
    )

def t49_manufacturing_industrial(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use manufacturing/industrial terms (e.g., 'Assembly Line', 'Factory Floor', "
            "'Supply Chain', 'Quality Control', 'Production Run'). Industrial revolution meets DeFi; "
            "1-2 words with spaces"
        )
    )

def t50_psychological_concepts(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use psychology concepts (e.g., 'Cognitive Load', 'Flow State', "
            "'Mirror Neuron', 'Dopamine Hit', 'Pattern Recognition'). Mind games but approachable; "
            "1-2 words with spaces"
        )
    )

def t51_fashion_textile(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use fashion/textile terminology (e.g., 'Velvet Protocol', 'Thread Count', "
            "'Couture Chain', 'Drip Index', 'Runway Ready'). High fashion meets crypto; "
            "1-2 words with spaces"
        )
    )

def t52_architecture_construction(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use architecture/construction terms (e.g., 'Load Bearer', 'Blueprint Labs', "
            "'Foundation Stone', 'Cantilever Bridge', 'Keystone Protocol'). Build vibes; "
            "1-2 words with spaces"
        )
    )

def t53_maritime_nautical(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use maritime/nautical themes (e.g., 'Port Authority', 'Anchor Protocol', "
            "'Tide Turner', 'Deep Water', 'Crow Nest'). Seafaring energy; "
            "1-2 words with spaces"
        )
    )

def t54_legal_judicial(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use legal/judicial terminology (e.g., 'Verdict Labs', 'Due Process', "
            "'Motion Protocol', 'Case Closed', 'Jury Pool'). Courtroom drama energy; "
            "1-2 words with spaces"
        )
    )

def t55_medical_healthcare(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use medical/healthcare terms (e.g., 'Vital Signs', 'Pulse Protocol', "
            "'Remedy Labs', 'Dose Response', 'Chart Review'). Clinical but approachable; "
            "1-2 words with spaces"
        )
    )

def t56_agricultural_farming(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use agricultural/farming terms (e.g., 'Harvest Moon', 'Seed Vault', "
            "'Crop Rotation', 'Field Notes', 'Grain Reserve'). Farm-to-table DeFi; "
            "1-2 words with spaces"
        )
    )

def t57_transportation_vehicles(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use transportation/vehicle terms (e.g., 'Transit Hub', 'Express Lane', "
            "'Cargo Hold', 'Terminal Station', 'Route Map'). Movement and logistics; "
            "1-2 words with spaces"
        )
    )

def t58_theater_performance(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use theater/stage terminology (e.g., 'Stage Left', 'Curtain Call', "
            "'Method Actor', 'Box Office', 'Green Room'). Dramatic flair; "
            "1-2 words with spaces"
        )
    )

def t59_journalism_media(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use journalism/media terms (e.g., 'Breaking News', 'Lead Story', "
            "'Press Pool', 'Source Code', 'Deadline Protocol'). Newsroom energy; "
            "1-2 words with spaces"
        )
    )

def t60_geology_minerals(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use geology/mineral terms (e.g., 'Bedrock Protocol', 'Crystal Formation', "
            "'Ore Vein', 'Fault Line', 'Sediment Layer'). Rock solid fundamentals; "
            "1-2 words with spaces"
        )
    )

def t61_botany_plants(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use botany/plant terms (e.g., 'Root Network', 'Bloom Protocol', "
            "'Canopy Layer', 'Seed Bank', 'Growth Ring'). Organic growth vibes; "
            "1-2 words with spaces"
        )
    )

def t62_dance_movement(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use dance/movement terms (e.g., 'Rhythm Protocol', 'Step Sequence', "
            "'Flow Motion', 'Beat Drop', 'Pivot Point'). Choreographed finance; "
            "1-2 words with spaces"
        )
    )

def t63_photography_optics(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use photography/optics terms (e.g., 'Focal Point', 'Aperture Labs', "
            "'Shutter Speed', 'Lens Flare', 'Depth Field'). Picture perfect protocols; "
            "1-2 words with spaces"
        )
    )

def t64_linguistics_language(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use linguistics/language terms (e.g., 'Syntax Error', 'Dialect Chain', "
            "'Phoneme Protocol', 'Grammar Check', 'Root Word'). Language nerds unite; "
            "1-2 words with spaces"
        )
    )

def t65_robotics_automation(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use robotics/automation terms (e.g., 'Servo Motor', 'Logic Gate', "
            "'Sensor Array', 'Control Loop', 'State Machine'). Automated excellence; "
            "1-2 words with spaces"
        )
    )

def t66_energy_power(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use energy/power generation terms (e.g., 'Grid Lock', 'Power Surge', "
            "'Voltage Spike', 'Current Flow', 'Load Balance'). Electric finance; "
            "1-2 words with spaces"
        )
    )

def t67_archaeology_ancient(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use archaeology/ancient civilization terms (e.g., 'Stone Tablet', 'Dig Site', "
            "'Carbon Date', 'Lost City', 'Relic Hunter'). Ancient wisdom meets DeFi; "
            "1-2 words with spaces"
        )
    )

def t68_insurance_actuarial(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use insurance/actuarial terms (e.g., 'Risk Pool', 'Premium Protocol', "
            "'Coverage Gap', 'Claim Stake', 'Policy Holder'). Calculated risk vibes; "
            "1-2 words with spaces"
        )
    )

def t69_library_archival(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use library/archival terms (e.g., 'Card Catalog', 'Stack Protocol', "
            "'Reference Desk', 'Archive Node', 'Index System'). Knowledge preservation; "
            "1-2 words with spaces"
        )
    )

def t70_hospitality_service(animal, words, style_instruction, style_name):
    return _prefer_name_else_desc(
        animal, words, style_instruction, style_name,
        name_extra=(
            "use hospitality/service terms (e.g., 'Concierge Protocol', 'Room Service', "
            "'Guest List', 'Five Star', 'Check Out'). Premium service energy; "
            "1-2 words with spaces"
        )
    )    

# Registry of all templates
_TEMPLATES: Dict[TemplateKey, TemplateFn] = {
    "T01_BASELINE_NAME_TREND": t01_baseline,
    "T02_MINIMAL_ONEWORD":    t02_minimal_oneword,
    "T03_ADJ_NOUN":           t03_adj_noun,
    "T04_DEFI_NATIVE":        t04_defi_native,
    "T05_CULT_CHANT":         t05_cult_chant,
    "T06_MINIMAL_ZEN":        t06_minimal_zen,
    "T07_LORE_EPIC":          t07_lore_epic,
    "T08_REGIONAL_FLAVOR":    t08_regional_flavor,
    "T09_MATH_QUANT":         t09_math_quant,
    "T10_UTILITY_PARODY":     t10_utility_parody,
    "T11_INTERNET_SLANG":     t11_internet_slang,
    "T12_CORPORATE_BUZZWORD": t12_corporate_buzzword,
    "T13_RETRO_GAMING":       t13_retro_gaming,
    "T14_CULINARY_THEMED":    t14_culinary_themed,
    "T15_ACADEMIC_PRETENTIOUS": t15_academic_pretentious,
    "T16_CT_KOL":             t16_ct_kol,
    "T17_INU_SUFFIX":         t17_inu_suffix,
    "T18_RUGPULL_DARK_HUMOR": t18_rugpull_dark_humor,
    "T19_EMOTIONAL_STATES":   t19_emotional_states,
    "T20_TIME_BASED":         t20_time_based,
    "T21_CONSPIRACY_PARODY":  t21_conspiracy_parody,
    "T22_SPACE_COSMIC":       t22_space_cosmic,
    "T23_SPORTS_ACTION":      t23_sports_action,
    "T24_MUSIC_AUDIO":        t24_music_audio,
    "T25_GADGET_MAKER":       t25_gadget_maker,
    "T26_WEATHER_SEASONAL":   t26_weather_seasonal,
    "T27_TRADFI_SATIRE":      t27_tradfi_satire,
    "T28_ART_MOVEMENT":       t28_art_movement,
    "T29_TRAVEL_PLACES":      t29_travel_places,
    "T30_SCI_FI_GIZMO":       t30_sci_fi_gizmo,
    "T31_OCCULT_RUNIC":             t31_occult_runic,
    "T32_INTEL_CODENAMES":          t32_intel_codenames,
    "T33_HERMETIC_GEOMETRY":        t33_hermetic_geometry,
    "T34_FRINGE_PHYSICS":           t34_fringe_physics,
    "T35_MEGASTRUCTURE_SPACE":      t35_megastructure_space,
    "T36_PANOPTICON_SURVEILLANCE":  t36_panopticon_surveillance,
    "T37_SYS_GLITCH_CODES":         t37_sys_glitch_codes,
    "T38_LIMINAL_RETRO_PARANORMAL": t38_liminal_retro_paranormal,
    "T39_LABYRINTH_TOPOLOGY":       t39_labyrinth_topology,
    "T40_ELDRITCH_CRYPTOZOOLOGY":   t40_eldritch_cryptozoology,
    "T41_CHEMISTRY_COMPOUND":    t41_chemistry_compound,
    "T42_VINTAGE_INTERNET":      t42_vintage_internet,
    "T43_MYTHOLOGY_DEITY":       t43_mythology_deity,
    "T44_MARKET_MECHANICS":      t44_market_mechanics,
    "T45_SOCIAL_DYNAMICS":       t45_social_dynamics, 
    "T46_MILITARY_TACTICAL":     t46_military_tactical,
    "T47_NATURAL_PHENOMENA":      t47_natural_phenomena,
    "T48_CASINO_GAMBLING":        t48_casino_gambling,
    "T49_MANUFACTURING_INDUSTRIAL": t49_manufacturing_industrial,
    "T50_PSYCHOLOGICAL_CONCEPTS":  t50_psychological_concepts,    
}

def build_user_prompt(
    animal: str,
    words: List[str],
    style_instruction: str,
    style_name: str,
    persona: str | None = None,
    persona_weight: float | None = None
) -> Tuple[str, List[str], List[str], str, str]:
    """
    Build user prompt using the full template system.
    Returns: (user_prompt, trending_words_shown, trending_words_all, template_key, name_style_target)
    """
    # Choose name style
    name_style = _choose_name_style()
    _set_name_style_ctx(name_style)
    
    # Set voice/style context
    pw = float(persona_weight) if persona_weight is not None else 0.5
    pw = max(0.0, min(1.0, pw))
    _set_voice_style_ctx(persona, (pw, 1.0 - pw))
    
    # Select a random template
    template_key = random.choice(list(_TEMPLATES.keys()))
    template_fn = _TEMPLATES[template_key]
    
    # Track which words are actually shown by intercepting _sample_trending
    shown_words = []
    original_sample = _sample_trending
    
    def tracking_sample(words_list, k):
        result = original_sample(words_list, k)
        shown_words.extend(result)
        return result
    
    # Temporarily replace the sampling function
    globals()['_sample_trending'] = tracking_sample
    
    try:
        # Call the actual template function
        prompt = template_fn(animal, words, style_instruction, style_name)
        
        # Log template selection
        try:
            log_event("template_selected", key=template_key)
        except Exception:
            pass
            
    finally:
        # Restore original function and clear context
        globals()['_sample_trending'] = original_sample
        _set_name_style_ctx(None)
        _set_voice_style_ctx(None, None)
    
    # If no words were captured (shouldn't happen), estimate
    if not shown_words:
        shown_words = words[:5] if words else []
    
    return prompt, shown_words, words, template_key, name_style