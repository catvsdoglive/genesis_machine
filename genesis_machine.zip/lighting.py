# lighting.py
"""
Lighting Module for Stable Diffusion 1.5 Prompt Generation (Optimized)

Compressed lighting conditions using SD1.5 tag format.
All descriptions reduced to essential keywords without articles/prepositions.

Position in prompt: Combined with CAMERA
Token budget: 1-3 tokens per lighting condition
"""

from __future__ import annotations
from typing import Final

__all__ = ["LIGHTING"]

LIGHTING: Final[list[str]] = [
    # Natural Light
    "natural light",
    "window light",
    "golden hour",
    "blue hour",
    "magic hour",
    "sunrise",
    "sunset",
    "overcast diffuse",
    "harsh midday",
    "dappled sunlight",
    "moonlight",
    "starlight",
    
    # Studio Lighting
    "studio lighting",
    "softbox",
    "ring light",
    "strobe",
    "continuous light",
    "three-point",
    "key light",
    "fill light",
    "hair light",
    "background light",
    
    # Portrait Lighting Patterns 
    "rembrandt lighting",
    "split lighting",
    "butterfly lighting",
    "loop lighting",
    "broad lighting",
    "short lighting",
    "paramount lighting",
    
    # Dramatic Lighting
    "rim lighting",
    "rim-lit silhouette",
    "backlighting",
    "backlit glow",
    "dramatic shadows",
    "chiaroscuro",
    "tenebrism",
    "harsh contrast",
    "single source",
    
    # Soft Lighting
    "soft diffused",
    "even lighting",
    "flat lighting",
    "ambient",
    "overcast softbox",
    "bounced light",
    "reflected light",
    
    # Key Styles
    "moody low-key",
    "bright high-key",
    "high key",
    "low key",
    
    # Atmospheric Effects
    "volumetric lighting",
    "volumetric god rays",
    "light shafts",
    "dust motes",
    "fog lighting",
    "hazy backlight",
    "atmospheric haze",
    "light beams",
    "crepuscular rays",
    
    # Special Effects
    "neon glow",
    "silhouette",
    "contre-jour",
    "lens flare",
    "light leak",
    "bokeh lights",
    "fairy lights",
    "string lights",
    "christmas lights",
    
    # Color Temperature
    "warm lighting",
    "cool lighting",
    "tungsten",
    "fluorescent",
    "candlelight",
    "firelight",
    "golden light",
    "blue light",
    
    # Directional Light
    "side lighting",
    "top lighting",
    "bottom lighting",
    "front lighting",
    "45 degree",
    "cross lighting",
    
    # Practical Lighting
    "practical lights",
    "motivated lighting",
    "available light",
    "mixed lighting",
    "stage lighting",
    "concert lighting",
    "club lighting",
    "street lighting",
    
    # Technical Lighting
    "hard light",
    "soft light",
    "specular highlights",
    "diffuse",
    "directional",
    "omnidirectional",
    "spot lighting",
    "flood lighting",
    
    # Cinematic Lighting
    "film noir",
    "neo noir",
    "technicolor",
    "anamorphic flares",
    "bleach bypass",
    "day for night",
    "night for day",
    "magic lantern",
    "projector beam",
    "drive-in glow",
    
    # Environmental Lighting
    "underwater caustics",
    "forest canopy",
    "cave mouth",
    "desert shimmer",
    "arctic light",
    "tropical storm",
    "volcanic glow",
    "aurora borealis",
    "bioluminescent",
    "phosphorescent",
    
    # Architectural Lighting
    "cathedral light",
    "stained glass",
    "skylight",
    "clerestory",
    "oculus beam",
    "light well",
    "atrium",
    "arcade shadows",
    "colonnade pattern",
    "lattice shadows",
    
    # Time-Specific
    "dawn breaking",
    "first light",
    "nautical twilight",
    "civil twilight",
    "astronomical twilight",
    "witching hour",
    "midnight blue",
    "pre-dawn",
    "afterglow",
    "alpenglow",
    
    # Weather Lighting
    "lightning flash",
    "storm light",
    "rainbow light",
    "snow reflection",
    "rain shimmer",
    "mist diffusion",
    "tornado light",
    "hurricane eye",
    "dust orange",
    "sandstorm",
    
    # Industrial/Urban
    "sodium vapor",
    "mercury vapor",
    "LED panel",
    "halogen spots",
    "xenon flash",
    "laser scanning",
    "blacklight UV",
    "infrared",
    "x-ray",
    "thermal imaging",
    
    # Period Lighting
    "gaslight",
    "oil lamp",
    "torch flicker",
    "lantern",
    "candelabra",
    "hearth fire",
    "brazier",
    "campfire",
    "bonfire",
    "ember glow",
    
    # Stylized Lighting
    "cell shaded",
    "anime lighting",
    "comic book",
    "watercolor light",
    "impressionist",
    "pointillist dots",
    "cross-hatched",
    "woodcut contrast",
    "lithograph",
    "screen print",
    
    # Scientific/Technical
    "electron microscope",
    "MRI false color",
    "spectrograph",
    "oscilloscope green",
    "radar sweep",
    "sonar ping",
    "lidar cloud",
    "photogrammetry",
    "schlieren",
    "kirlian aura",
    
    # Theatrical
    "footlight",
    "spotlight",
    "gobo pattern",
    "color gel",
    "cyclorama",
    "scrim",
    "border lights",
    "house lights",
    "work lights",
    "ghost light",
    
    # Emotional/Mood
    "melancholic grey",
    "euphoric bright",
    "anxious flicker",
    "serene glow",
    "ominous dark",
    "hopeful ray",
    "nostalgic sepia",
    "dreamlike soft",
    "nightmare harsh",
    "liminal fluorescent",
    
    # Material Interaction
    "crystal refraction",
    "mirror bounce",
    "metallic reflection",
    "water caustics",
    "ice glow",
    "glass transmission",
    "smoke filtered",
    "steam diffused",
    "dust scattered",
    "prism rainbow",
    
    # Gaming/Digital
    "raytraced GI",
    "screen space",
    "ambient occlusion",
    "emissive",
    "light probes",
    "lightmap",
    "vertex lighting",
    "forward rendering",
    "deferred shading",
    "voxel traced",
    
    # Experimental
    "quantum dot",
    "metamaterial",
    "photonic crystal",
    "plasmonic",
    "optical vortex",
    "structured light",
    "holographic",
    "light field",
    "plenoptic",
    "computational",
]