// api.js
export class APIClient {
  constructor() {
    this.baseURL = '/machine/api';
    this.requestCount = 0;
    this.errorCount = 0;
  }

  async request(endpoint, options = {}) {
    const requestId = ++this.requestCount;
    const startTime = performance.now();
    
    try {
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        cache: 'no-store',
        headers: {
          'Accept': 'application/json',
          ...(options.headers || {})
        },
        ...options
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      const duration = performance.now() - startTime;
      if (duration > 1000) {
        console.warn(`Slow API request #${requestId}: ${endpoint} took ${Math.round(duration)}ms`);
      }
      
      return data;
    } catch (error) {
      this.errorCount++;
      console.error(`API request #${requestId} failed: ${endpoint}`, error);
      throw error;
    }
  }

  async getTokens(limit = 24, offset = 0, options = {}) {
    const params = new URLSearchParams({
      limit: limit.toString(),
      offset: offset.toString()
    });
    
    if (options.since_id) {
      params.append('since_id', options.since_id.toString());
    }
    if (options.since_ts) {
      params.append('since_ts', options.since_ts);
    }
    
    const tokens = await this.request(`/tokens?${params}`);
      
    return tokens;
  }

  async getToken(id) {
    return this.request(`/tokens/${id}`);
  }

  async getTrendingWords(limit = 6) {
    return this.request(`/words/top?limit=${limit}`);
  }

  async getMetrics() {
    return this.request('/metrics');
  }

  async getTokensByIds(ids) {
    if (!ids || ids.length === 0) return [];
    
    try {
      return await this.request('/tokens/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids })
      });
    } catch (error) {
      console.warn('Batch endpoint not available, falling back to individual fetches');
      const results = await Promise.allSettled(
        ids.map(id => this.getToken(id))
      );
      return results
        .filter(r => r.status === 'fulfilled')
        .map(r => r.value);
    }
  }

  async findToken(criteria) {
    const params = new URLSearchParams();
    
    if (criteria.contract_address) {
      params.append('contract', criteria.contract_address);
    }
    if (criteria.image_filename) {
      params.append('filename', criteria.image_filename);
    }
    if (criteria.ticker) {
      params.append('ticker', criteria.ticker);
    }
    
    try {
      const results = await this.request(`/tokens/search?${params}`);
      return Array.isArray(results) ? results[0] : results;
    } catch (error) {
      console.error('Token search failed:', error);
      return null;
    }
  }

  async getTokensSince(timestamp, limit = 100) {
    const params = new URLSearchParams({
      since_ts: timestamp,
      limit: limit.toString()
    });
    
    try {
      return await this.request(`/tokens?${params}`);
    } catch (error) {
      console.warn('Error fetching tokens since timestamp, falling back to recent tokens', error);
      return this.getTokens(limit, 0);
    }
  }

  async healthCheck() {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 5000);
    try {
      const response = await this.request('/health', { signal: ctrl.signal });
      return response.status === 'ok' || response.healthy === true;
    } catch { 
      return false; 
    } finally { 
      clearTimeout(t); 
    }
  }

  getStats() {
    return {
      requests: this.requestCount,
      errors: this.errorCount,
      errorRate: this.requestCount > 0 
        ? `${Math.round(this.errorCount * 100 / this.requestCount)}%` 
        : '0%'
    };
  }

  resetStats() {
    this.requestCount = 0;
    this.errorCount = 0;
  }

  async getSystemStatus() {
    return this.request('/system');
  }
}