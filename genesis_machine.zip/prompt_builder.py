# prompt_builder.py
"""
Stable Diffusion 1.5 prompt builder (schema v2)
-----------------------------------------------
Implements the new prompt grammar:

[trigger], [medium/type] of [breed] [action] [environment], [attribute],
[STYLE modifiers OR ARTIST], [colour], [lighting], [camera], [quality_pair]

Selection rules:
- trigger: "cat" | "dog" (exactly once at the start)
- breed: ALWAYS one from breed.py (entries already include the animal word)
- action: ALWAYS one from action.py (gerund/verb phrase)
- environment: ALWAYS one (preposition embedded)
- attribute: ALWAYS exactly one
- medium/type: 50/50 – from style.py OR artist.py (mutually exclusive)
  * if style: use style_name as medium/type; modifiers string -> list for meta
  * if artist: use (artist_medium, artist_name); meta holds "by <artist>" string
- colour: ALWAYS one (goes after style/artist in the prompt)
- lighting: ALWAYS one
- camera: ALWAYS one
- quality: ALWAYS one tuple -> both parts used, comma-separated at the tail
- token budget: enforce CLIP 77 tokens; truncation priority:
  quality → colour → attribute → lighting/camera → environment → action → breed → medium → trigger
"""

from __future__ import annotations

import random
import logging
from typing import Any, Dict, List, Tuple, Union

# Data modules
from breed import CAT_BREEDS, DOG_BREEDS
from action import ACTIONS
from environment import ENVIRONMENTS
from attribute import ATTRIBUTES
from style import STYLES
from artist import ARTISTS
from lighting import LIGHTING
from camera import CAMERA
from colour import COLOURS
from quality import QUALITY_MODES
from config import TRIGGER_WEIGHT, BREED_WEIGHT

logger = logging.getLogger(__name__)

MAX_TOKENS_CLIP = 77  # SD/CLIP token limit per prompt segment

# Optional exact CLIP tokenizer (falls back gracefully if not available)
try:
    from transformers import CLIPTokenizerFast
    _TOKENIZER = CLIPTokenizerFast.from_pretrained(
        "openai/clip-vit-large-patch14", local_files_only=True
    )
except Exception:
    _TOKENIZER = None

# Optional metrics
try:
    from metrics import log_event
except Exception:
    def log_event(*_args, **_kwargs):
        pass

# Helpers

def _clip_token_len(text: str) -> int:
    """Count CLIP tokens (approx if tokenizer unavailable). Target ≤ 77 total."""
    if _TOKENIZER is None:
        # Conservative fallback: whitespace tokens + 2 specials
        return len(text.split()) + 2
    enc = _TOKENIZER(text, add_special_tokens=False)
    # Add 2 for [SOT]/[EOT]
    return len(enc["input_ids"]) + 2

def _apply_sd_weight(text: str, weight: float, model_key: str | None = None) -> str:
    """Emit Compel/Diffusers-compatible weighting syntax for all SD variants."""
    if abs(weight - 1.0) < 1e-2:
        return text
    weighted = f"({text}:{weight:.2f})"
    try:
        log_event("sd_weight_applied", original=text, weighted=weighted, weight=weight, model=model_key)
    except Exception:
        pass
    return weighted
    
def _assemble(parts: Dict[str, Any], keep: Dict[str, bool], model_key: str = None) -> str:
    """Build the prompt from selected components with 'keep' gating (for truncation)."""
    # Core "[medium] of [breed] [action] [environment]"
    core_chunks: List[str] = []
    if keep["medium"]:
        core_chunks.append(f"{parts['medium']} of")
    if keep["breed"]:
        weighted_breed = _apply_sd_weight(parts["breed"], BREED_WEIGHT, model_key)
        core_chunks.append(weighted_breed)
    if keep["action"]:
        core_chunks.append(parts["action"])
    if keep["environment"]:
        core_chunks.append(parts["environment"])
    core = " ".join(core_chunks).strip()

    segs: List[str] = []
    if keep["trigger"]:
        weighted_trigger = _apply_sd_weight(parts["trigger"], TRIGGER_WEIGHT, model_key)
        segs.append(weighted_trigger)
    if core:
        segs.append(core)
    if keep["attribute"]:
        segs.append(parts["attribute"])
    if parts.get("style_or_artist"):
        segs.append(parts["style_or_artist"])
    if keep["colour"]:
        segs.append(parts["colour"])
    if keep["lighting"]:
        segs.append(parts["lighting"])
    if keep["camera"]:
        segs.append(parts["camera"])
    if keep["quality"]:
        q = parts["quality"]
        segs.extend(q)
    return ", ".join([s for s in segs if s])

def _truncate_to_77(parts: Dict[str, Any], model_key: str = None) -> Tuple[str, bool, List[str]]:
    """
    Enforce CLIP 77-token limit using the specified truncation priority.
    Returns: (prompt, truncated_flag, dropped_keys in order)
    """
    keep = {
        "quality": True, "colour": True, "attribute": True,
        "lighting": True, "camera": True,
        "environment": True, "action": True, "breed": True,
        "medium": True, "trigger": True,
    }
    dropped: List[str] = []
    prompt = _assemble(parts, keep, model_key)
    if _clip_token_len(prompt) <= 77:
        return prompt, False, dropped

    # Apply priority drops
    priority: List[Union[str, Tuple[str, str]]] = [
        "quality", "colour", "attribute", ("lighting", "camera"),
        "environment", "action", "breed", "medium", "trigger",
    ]
    for item in priority:
        if isinstance(item, tuple):
            changed = False
            for k in item:
                if keep.get(k):
                    keep[k] = False
                    dropped.append(k)
                    changed = True
            if changed:
                prompt = _assemble(parts, keep, model_key)
                if _clip_token_len(prompt) <= 77:
                    return prompt, True, dropped
        else:
            if keep.get(item):
                keep[item] = False
                dropped.append(item)
                prompt = _assemble(parts, keep, model_key)
                if _clip_token_len(prompt) <= 77:
                    return prompt, True, dropped
    return prompt, True, dropped

def build_prompt(animal_class: str, seed: int = None, 
                negative_prompt: str = None, negative_prompt_variant: str = None,
                model_key: str = None) -> Dict[str, Any]:
    """
    Build SD prompt with proper component tracking.
    
    Args:
        animal_class: "cat" or "dog"
        seed: Random seed for reproducible generation
        negative_prompt: Pre-selected negative prompt from render_params
        negative_prompt_variant: The variant name from render_params
        model_key: "sd14", "sd15", or "sd21" for model-specific formatting
    Returns:
        Dictionary containing:
        - prompt: str
        - negative_prompt: str  
        - negative_prompt_variant: str
        - prompt_truncated: bool
        - truncated_components: List[str]
        - generation_meta: Dict with all selected components
        - model_key: str
    """
    # Clean input
    trigger = animal_class.strip().lower()
    if trigger not in {"cat", "dog"}:
        trigger = "cat"  

    rng = random.Random(seed)

    # Select all mandatory elements
    breed = rng.choice(CAT_BREEDS if trigger == "cat" else DOG_BREEDS)
    action = rng.choice(ACTIONS)
    environment = rng.choice(ENVIRONMENTS)
    attribute = rng.choice(ATTRIBUTES)
    lighting = rng.choice(LIGHTING)
    camera = rng.choice(CAMERA)
    quality_pair = list(rng.choice(QUALITY_MODES))
    colour = rng.choice(COLOURS)

    # 50/50 medium source selection
    if rng.random() < 0.5:
        style_name, modifiers_csv = rng.choice(STYLES)
        style_modifiers = [m.strip() for m in modifiers_csv.split(",") if m.strip()]
        medium = style_name
        style_or_artist = ", ".join(style_modifiers) if style_modifiers else style_name
        meta_extra = {
            "medium_source": "style",
            "style_name": style_name,
            "style_modifiers": style_modifiers,
            "artist_medium": None,
            "artist_name": None,
        }
        log_event("medium_source_selected", source="style")
        log_event("style_selected", name=style_name)
    else:
        artist_medium, artist_attr = rng.choice(ARTISTS)
        # Normalize artist name: strip possible leading "by "
        name_clean = artist_attr.strip()
        if name_clean.lower().startswith("by "):
            name_clean = name_clean[3:].strip()
        medium = artist_medium
        style_or_artist = f"by {name_clean}"
        meta_extra = {
            "medium_source": "artist",
            "artist_medium": artist_medium,
            "artist_name": name_clean,
            "style_name": None,
            "style_modifiers": None,
        }
        log_event("medium_source_selected", source="artist")
        log_event("artist_selected", name=name_clean)

    # Build parts dictionary for prompt assembly
    parts = {
        "trigger": trigger,
        "medium": medium,
        "breed": breed,
        "action": action,
        "environment": environment,
        "attribute": attribute,
        "style_or_artist": style_or_artist,
        "colour": colour,
        "lighting": lighting,
        "camera": camera,
        "quality": quality_pair,
    }

    # Compose prompt with CLIP token limit enforcement
    prompt, truncated, dropped = _truncate_to_77(parts, model_key)
    if truncated:
        try:
            log_event("prompt_truncated", dropped=",".join(dropped), token_len=_clip_token_len(prompt))
        except Exception:
            pass

    # Log selection metrics
    try:
        log_event("breed_selected", breed=breed)
        log_event("action_selected", action=action)
        log_event("environment_selected", environment=environment)
        log_event("attribute_selected", attribute=attribute) 
        log_event("colour_selected", colour=colour)
        log_event("lighting_selected", lighting=lighting)
        log_event("camera_selected", camera=camera)
        log_event("quality_selected", quality="|".join(quality_pair))
    except Exception:
        pass

    # Build generation_meta with all selected components
    generation_meta = {
        "trigger": trigger,
        "breed": breed,
        "action": action,
        "environment": environment,
        "attribute": attribute,
        "colour": colour,
        "lighting": lighting,
        "camera": camera,
        "quality": quality_pair,
        "seed": seed,
        "medium_source": meta_extra["medium_source"],
        "style_name": meta_extra.get("style_name"),
        "style_modifiers": meta_extra.get("style_modifiers"),
        "artist_medium": meta_extra.get("artist_medium"),
        "artist_name": meta_extra.get("artist_name"),
    }

    return {
        "prompt": prompt,
        "negative_prompt": negative_prompt, 
        "negative_prompt_variant": negative_prompt_variant, 
        "prompt_truncated": truncated,
        "truncated_components": dropped,
        "generation_meta": generation_meta,
        "model_key": model_key,  # Include in return
    }