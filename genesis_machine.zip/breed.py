# breed.py
"""
Breed Module for Stable Diffusion Prompt Generation

Contains breed modifiers for cat and dog subjects. These work in conjunction
with the LoRA trigger words "cat" and "dog" to create specific breed variations
while maintaining the core trigger that the model was trained on.

Position in prompt: Part of PRIMARY SUBJECT (combined with trigger word)
Example usage: "golden retriever dog" where "golden retriever" comes from this module

Originally extracted from inline data in prompt_builder.py
The breed is optional and controlled by probability settings in config
"""

from __future__ import annotations
from typing import Final

__all__ = ["CAT_BREEDS", "DOG_BREEDS"]

CAT_BREEDS: Final[list[str]] = [
    "tabby cat",
    "siamese cat",
    "persian cat",
    "maine coon cat",
    "british shorthair cat",
    "ragdoll cat",
    "bengal cat",
    "sphynx cat",
    "russian blue cat",
    "abyssinian cat",
    "scottish fold cat",
    "birman cat",
    "oriental shorthair cat",
    "devon rex cat",
    "himalayan cat",
    "burmese cat",
    "manx cat",
    "bombay cat",
    "munchkin cat",
    "savannah cat",
]

DOG_BREEDS: Final[list[str]] = [
    "labrador dog",
    "golden retriever dog",
    "german shepherd dog",
    "bulldog",
    "poodle dog",
    "beagle dog",
    "husky dog",
    "chihuahua dog",
    "corgi dog",
    "shiba inu dog",
    "dachshund dog",
    "pug dog",
    "dalmatian dog",
    "boxer dog",
    "great dane dog",
    "cocker spaniel dog",
    "shih tzu dog",
    "pomeranian dog",
    "yorkshire terrier dog",
    "rottweiler dog",
    "doberman dog",
    "bernese mountain dog",
    "french bulldog",
    "pit bull dog",
    "greyhound dog",
]