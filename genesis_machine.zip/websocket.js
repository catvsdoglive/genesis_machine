// websocket.js
export class WebSocketManager {
  constructor(ui, api = null) {
    this.ui = ui;
    this.api = api;
    this.ws = null;
    this.url = this._buildUrl();
    this.reconnectDelayMs = 1000;
    this.maxDelayMs = 15000;
    this.heartbeatMs = 25000;
    this.heartbeatTimer = null;
    this.watchdogTimer = null;
    this.lastMsgAt = 0;
    this.lastPingSentAt = 0;
    this.lastPongAt = 0;
    this.missedPongs = 0;
    this.requirePong = null;
    this._graceMisses = 2;
    this._idleGraceFactor = 4.0;
    this._pingSeq = 0;
    this._lastRttMs = null;
        
    this.tokenBuffer = [];
    this.bufferingEnabled = true;
    this._pipelineStageBuffered = null;
    
    this.lastSeenId = null;
    this.lastSeenTimestamp = null;
    
    this.onTokenReceived = null;
  }

  _buildUrl() {
    const isSecure = window.location.protocol === 'https:';
    const proto = isSecure ? 'wss' : 'ws';
    return `${proto}://${window.location.host}/machine/ws/`;
  }

  isConnected() {
    return !!(this.ws && this.ws.readyState === WebSocket.OPEN);
  }

  connect() {
    try {
      if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
        return;
      }
      this.ui.addTerminalLine(`ws: connecting → ${this.url}`);
      this.ws = new WebSocket(this.url);

      this.ws.addEventListener('open',  () => this._onOpen());
      this.ws.addEventListener('message', (e) => this._onMessage(e));
      this.ws.addEventListener('error', () => this._onError());
      this.ws.addEventListener('close', () => this._onClose());
    } catch (err) {
      this.ui.addTerminalLine(`ws: connect error: ${err?.message || err}`, 'error');
      this._scheduleReconnect();
    }
  }

  async _onOpen() {
    this.ui.setConnectionStatus(true);
    this.ui.addTerminalLine('ws: communion with genesis_machine achieved - the cycle beckons', 'info');
    this.reconnectDelayMs = 1000;
    this.lastMsgAt = Date.now();
    this.lastPongAt = 0;
    this.missedPongs = 0;
    this.requirePong = null;
    this._startHeartbeat();
		
    if (this.ui.binaryStreamActive) {
      this.ui.setBinaryStreamSpeed(150);
    }
    
    if (this.lastSeenId && this.api) {
      this.ui.addTerminalLine(`ws: backfilling from id ${this.lastSeenId}`, 'info');
      await this._performBackfill();
    } else if (this.lastSeenTimestamp && this.api) {
      this.ui.addTerminalLine(`ws: backfilling from timestamp ${this.lastSeenTimestamp}`, 'info');
      await this._performBackfill();
    }
  }

  async _performBackfill() {
    if (!this.api) return;
    
    try {
      let backfillTokens = [];
      
      if (this.lastSeenId) {
        backfillTokens = await this.api.getTokens(100, 0, { since_id: this.lastSeenId });
      } else if (this.lastSeenTimestamp) {
        backfillTokens = await this.api.getTokensSince(this.lastSeenTimestamp, 100);
      }
      
      if (backfillTokens && backfillTokens.length > 0) {
        this.ui.addTerminalLine(`ws: backfilled ${backfillTokens.length} tokens`, 'info');
        
        backfillTokens.forEach(token => {
          this._handleToken(token, true);
        });
      }
    } catch (error) {
      console.error('Backfill failed:', error);
      this.ui.addTerminalLine('ws: backfill failed', 'warning');
    }
  }

  _onError() {
    this.ui.addTerminalLine('ws: error', 'warning');
  }

  _onClose() {
    this.ui.setConnectionStatus(false);
    this.ui.updatePipelineStatus(null);
    this.ui.addTerminalLine('ws: disconnected', 'warning');
    this._stopHeartbeat();
    this._scheduleReconnect();
		    
    if (this.ui.binaryStreamActive) {
      this.ui.setBinaryStreamSpeed(500);
    }
  }

  _scheduleReconnect() {
    const delay = Math.min(this.reconnectDelayMs, this.maxDelayMs);
    this.ui.addTerminalLine(`ws: reconnecting in ${Math.round(delay/1000)}s…`, 'info');
    setTimeout(() => this.connect(), delay);
    this.reconnectDelayMs = Math.min(this.maxDelayMs, Math.round(this.reconnectDelayMs * (1.6 + Math.random() * 0.4)));
  }

  _startHeartbeat() {
    this._stopHeartbeat();
  
    if (this.ws?.readyState === WebSocket.OPEN) {
      try {
        const now = Date.now();
        this.lastPingSentAt = now;
        this._pingSeq++;
        this.ws.send(JSON.stringify({ type: 'ping', t: now, seq: this._pingSeq }));
      } catch {}
    }

    this.heartbeatTimer = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        try {
          const now = Date.now();
          this.lastPingSentAt = now;
          this._pingSeq++;
          this.ws.send(JSON.stringify({ type: 'ping', t: now, seq: this._pingSeq }));
        } catch {}
      }
    }, this.heartbeatMs);
    this._armWatchdog();
  }

  _stopHeartbeat() {
    if (this.heartbeatTimer) { 
      clearInterval(this.heartbeatTimer); 
      this.heartbeatTimer = null; 
    }
    if (this.watchdogTimer) { 
      clearTimeout(this.watchdogTimer); 
      this.watchdogTimer = null; 
    }
  }

  _armWatchdog() {
    if (this.watchdogTimer) clearTimeout(this.watchdogTimer);
    
    this.watchdogTimer = setTimeout(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        const now = Date.now();
        const sinceAnyMsg = now - (this.lastMsgAt || now);
        const sincePong = now - (this.lastPongAt || 0);

        if (this.requirePong === true) {
          const expectWindow = Math.round(this.heartbeatMs * 1.3);
          if (this.lastPingSentAt && sincePong > expectWindow) {
            this.missedPongs += 1;
            this.ui.addTerminalLine(`ws: missed pong #${this.missedPongs} (RTT=${this._lastRttMs ?? '-'} ms)`, 'warning');
          } else if (this.lastPongAt) {
            this.missedPongs = 0;
          }
          if (this.missedPongs >= this._graceMisses) {
            this.ui.addTerminalLine('ws: consecutive missed pongs → reconnect', 'warning');
            try { this.ws.close(); } catch {}
            return;
          }
        } else {
          const idleCloseMs = Math.round(this.heartbeatMs * this._idleGraceFactor);
          if (sinceAnyMsg >= idleCloseMs) {
            this.ui.addTerminalLine('ws: idle timeout (no inbound msgs) → reconnect', 'warning');
            try { this.ws.close(); } catch {}
            return;
          }
        }
        this._armWatchdog();
      }
    }, this.heartbeatMs * 2.2);
  }

  _validateToken(token) {
    const hasId = token.id !== undefined && token.id !== null;
    const hasPrompt = token.prompt !== undefined && token.prompt !== null;
  
    if (!hasId || !hasPrompt) {
      console.warn('Partial token received:', {
        ticker: token.ticker,
        hasId,
        hasPrompt
      });
    }
  
    return {
      isValid: hasId || hasPrompt || token.ticker || token.name,
      isPartial: !hasId || !hasPrompt
    };
  }

  _handleToken(token, fromBackfill = false) {
    if (token.id) {
      this.lastSeenId = token.id;
    }
    if (token.created_at) {
      this.lastSeenTimestamp = token.created_at;
    }
    
    if (this.bufferingEnabled && !fromBackfill) {
      if (this.tokenBuffer.length >= 100) {
        console.warn('Buffer overflow, dropping oldest token');
        this.tokenBuffer.shift();
      }
      this.tokenBuffer.push(token);
      console.log(`Buffered token ${token.id || token.ticker}, buffer size: ${this.tokenBuffer.length}`);
      return;
    }
    
    if (this.onTokenReceived) {
      this.onTokenReceived(token);
    } else {
      this.ui.createTokenCard(token);
    }
  }

  _onMessage(e) {
    this.lastMsgAt = Date.now();
    this._armWatchdog();

    let msg = null;
    try { 
      msg = JSON.parse(typeof e.data === 'string' ? e.data : ''); 
    } catch { 
      msg = { type: 'log', level: 'info', message: String(e.data) }; 
    }

    const type = msg.type || msg.event || msg.kind;

    if (type === 'hello') {
      const hinted = parseInt(msg.heartbeat_ms, 10);
      if (Number.isFinite(hinted) && hinted >= 5000 && hinted <= 120000) {
        if (hinted !== this.heartbeatMs) {
          this.heartbeatMs = hinted;
          this.ui.addTerminalLine(`ws: server heartbeat = ${hinted}ms`, 'info');
          this._startHeartbeat();
        }
      }
    
      if (msg.message) {
        this.ui.addTerminalLine(msg.message, 'operator');
      }
      
      // Apply current stage from hello message immediately
      if (msg.current_stage) {
        console.log('Hello message contains current stage:', msg.current_stage);
        this._pipelineStageBuffered = msg.current_stage;
        
        // Apply immediately if not buffering
        if (!this.bufferingEnabled) {
          this._applyPipelineStage(msg.current_stage);
        }
      }

      this.ui.addTerminalLine('ws: acknowledged operator - UI systems synced, ready to display freshly minted memes', 'info');
      return;
    }
    
    if (type === 'pong') {
      const now = Date.now();
      this.lastPongAt = now;
      const t = Number(msg.t);
      if (Number.isFinite(t)) this._lastRttMs = Math.max(0, now - t);
      
      if (this.requirePong !== true) {
        this.requirePong = true;
        this.ui.addTerminalLine('ws: ping/pong duality achieved - genesis_machine mirrors our existence', 'info');
      }
      return;
    }
    
    if (type === 'heartbeat' || type === 'ready') {
      this.ui.addTerminalLine(`ws: ${type}`);
      return;
    }

    if (type === 'pipeline' || type === 'pipeline_step' || type === 'stage') {
      const stageRaw = (msg.stage || msg.step || msg.phase || '').toLowerCase().trim();
      
      console.log('Pipeline update received:', {
        raw: stageRaw,
        buffering: this.bufferingEnabled,
        replayed: msg.replayed
      });
      
      // Always update the last known stage
      if (stageRaw) {
        this._pipelineStageBuffered = stageRaw;
      }
      
      // Apply immediately if not buffering OR if this is a replay from hello message
      if (!this.bufferingEnabled || msg.replayed) {
        this._applyPipelineStage(stageRaw);
        
        if (stageRaw && stageRaw !== 'idle' && stageRaw !== 'done') {
          localStorage.setItem('lastPipelineStage', stageRaw);
        } else if (stageRaw === 'idle' || stageRaw === 'done') {
          localStorage.removeItem('lastPipelineStage');
        }
      }
      return;
    }

    if (type === 'metrics' || type === 'stats') {
      const payload = msg.metrics || msg.data || msg;
      
      if (payload && payload.kind === 'system') {
        const systemData = {
          cpu: payload.cpu,
          mem: payload.mem,
          load: payload.load,
          uptime_seconds: payload.uptime_seconds
        };
        this.ui.renderSystemMetrics(systemData);
      } else {
        this.ui.renderMetrics(payload);
      }
      return;
    }

    if (type === 'token') {
      const tok = msg.token || msg.data || msg;
      
      const validation = this._validateToken(tok);
      
      if (validation.isValid) {
        this._handleToken(tok);
        
        if (validation.isPartial && this.api) {
          this._attemptHydration(tok);
        }
      } else {
        console.error('Invalid token structure:', tok);
        this.ui.addTerminalLine('ws: received malformed token', 'error');
      }
      return;
    }

    if (type === 'top_words' || (Array.isArray(msg.words) && msg.words.length)) {
      this.ui.renderWordPool(msg.words);
      return;
    }

    if (type === 'log') {
      const level = (msg.level || type).toLowerCase();
      let terminalType = level === 'warn' ? 'warning' : level;

      const messageText = msg.message || JSON.stringify(msg);

      // Detect messages originating from operator_messages.py via common fields
      const f = String(msg.file || msg.filename || '');
      const meta = [
        msg.module, msg.logger, msg.origin, msg.src, msg.source, msg.path
      ].filter(Boolean).join(' ');
      const isOperatorMsg =
        /(^|[\\/])operator_messages\.py$/.test(f) ||
        /\boperator_messages(\.py)?\b/.test(meta) ||
        /\boperator_messages\.py\b/.test(messageText) ||
        msg.tag === 'operator' || msg.kind === 'operator';

      if (isOperatorMsg) {
        // Keep backend prefix for consistency with source parsing,
        // but the UI will render this as "DREAMING:" with yellow color.
        const dreamingMsg = messageText.startsWith('backend:')
          ? messageText
          : `backend: ${messageText}`;
        this.ui.addTerminalLine(dreamingMsg, 'dreaming');
        return;
      }

      const prefixedMessage = messageText.startsWith('backend:') ? 
        messageText : `backend: ${messageText}`;

      this.ui.addTerminalLine(prefixedMessage, terminalType);
      return;
    }

    this.ui.addTerminalLine(`ws: unhandled message ${JSON.stringify(msg).slice(0, 200)}`, 'warning');
  }

  async _attemptHydration(partialToken) {
    if (!this.api || !partialToken) return;
  
    try {
      const identifier = partialToken.id ||
                        partialToken.image_filename || 
                        partialToken.contract_address ||
                        `${partialToken.ticker}_${partialToken.name}`;
    
      if (!identifier) return;
    
      let fullToken = null;
      
      if (partialToken.id) {
        fullToken = await this.api.getToken(partialToken.id);
      } else {
        const criteria = {};
        if (partialToken.contract_address) criteria.contract_address = partialToken.contract_address;
        if (partialToken.image_filename) criteria.image_filename = partialToken.image_filename;
        if (partialToken.ticker) criteria.ticker = partialToken.ticker;
      
        if (Object.keys(criteria).length > 0) {
          fullToken = await this.api.findToken(criteria);
        }
      }
    
      if (fullToken) {
        const hydrated = { ...partialToken, ...fullToken, _hydrated: true };
      
        if (this.ui && this.ui.computeKeyFromRaw && this.ui.rekeyCard) {
          const oldKey = this.ui.computeKeyFromRaw(partialToken);
          const newKey = this.ui.computeKeyFromRaw(hydrated);
          this.ui.rekeyCard(oldKey, newKey);
        }
      
        if (this.onTokenReceived) {
          this.onTokenReceived(hydrated);
        } else {
          this.ui.createTokenCard(hydrated);
        }
      }
    } catch (error) {
      console.warn('Hydration failed:', error);
    }
  }

  _applyPipelineStage(rawStage) {
    const s = (rawStage || '').toLowerCase().trim();
    
    // Don't apply empty stages
    if (!s) {
      console.warn('Empty pipeline stage received');
      return;
    }
    
    console.log(`Applying pipeline stage: ${s}`);
    
    // Clear status if idle/done
    if (s === 'idle' || s === 'done') {
      this.ui.updatePipelineStatus(null);
      return;
    }
    
    // Apply the stage
    this.ui.updatePipelineStatus(s);
  }

  setBuffering(enabled) {
    const wasBuffering = this.bufferingEnabled;
    this.bufferingEnabled = enabled;
    
    console.log(`Buffering ${enabled ? 'enabled' : 'disabled'}, last stage: ${this._pipelineStageBuffered}`);
    
    if (!enabled && wasBuffering) {
      // Flush tokens first
      if (this.tokenBuffer.length > 0) {
        this.ui.addTerminalLine(`ws: flushing ${this.tokenBuffer.length} buffered tokens`, 'info');
        this.flushBuffer();
      }
      
      // Then apply the last known pipeline stage
      if (this._pipelineStageBuffered !== null && this._pipelineStageBuffered !== undefined) {
        console.log(`Applying buffered pipeline stage: ${this._pipelineStageBuffered}`);
        this._applyPipelineStage(this._pipelineStageBuffered);
      }
    }
  }

  flushBuffer() {
    const tokens = [...this.tokenBuffer];
    this.tokenBuffer = [];
    
    tokens.forEach(token => {
      if (this.onTokenReceived) {
        this.onTokenReceived(token);
      } else {
        this.ui.createTokenCard(token);
      }
    });
  }

  getBufferedTokens() {
    return [...this.tokenBuffer];
  }

  getTokenStats() {
    return {
      lastSeenId: this.lastSeenId,
      bufferSize: this.tokenBuffer.length
    };
  }

  setHeartbeatMs(ms) {
    const v = Number(ms);
    if (Number.isFinite(v) && v >= 5000) {
      this.heartbeatMs = v;
      if (this.isConnected()) this._startHeartbeat();
    }
  }

  shutdown() {
    this._stopHeartbeat();
    if (this.ws) {
      try { 
        this.ws.close(1000, 'client-shutdown'); 
      } catch {}
      this.ws = null;
    } 
  }
}