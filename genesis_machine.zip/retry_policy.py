# retry_policy.py
"""
Provides decorators for retrying functions with exponential backoff using Tenacity.
Compatibility:
- Tenacity 9.1.2
  * before_sleep(rs: RetryCallState) → attempt logging and reason visibility
  * retry_error_callback(rs: RetryCallState) → final-failure metric on give-up
"""

from __future__ import annotations
import json
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    RetryCallState,
)
from config import RETRY_MAX_ATTEMPTS, RETRY_BACKOFF_SEC
from loguru import logger

# Optional metrics import with fallback no-op
try:
    from metrics import log_event
except Exception:
    def log_event(*_a, **_k):
        pass

def _before_sleep(rs: RetryCallState) -> None:
    """
    Log attempt counters and reasons; emit metrics for observability.
    Called by Tenacity right before sleeping between retries.
    """
    fn_name = getattr(rs.fn, "__name__", "unknown")
    att = rs.attempt_number
    max_att = RETRY_MAX_ATTEMPTS
    err = rs.outcome.exception() if rs.outcome else None
    eta = getattr(rs.next_action, "sleep", None)
    logger.warning(
        "Retrying {} attempt {}/{} in ~{}s due to: {}",
        fn_name, att, max_att, eta, err
    )
    try:
        log_event(
            "retry",
            function=fn_name,
            attempt=att,
            max_attempts=max_att,
            reason=str(err),
        )
    except Exception:
        pass

def _on_giveup(rs: RetryCallState):
    """
    Final-failure callback: emit a metric and preserve prior behavior by
    re-raising the last exception (so callers observe the same failure mode).
    """
    fn_name = getattr(rs.fn, "__name__", "unknown")
    att = rs.attempt_number
    err = rs.outcome.exception() if rs.outcome else None
    logger.error("Final failure in {} after {} attempts: {}", fn_name, att, err)
    try:
        log_event("retry_giveup", function=fn_name, attempts=att, reason=str(err))
    except Exception:
        pass
    
    # Preserve original semantics: raise the last exception after metrics/logs.
    if err is not None:
        raise err
    # Edge case: if no exception (unexpected), return the last result if present.
    return rs.outcome.result() if rs.outcome else None

# Define a generic retry decorator for functions that may fail transiently
retry_decorator = retry(
    reraise=True,
    stop=stop_after_attempt(RETRY_MAX_ATTEMPTS),
    wait=wait_exponential(multiplier=RETRY_BACKOFF_SEC, min=RETRY_BACKOFF_SEC),
    retry=retry_if_exception_type((ValueError, json.JSONDecodeError)),
    before_sleep=_before_sleep,
    retry_error_callback=_on_giveup,
)

def retryable(fn):
    """
    Decorator to apply retry logic to any function that may throw exceptions.
    Usage:
        @retryable
        def fetch_data():
            ...
    """
    return retry_decorator(fn)