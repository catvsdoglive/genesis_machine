# api_server.py
"""
FastAPI REST API for Meme Factory.
Serves token data, metrics, and system status.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional, Literal
import json
import os

import sqlite3
from fastapi import Depends, FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from output_saver import configure_sqlite_connection

from config import (
    DB_PATH,
    SQLITE_JOURNAL_MODE,
    SQLITE_SYNCHRONOUS,
    SQLITE_BUSY_TIMEOUT_MS,
    SQLITE_WAL_AUTOCHECKPOINT,
)

import output_saver  # bootstrap: ensures DB file + meme_tokens table + indexes on first import

from system_monitor import (
    get_memory_stats,
    get_cpu_usage_percent,
    get_uptime_seconds,
    get_load_average
)

from meme_factory import serialize_token_for_wire  # single source of truth

try:
    from fetch_top_words import fetch_top_words
except ImportError:  # Specific exception for missing module
    def fetch_top_words() -> List[str]:
        return []


# SQLite connection management

def _connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH), timeout=5.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    configure_sqlite_connection(conn, busy_ms=SQLITE_BUSY_TIMEOUT_MS)
    
    return conn


def get_db() -> Iterable[sqlite3.Connection]:
    """FastAPI dependency for per-request database connection."""
    conn = _connect_db()
    try:
        yield conn
    finally:
        try:
            conn.close()
        except Exception:
            pass


# Response models

class MemeToken(BaseModel):
    """Token model with flattened metadata fields and generation context."""
    # core
    id: int
    name: Optional[str] = None
    ticker: Optional[str] = None
    description: Optional[str] = None
    contract_address: Optional[str] = None
    animal_class: Optional[str] = None
    image_filename: Optional[str] = None
    image_path: Optional[str] = None
    created_at: Optional[str] = Field(None, description="unix epoch seconds or ISO string")
    lora_id: Optional[str] = None

    # SD parameters
    cfg_scale: Optional[float] = None
    lora_scale: Optional[float] = None
    steps: Optional[int] = None
    seed: Optional[int] = None
    sampler: Optional[str] = None
    model: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None

    prompt: Optional[str] = None
    negative_prompt: Optional[str] = None
    negative_prompt_base: Optional[str] = None

    # LLM parameters
    llm_model: Optional[str] = None
    llm_temperature: Optional[float] = None
    llm_top_p: Optional[float] = None
    llm_presence_penalty: Optional[float] = None
    llm_frequency_penalty: Optional[float] = None
    llm_repeat_penalty: Optional[float] = None
    llm_max_tokens: Optional[int] = None
    llm_seed: Optional[int] = None

    # Image generation meta (JSON)
    generation_meta: Optional[Dict[str, Any]] = None
    
    # LLM generation context
    trending_words_shown: Optional[List[str]] = None
    trending_words_all: Optional[List[str]] = None
    user_prompt: Optional[str] = None
    template_key: Optional[str] = None
    trending_words_count: Optional[int] = None
    name_style_target: Optional[Literal["oneword", "spaced", "camel"]] = None
    persona_text: Optional[str] = None
    persona_index: Optional[int] = None
    description_style: Optional[str] = None
    persona_weight: Optional[float] = None
    style_weight: Optional[float] = None
    
    # SD generation context
    negative_prompt_variant: Optional[Literal["clean_glossy", "text_heavy", "degraded_retro", "disabled"]] = None
    lora_disabled: Optional[bool] = None
    prompt_truncated: Optional[bool] = None
    truncated_components: Optional[List[str]] = None

class MetricsResponse(BaseModel):
    tokens_generated: int
    gen_rate_per_24h: int
    cat_dog_ratio: str
    avg_gen_time: float

class BatchRequest(BaseModel):
    ids: List[int]

class HealthResponse(BaseModel):
    status: str
    healthy: bool
    db_rows: Optional[int] = None

class SystemCPU(BaseModel):
    usage_percent: float

class SystemMem(BaseModel):
    total_bytes: int
    used_bytes: int
    available_bytes: int
    used_percent: float

class SystemLoad(BaseModel):
    load_avg_1m: float
    load_avg_5m: float
    load_avg_15m: float

class SystemStatus(BaseModel):
    cpu: SystemCPU
    mem: SystemMem
    load: SystemLoad
    uptime_seconds: float


# Metrics computation

def _dt_from_iso(s: str) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None


def _compute_avg_interarrival_seconds(timestamps_iso: List[str]) -> float:
    """Calculate average time between token generations."""
    if len(timestamps_iso) < 2:
        return 0.0
    dts = [dt for dt in (_dt_from_iso(s) for s in timestamps_iso) if dt is not None]
    if len(dts) < 2:
        return 0.0
    dts.sort()
    deltas = []
    for a, b in zip(dts[:-1], dts[1:]):
        deltas.append((b - a).total_seconds())
    return float(sum(deltas) / len(deltas)) if deltas else 0.0


def _compute_metrics(conn: sqlite3.Connection) -> MetricsResponse:
    cur = conn.cursor()
    try:
        # Total tokens
        cur.execute("SELECT COUNT(*) AS c FROM meme_tokens;")
        total = int(cur.fetchone()["c"])

        # Last 24h
        now = datetime.now(timezone.utc)
        since = (now - timedelta(hours=24)).isoformat()
        cur.execute(
            "SELECT COUNT(*) AS c FROM meme_tokens WHERE created_at >= ?;",
            (since,),
        )
        last24 = int(cur.fetchone()["c"])

        # Cat/Dog ratio
        cur.execute(
            """
            SELECT
                SUM(CASE WHEN LOWER(animal_class)='cat' THEN 1 ELSE 0 END) AS cats,
                SUM(CASE WHEN LOWER(animal_class)='dog' THEN 1 ELSE 0 END) AS dogs
            FROM meme_tokens;
            """
        )
        row = cur.fetchone()
        cats = int(row["cats"] or 0)
        dogs = int(row["dogs"] or 0)
        denom = max(cats + dogs, 1)
        cat_pct = round(100.0 * cats / denom)
        dog_pct = 100 - int(cat_pct)
        ratio = f"{cat_pct}% / {dog_pct}%"

        # Average inter-arrival time
        N = 20
        cur.execute(
            "SELECT created_at FROM meme_tokens ORDER BY created_at DESC LIMIT ?;",
            (N,),
        )
        ts = [r["created_at"] for r in cur.fetchall()]
        avg_secs = _compute_avg_interarrival_seconds(ts)

        return MetricsResponse(
            tokens_generated=total,
            gen_rate_per_24h=last24,
            cat_dog_ratio=ratio,
            avg_gen_time=round(avg_secs, 2),
        )
    finally:
        try:
            cur.close()
        except Exception:
            pass


def _row_to_token(row: sqlite3.Row) -> MemeToken:
    """Convert database row to API response model using unified serializer."""
    # Use the unified serializer to ensure REST returns the exact same structure as WS
    try:
        serialized = serialize_token_for_wire(row)
        # Handle generation_meta separately if it exists
        d = dict(row)
        gm = d.get("generation_meta")
        if isinstance(gm, str) and gm.strip():
            try:
                serialized["generation_meta"] = json.loads(gm)
            except Exception:
                serialized["generation_meta"] = None
        else:
            serialized["generation_meta"] = None
        return MemeToken(**serialized)
    except Exception:
        # Direct conversion if serializer not available
        d = dict(row)
        gm = d.get("generation_meta")
        if isinstance(gm, str) and gm.strip():
            try:
                d["generation_meta"] = json.loads(gm)
            except Exception:
                d["generation_meta"] = None
        else:
            d["generation_meta"] = None
        return MemeToken(**d)


# FastAPI application

app = FastAPI(
    title="Meme Factory API",
    version="1.2.0",
    description="REST API for meme token data and metrics.",
)


# API routes

@app.get("/api/tokens", response_model=List[MemeToken])
def list_tokens(
    limit: int = Query(24, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    since_id: Optional[int] = Query(None, description="Return tokens with ID > since_id"),
    since_ts: Optional[str] = Query(None, description="Return tokens created after timestamp"),
    db: sqlite3.Connection = Depends(get_db),
) -> List[MemeToken]:
    """List tokens with pagination and optional cursor-based filtering."""
    try:
        cur = db.cursor()
        
        where_clauses = []
        params = []
        
        if since_id is not None:
            where_clauses.append("id > ?")
            params.append(since_id)
        
        if since_ts is not None:
            where_clauses.append("created_at > ?")
            params.append(since_ts)
        
        where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
        
        query = f"""
            SELECT
                id, name, ticker, description, contract_address, animal_class,
                image_filename, image_path, created_at, lora_id,
                cfg_scale, lora_scale, steps, seed, sampler, model, width, height,
                prompt, negative_prompt, negative_prompt_base,
                llm_model, llm_temperature, llm_top_p, llm_presence_penalty,
                llm_frequency_penalty, llm_repeat_penalty, llm_max_tokens, llm_seed,
                generation_meta,
                trending_words_shown, trending_words_all, user_prompt, template_key,
                trending_words_count, name_style_target, persona_text, persona_index, description_style,
                persona_weight, style_weight,
                negative_prompt_variant, lora_disabled, prompt_truncated, truncated_components
            FROM meme_tokens
            {where_sql}
            ORDER BY id DESC, created_at DESC
            LIMIT ? OFFSET ?
        """
        
        params.extend([limit, offset])
        cur.execute(query, params)
        rows = cur.fetchall()
        
        return [_row_to_token(r) for r in rows]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error: {e}")
    finally:
        try:
            cur.close()
        except Exception:
            pass


@app.get("/api/tokens/{token_id}", response_model=MemeToken)
def get_token(
    token_id: int,
    db: sqlite3.Connection = Depends(get_db),
) -> MemeToken:
    """Get a specific token by ID."""
    try:
        cur = db.cursor()
        cur.execute(
            """
            SELECT
                id, name, ticker, description, contract_address, animal_class,
                image_filename, image_path, created_at, lora_id,
                cfg_scale, lora_scale, steps, seed, sampler, model, width, height,
                prompt, negative_prompt, negative_prompt_base,
                llm_model, llm_temperature, llm_top_p, llm_presence_penalty,
                llm_frequency_penalty, llm_repeat_penalty, llm_max_tokens, llm_seed,
                generation_meta,
                trending_words_shown, trending_words_all, user_prompt, template_key,
                trending_words_count, name_style_target, persona_text, persona_index, description_style,
                persona_weight, style_weight,
                negative_prompt_variant, lora_disabled, prompt_truncated, truncated_components
            FROM meme_tokens
            WHERE id = ?
            """,
            (token_id,),
        )
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Token not found")
        
        return _row_to_token(row)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error: {e}")
    finally:
        try:
            cur.close()
        except Exception:
            pass


@app.get("/api/tokens/search", response_model=List[MemeToken])
def search_tokens(
    contract: Optional[str] = Query(None, description="Contract address"),
    filename: Optional[str] = Query(None, description="Image filename"),
    ticker: Optional[str] = Query(None, description="Token ticker"),
    limit: int = Query(10, ge=1, le=100),
    db: sqlite3.Connection = Depends(get_db),
) -> List[MemeToken]:
    """Search tokens by contract, filename, or ticker."""
    try:
        if not any([contract, filename, ticker]):
            raise HTTPException(status_code=400, detail="At least one search parameter required")
        
        cur = db.cursor()
        
        where_clauses = []
        params = []
        
        if contract:
            where_clauses.append("contract_address = ?")
            params.append(contract)
        if filename:
            where_clauses.append("image_filename = ?")
            params.append(filename)
        if ticker:
            where_clauses.append("ticker = ?")
            params.append(ticker)
        
        where_sql = f"WHERE {' OR '.join(where_clauses)}"
        
        query = f"""
            SELECT
                id, name, ticker, description, contract_address, animal_class,
                image_filename, image_path, created_at, lora_id,
                cfg_scale, lora_scale, steps, seed, sampler, model, width, height,
                prompt, negative_prompt, negative_prompt_base,
                llm_model, llm_temperature, llm_top_p, llm_presence_penalty,
                llm_frequency_penalty, llm_repeat_penalty, llm_max_tokens, llm_seed,
                generation_meta,
                trending_words_shown, trending_words_all, user_prompt, template_key,
                trending_words_count, name_style_target, persona_text, persona_index, description_style,
                persona_weight, style_weight,
                negative_prompt_variant, lora_disabled, prompt_truncated, truncated_components
            FROM meme_tokens
            {where_sql}
            ORDER BY id DESC, created_at DESC
            LIMIT ?
        """
        
        params.append(limit)
        cur.execute(query, params)
        rows = cur.fetchall()
        
        return [_row_to_token(r) for r in rows]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error: {e}")
    finally:
        try:
            cur.close()
        except Exception:
            pass


@app.post("/api/tokens/batch", response_model=List[MemeToken])
def get_tokens_batch(
    request: BatchRequest,
    db: sqlite3.Connection = Depends(get_db),
) -> List[MemeToken]:
    """Get multiple tokens by IDs."""
    try:
        if not request.ids:
            return []
        
        cur = db.cursor()
        
        placeholders = ','.join('?' * len(request.ids))
        
        cur.execute(
            f"""
            SELECT
                id, name, ticker, description, contract_address, animal_class,
                image_filename, image_path, created_at, lora_id,
                cfg_scale, lora_scale, steps, seed, sampler, model, width, height,
                prompt, negative_prompt, negative_prompt_base,
                llm_model, llm_temperature, llm_top_p, llm_presence_penalty,
                llm_frequency_penalty, llm_repeat_penalty, llm_max_tokens, llm_seed,
                generation_meta,
                trending_words_shown, trending_words_all, user_prompt, template_key,
                trending_words_count, name_style_target, persona_text, persona_index, description_style,
                persona_weight, style_weight,
                negative_prompt_variant, lora_disabled, prompt_truncated, truncated_components
            FROM meme_tokens
            WHERE id IN ({placeholders})
            ORDER BY created_at DESC
            """,
            request.ids,
        )
        rows = cur.fetchall()
        
        return [_row_to_token(r) for r in rows]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB error: {e}")
    finally:
        try:
            cur.close()
        except Exception:
            pass


@app.get("/api/metrics", response_model=MetricsResponse)
def get_metrics(db: sqlite3.Connection = Depends(get_db)) -> MetricsResponse:
    """Get generation metrics."""
    try:
        return _compute_metrics(db)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Metrics error: {e}")

@app.get("/api/words/top")
def get_top_words(
limit: int = Query(6, ge=1, le=100)
) -> Dict[str, List[str]]:
    """Get trending words."""
    try:
        words = fetch_top_words() or []
        return {"words": words[:limit]}
    except Exception:
        return {"words": []}

@app.get("/api/health", response_model=HealthResponse)
def health_check(db: sqlite3.Connection = Depends(get_db)) -> HealthResponse:
    """Health check endpoint."""
    try:
        cur = db.cursor()
        cur.execute("SELECT COUNT(*) AS c FROM meme_tokens;")
        total = int(cur.fetchone()["c"])
         
        return HealthResponse(
            status="ok",
            healthy=True,
            db_rows=total
        )
    except Exception as e:
        return HealthResponse(
            status="error",
            healthy=False,
            db_rows=None
        )
    finally:
        try:
            cur.close()
        except Exception:
            pass

@app.get("/api/system", response_model=SystemStatus)
def get_system_status() -> SystemStatus:
    """Get system resource usage."""
    try:
        cpu = SystemCPU(usage_percent=round(get_cpu_usage_percent(0.1), 2))
        mem = SystemMem(**get_memory_stats())
        up = get_uptime_seconds()
        l1, l5, l15 = get_load_average()
        return SystemStatus(
            cpu=cpu, 
            mem=mem, 
            load=SystemLoad(load_avg_1m=l1, load_avg_5m=l5, load_avg_15m=l15), 
            uptime_seconds=up
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"System status error: {e}")

@app.get("/api/system/cpu", response_model=SystemCPU)
def get_system_cpu() -> SystemCPU:
    """Get CPU usage."""
    try:
        return SystemCPU(usage_percent=round(get_cpu_usage_percent(0.1), 2))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"CPU error: {e}")

@app.get("/api/system/mem", response_model=SystemMem)
def get_system_mem() -> SystemMem:
    """Get memory usage."""
    try:
        return SystemMem(**get_memory_stats())  # ✅ FIXED: Convert dict to SystemMem
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Memory error: {e}")

@app.get("/api/system/load", response_model=SystemLoad)
def get_system_load() -> SystemLoad:
    """Get load averages."""
    try:
        l1, l5, l15 = get_load_average()
        return SystemLoad(load_avg_1m=l1, load_avg_5m=l5, load_avg_15m=l15)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Load error: {e}")