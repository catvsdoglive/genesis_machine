# quality.py
"""
Quality Module for Stable Diffusion 1.5 Prompt Generation (Optimized)

Compressed quality modifiers using SD1.5 tag format.
Returns tuples with both parts optimized for token efficiency.

Position in prompt: LAST - always at the end
Token budget: 2-3 tokens per quality pair
"""

from __future__ import annotations
from typing import Final

__all__ = ["QUALITY_MODES"]

QUALITY_MODES: Final[list[tuple[str, str]]] = [
    # Core Quality
    ("masterpiece", "best quality"),
    ("high quality", "finished"),
    ("ultra-detailed", "intricate"),
    ("high resolution", "8k"),
    ("clean", "noise-free"),
    ("professional", "editorial"),
    ("highly detailed", "intricate"),
    ("award winning", "masterwork"),
    ("museum quality", "fine art"),
    ("gallery worthy", "exhibition"),
    ("professional", "commission"),
    ("portfolio", "showcase"),
    
    # Resolution & Clarity
    ("8k resolution", "ultra detailed"),
    ("4k wallpaper", "high res"),
    ("hyperrealistic", "photorealistic"),
    ("sharp focus", "tack sharp"),
    ("crisp", "sharp"),
    ("perfect clarity", "crystal clear"),
    ("high fidelity", "premium"),
    ("ultra crisp", "razor sharp"),
    ("extreme detail", "micro"),
    ("hyper detailed", "ultra sharp"),
    ("fine details", "precise"),
    
    # Rendering Quality
    ("flawless", "pristine"),
    ("meticulous", "careful"),
    ("exquisite", "refined"),
    ("immaculate", "perfect"),
    ("superb", "polished"),
    ("perfect shading", "realistic"),
    ("smooth gradients", "clean"),
    ("refined shading", "subtle"),
    ("perfect rendering", "flawless"),
    
    # Color & Tone
    ("vibrant", "rich"),
    ("vivid", "saturated"),
    ("natural colors", "accurate"),
    ("balanced", "natural"),
    ("perfect color", "true"),
    ("rich depth", "full spectrum"),
    ("clean whites", "deep blacks"),
    ("tonal balance", "rich"),
    ("color accurate", "faithful"),
    
    # Technical Excellence
    ("perfect exposure", "balanced"),
    ("optimal lighting", "ideal"),
    ("noise reduced", "artifact-free"),
    ("anti-aliased", "smooth"),
    ("HDR", "full range"),
    ("extended range", "detail preserved"),
    ("perfect focus", "optimal"),
    ("uniform clarity", "consistent"),
    ("detail preserved", "clarity"),
    
    # Trending/Popular
    ("trending artstation", "popular"),
    ("trending pixiv", "featured"),
    ("trending deviantart", "daily deviation"),
    ("trending behance", "staff pick"),
    ("instagram worthy", "social ready"),
    ("pinterest aesthetic", "curated"),
    ("viral", "trending"),
    ("editor's choice", "featured"),
    ("hall of fame", "legendary"),
    
    # Professional Standards
    ("broadcast quality", "production"),
    ("print quality", "publication"),
    ("archival", "museum"),
    ("reference", "documentation"),
    ("commercial", "client ready"),
    ("exhibition", "gallery"),
    ("collector", "investment"),
    ("competition", "award"),
    
    # Photographic Quality
    ("dslr quality", "camera"),
    ("medium format", "large sensor"),
    ("raw quality", "uncompressed"),
    ("lossless", "full data"),
    ("film quality", "cinematic"),
    ("studio quality", "controlled"),
    ("professional photo", "commercial"),
    
    # Digital Quality
    ("vector quality", "scalable"),
    ("uncompressed", "full"),
    ("lossless render", "maximum"),
    ("ray traced", "accurate"),
    ("path traced", "GI"),
    ("production", "industry"),
    ("final", "delivery"),
    
    # Clarity Descriptors
    ("pristine", "perfect"),
    ("optical", "lens-like"),
    ("microscopic", "extreme"),
    ("surgical", "exact"),
    ("laser", "perfect"),
    ("diamond", "flawless"),
    ("crystal", "perfect"),
    
    # Finish Quality
    ("polished", "refined"),
    ("smooth", "even"),
    ("perfect", "flawless"),
    ("professional", "commercial"),
    ("premium", "luxury"),
    ("impeccable", "perfect"),
    ("refined", "sophisticated"),
    
    # Overall Excellence
    ("exceptional", "outstanding"),
    ("superior", "excellent"),
    ("premium", "top tier"),
    ("ultimate", "highest"),
    ("supreme", "unmatched"),
    ("peak", "maximum"),
    ("optimal", "best"),
    ("perfect", "flawless"),
]