// ui.js
export class UIManager {
   constructor() {
     this._elementsCache = null;
     this._initialized = false;
 
     this.tokenStore = new Map();
     this.cardsByKey = new Map();
     
     this.detailsModal = null;
     this.currentModalCard = null;
 
     this.apiClient = null;
     
     this.globalTooltip = null;
     
     this.binaryStreamInterval = null;
     this.binaryStreamActive = false;
     this.binaryStreamSpeed = 200;
   }
 
			get elements() {
					if (!this._elementsCache) {
							this._elementsCache = {
									connectionDot: document.getElementById('connection-dot'),
									connectionText: document.getElementById('connection-text'),
									tokenCount: document.getElementById('token-count'),
									tokensToday: document.getElementById('tokens-today'),
									avgTime: document.getElementById('avg-time'),
									tokenGrid: document.getElementById('token-grid'),
									terminal: document.getElementById('terminal'),
									wordPool: document.getElementById('word-pool'),
									loading: document.getElementById('loading'),
									systemStatus: document.getElementById('system-status')
							};
					}
					return this._elementsCache;
			}

			initialize() {
					if (this._initialized) return;
					
					this._elementsCache = null;
					const _ = this.elements;
					
					this.globalTooltip = this._ensureGlobalTooltip();
					
					this._initialized = true;
			}

  _sanitizeDescription(text) {
    const withoutControls = String(text ?? '')
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
    
    const withoutLiteralB = withoutControls.replace(/\\\s*b/g, '');
    
    const commaNoBreak = withoutLiteralB.replace(/,\s*\n+/g, ', ');
    
    return commaNoBreak;
  }

  _ensureGlobalTooltip() {
    let el = document.getElementById('global-description-tooltip');
    if (!el) {
      el = document.createElement('div');
      el.id = 'global-description-tooltip';
      el.setAttribute('role', 'tooltip');
      el.setAttribute('aria-hidden', 'true');
      document.body.appendChild(el);
    }
    
    const hide = () => { 
      el.dataset.show = 'false'; 
      el.setAttribute('aria-hidden', 'true'); 
    };
    
    if (!el._bound) {
      window.addEventListener('resize', hide, { passive: true });
      document.addEventListener('scroll', hide, { passive: true, capture: true });
      document.addEventListener('keydown', (e) => { 
        if (e.key === 'Escape') hide(); 
      });
      el._bound = true;
    }
    return el;
  }

  /**
   * Render a complete, auditable view of ALL generation parameters.
   * - Assumes unified top-level token payload from serialize_token_for_wire()
   * - Renders both top-level and generation_meta keys
   * - Adds tooltips for key parameters
   * - Minimizes DOM work via a single DocumentFragment append
   * Runtime: Browser (ES2020+)
   */
  _renderGenerationDetails(container, fields) {
    // ---------- Setup ----------
    container.innerHTML = '';
    const frag = document.createDocumentFragment();

    // --- small, local helpers (no external deps) ---
    const tc = (s) => (typeof s === 'string'
      ? s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
      : s);

    const isEmpty = (v) =>
      v === null || v === undefined || v === '' ||
      (Array.isArray(v) && v.length === 0) ||
      (typeof v === 'object' && !Array.isArray(v) && Object.keys(v).length === 0);

    const num = (v, decimals = 2) => {
      if (v === null || v === undefined || v === '') return undefined;
      const n = Number(v);
      if (!Number.isFinite(n)) return String(v);
      return (Math.round(n) === n) ? String(n) : n.toFixed(decimals);
    };

    const joinList = (v) => {
      if (Array.isArray(v)) return v.join(', ');
      return v;
    };

    const addItem = (sectionFrag, label, value, {
      multiline = false,
      className = '',
      title = ''
    } = {}) => {
      if (isEmpty(value)) return;

      const dl = document.createElement('dl');
      dl.className = 'detail-item';
      if (multiline) dl.classList.add('detail-multiline');

      const dt = document.createElement('dt');
      dt.className = 'detail-label';
      dt.textContent = label;
      if (title) dt.title = title;

      const dd = document.createElement('dd');
      dd.className = 'detail-value detail-text';
      if (className) {
        for (const c of className.split(' ')) dd.classList.add(c);
      }
      // Strings only; ensure stable display for arrays/objects
      dd.textContent = (typeof value === 'string') ? value : String(value);
      if (title && !dt.title) dd.title = title;

      dl.appendChild(dt);
      dl.appendChild(dd);
      sectionFrag.appendChild(dl);
    };

    const addCopyableAddress = (sectionFrag, label, address) => {
      if (isEmpty(address)) return;
      const dl = document.createElement('dl');
      dl.className = 'detail-item';

      const dt = document.createElement('dt');
      dt.className = 'detail-label';
      dt.textContent = label;

      const dd = document.createElement('dd');
      dd.className = 'detail-value contract-full';
      dd.textContent = String(address);
      dd.title = 'Click to copy';
      dd.style.cursor = 'pointer';
      dd.onclick = () => navigator.clipboard?.writeText(String(address)).catch(() => {});

      dl.appendChild(dt);
      dl.appendChild(dd);
      sectionFrag.appendChild(dl);
    };

    const section = (title) => {
      const wrap = document.createElement('div');
      const h = document.createElement('div');
      wrap.className = 'detail-section';
      h.className = 'detail-section-title';
      h.textContent = title;
      wrap.appendChild(h);
      frag.appendChild(wrap);
      return wrap;
    };

    const withSection = (title, buildFn) => {
      const sec = section(title);
      const secFrag = document.createDocumentFragment();
      buildFn(secFrag);
      sec.appendChild(secFrag);
    };

    // Friendly mapping for SD negative prompt variants
    const NEGATIVE_PROMPT_VARIANT_MAP = {
      clean_glossy: 'Clean & Glossy',
      text_heavy: 'Text/Logo Allowed',
      degraded_retro: 'Retro Artifacts',
      disabled: 'Disabled'
    };

    // Friendly mapping for persona/style selection policy
    const PERSONA_STYLE_MODE_MAP = {
      balanced: 'Balanced',
      jitter: 'Jitter',
      random: 'Random'
    };

    // Field hints (tooltips) for key parameters
    const HINT = {
      'Temperature': 'Higher values increase randomness (exploration).',
      'Top P': 'Nucleus sampling; considers top cumulative probability mass.',
      'Presence Penalty': 'Discourage repeated tokens globally.',
      'Frequency Penalty': 'Penalize frequent tokens to improve diversity.',
      'Repeat Penalty': 'Model-specific repetition penalty (llama.cpp).',
      'CFG Scale': 'Stable Diffusion guidance scale: adherence to prompt.',
      'Steps': 'Number of inference steps for Stable Diffusion.',
      'Sampler': 'Diffusion scheduler used to sample noise trajectory.',
      'Seed (LLM)': 'Seed used by the LLM (separate from image seed).',
      'Seed': 'Seed used by Stable Diffusion image rendering.',
      'Seed (Meta)': 'Duplicate of top-level seed stored in generation_meta for provenance.',
      'LoRA': 'Whether LoRA adapters were used for this render.',
      'LoRA Scale': 'Cross-attention scale applied when LoRA is enabled.',
      'Negative Prompt Variant': 'Preset for negative prompt template selection.',
      'Trending Words (Shown)': 'Words actually inserted into this generation.',
      'Trending Words (All)': 'Broader pool considered by the template.',
      'Quality Mode': 'Prompt quality mode index/text and approximate weighting.',
      'Prompt Truncated': 'True if template components were truncated by limits.',
      'Persona Style Mode': 'How persona/style weighting was chosen for this generation (balanced/jitter/random).'	  
    };

    // ---------- Sections ----------
    // 1) Token identity / core
    withSection('Token', (sec) => {
      addItem(sec, 'Name', fields.name);
      addItem(sec, 'Ticker', fields.ticker ? `$${fields.ticker}` : undefined);
      addItem(sec, 'Class', fields.animal_class ? String(fields.animal_class).toUpperCase() : undefined);
      addItem(sec, 'ID', fields.id);
      addItem(sec, 'Image Filename', fields.image_filename);
      addItem(sec, 'Image Path', fields.image_path, { multiline: true });
      addCopyableAddress(sec, 'Contract', fields.contract_address);
      addItem(sec, 'Created', fields.created_at ? new Date(fields.created_at).toISOString() : '—');
    });

    // 2) Text Generation (LLM)
    withSection('Text Generation (LLM)', (sec) => {
      addItem(sec, 'LLM Model', fields.llm_model);
      addItem(sec, 'Temperature', num(fields.llm_temperature, 2), { title: HINT['Temperature'] });
      addItem(sec, 'Top P', num(fields.llm_top_p, 2), { title: HINT['Top P'] });
      addItem(sec, 'Presence Penalty', num(fields.llm_presence_penalty, 2), { title: HINT['Presence Penalty'] });
      addItem(sec, 'Frequency Penalty', num(fields.llm_frequency_penalty, 2), { title: HINT['Frequency Penalty'] });
      addItem(sec, 'Repeat Penalty', num(fields.llm_repeat_penalty, 2), { title: HINT['Repeat Penalty'] });
      addItem(sec, 'Max Tokens', fields.llm_max_tokens);
      addItem(sec, 'Seed (LLM)', fields.llm_seed, { title: HINT['Seed (LLM)'] });

      // LLM context / composition knobs
      addItem(sec, 'Template Key', fields.template_key);
      addItem(sec, 'Name Style Target', fields.name_style_target);
      addItem(sec, 'Description Style', fields.description_style);
      addItem(sec, 'Persona Index', fields.persona_index);
      addItem(sec, 'Persona Text', fields.persona_text, { multiline: true });
      addItem(sec, 'Persona Weight', num(fields.persona_weight, 3));
      addItem(sec, 'Style Weight', num(fields.style_weight, 3));
      addItem(sec, 'Trending Words Count', fields.trending_words_count);

      // Context prompts and word pools
      addItem(sec, 'User Prompt', fields.user_prompt, { multiline: true });
      addItem(sec, 'Trending Words (Shown)', joinList(fields.trending_words_shown), { multiline: true, title: HINT['Trending Words (Shown)'] });
      addItem(sec, 'Trending Words (All)', joinList(fields.trending_words_all), { multiline: true, title: HINT['Trending Words (All)'] });
    });

    // 3) Image Rendering (Stable Diffusion)
    withSection('Image Rendering', (sec) => {
      addItem(sec, 'Model', fields.model);
      addItem(sec, 'Sampler', fields.sampler, { title: HINT['Sampler'] });
      if (fields.width || fields.height) {
        addItem(sec, 'Dimensions', `${fields.width ?? '—'}×${fields.height ?? '—'}`);
      }
      addItem(sec, 'Steps', fields.steps, { title: HINT['Steps'] });
      addItem(sec, 'CFG Scale', num(fields.cfg_scale, 2), { title: HINT['CFG Scale'] });
      addItem(sec, 'Seed', fields.seed, { title: HINT['Seed'] });

	  // Prompts
	  addItem(sec, 'Prompt', fields.prompt, { multiline: true });
	  addItem(sec, 'Negative Prompt', fields.negative_prompt, { multiline: true });
	  // Also surface the base (pre-TI / pre-model policy) negative prompt
	  addItem(sec, 'Base Negative Prompt', fields.negative_prompt_base, { multiline: true });

	  // Correctly read top-level negative prompt variant + LoRA flags
	  const npv = fields.negative_prompt_variant;
      if (!isEmpty(npv)) {
        addItem(sec, 'Negative Prompt Variant',
          NEGATIVE_PROMPT_VARIANT_MAP[npv] || String(npv),
          { title: HINT['Negative Prompt Variant'] }
        );
      }

      const loraStatus = (fields.lora_disabled === true) ? 'Disabled' : 'Enabled';
      addItem(sec, 'LoRA', loraStatus, { title: HINT['LoRA'] });
      addItem(sec, 'LoRA ID', fields.lora_id);
      addItem(sec, 'LoRA Scale', num(fields.lora_scale, 2), { title: HINT['LoRA Scale'] });
    });

    // 4) Prompt Composition / Generation Meta
    const gm = (fields.generation_meta && typeof fields.generation_meta === 'object') ? fields.generation_meta : {};

    withSection('Prompt Composition', (sec) => {
      addItem(sec, 'Trigger', gm.trigger);
      addItem(sec, 'Breed', gm.breed);
      addItem(sec, 'Action', gm.action);
      addItem(sec, 'Environment', gm.environment);
      addItem(sec, 'Attribute', gm.attribute);
      addItem(sec, 'Colour', gm.colour);
      addItem(sec, 'Lighting', gm.lighting);
      addItem(sec, 'Camera', gm.camera);
      addItem(sec, 'Quality', gm.quality);
      addItem(sec, 'Medium Source', gm.medium_source);
      addItem(sec, 'Style Name', gm.style_name);
      addItem(sec, 'Style Modifiers', joinList(gm.style_modifiers), { multiline: true });
      addItem(sec, 'Artist Medium', gm.artist_medium);
      addItem(sec, 'Artist Name', gm.artist_name);
    });

    // 5) Quality & Randomization (meta-derived)
    withSection('Quality & Randomization', (sec) => {
      // Keep meta seed visible for provenance (even though it duplicates top-level seed)
      if (!isEmpty(gm.seed)) {
        addItem(sec, 'Seed (Meta)', gm.seed, { title: HINT['Seed (Meta)'] });
      }

      // Persona Style Mode (balanced/jitter/random)
      if (!isEmpty(gm.persona_style_mode)) {
        const psm = String(gm.persona_style_mode).toLowerCase();
        addItem(
          sec,
          'Persona Style Mode',
          PERSONA_STYLE_MODE_MAP[psm] || gm.persona_style_mode,
          { title: HINT['Persona Style Mode'] }
        );
      }
    });

    // 6) Truncation & Validation
    withSection('Truncation & Validation', (sec) => {
      const pt = fields.prompt_truncated;
      if (pt === true || pt === false) {
        addItem(sec, 'Prompt Truncated', pt ? 'Yes' : 'No', { title: HINT['Prompt Truncated'] });
      }
      // Prefer top-level, but fall back to generation_meta if needed
      const truncList = fields.truncated_components ?? gm.truncated_components ?? gm.element_drops;
      addItem(sec, 'Truncated Components', joinList(truncList), { multiline: true });
    });

    // 7) Other (top-level & meta) — catch-all for any new/unknown keys so nothing gets lost
    const shownTop = new Set([
      'id','name','ticker','description','contract_address','animal_class','image_filename','image_path','created_at',
      'cfg_scale','lora_scale','steps','seed','sampler','model','width','height','prompt','negative_prompt','negative_prompt_base', 
      'llm_model','llm_temperature','llm_top_p','llm_presence_penalty','llm_frequency_penalty','llm_repeat_penalty','llm_max_tokens','llm_seed',
      'trending_words_shown','trending_words_all','system_prompt','user_prompt','template_key','trending_words_count','name_style_target',
      'persona_text','persona_index','description_style','persona_weight','style_weight',
      'negative_prompt_variant','lora_disabled','prompt_truncated','truncated_components',
      'generation_meta','lora_id'
    ]);

    const otherTop = Object.entries(fields)
      .filter(([k, v]) => !shownTop.has(k) && !isEmpty(v))
      .map(([k, v]) => [tc(k), Array.isArray(v) ? v.join(', ') : (typeof v === 'object' ? JSON.stringify(v) : String(v))]);

    const shownMeta = new Set([
      'trigger','breed','action','environment','attribute','colour','lighting','camera','quality','composition',
      'medium_source','style_name','style_modifiers','artist_medium','artist_name',
      'quality_mode_text','quality_mode_weight','quality_mode_index','element_drops','seed'
    ]);

    const otherMeta = (gm && typeof gm === 'object')
      ? Object.entries(gm)
          .filter(([k, v]) => !shownMeta.has(k) && !isEmpty(v))
          .map(([k, v]) => [tc(k), Array.isArray(v) ? v.join(', ') : (typeof v === 'object' ? JSON.stringify(v) : String(v))])
      : [];

    if (otherTop.length || otherMeta.length) {
      withSection('Other Parameters', (sec) => {
        for (const [label, value] of otherTop) addItem(sec, label, value, { multiline: value.length > 80 });
        for (const [label, value] of otherMeta) addItem(sec, `Meta: ${label}`, value, { multiline: value.length > 80 });
      });
    }

    // ---------- Commit ----------
    container.appendChild(frag);
  }

  openDetailsModal(card, fields) {
    const modal = document.getElementById('token-details-modal');
    if (!modal) {
      console.error('Token details modal not found');
      return;
    }
    
    this.currentModalCard = card;
    
    const titleEl = modal.querySelector('.modal-title');
    if (titleEl) {
      titleEl.textContent = `Generation Details - ${fields.name} ($${fields.ticker})`;
    }
    
    const contentContainer = document.getElementById('modal-details-content');
    if (contentContainer) {
      this._renderGenerationDetails(contentContainer, fields);
    }
    
    const copyBtn = document.getElementById('copy-all-details');
    if (copyBtn) {
      copyBtn.onclick = () => this.copyAllDetails(fields);
    }
    
    modal.showModal();
    
    this.addTerminalLine(`ui: opened details for ${fields.name} (#${fields.id || 'N/A'})`);
  }
  
  _updateModalIfOpen(card) {
    const modal = document.getElementById('token-details-modal');
    if (modal && modal.open && this.currentModalCard === card) {
      const contentContainer = document.getElementById('modal-details-content');
      if (contentContainer && card._tokenFields) {
        this._renderGenerationDetails(contentContainer, card._tokenFields);
      }
    }
  }
  
  copyAllDetails(fields) {
    const details = this._formatDetailsForCopy(fields);
    navigator.clipboard.writeText(details).then(() => {
      this.addTerminalLine('ui: details copied to clipboard', 'info');
      const btn = document.getElementById('copy-all-details');
      if (btn) {
        const originalText = btn.textContent;
        btn.textContent = 'Copied!';
        setTimeout(() => { btn.textContent = originalText; }, 2000);
      }
    }).catch(err => {
      this.addTerminalLine('ui: failed to copy details', 'error');
    });
  }
  
	_setupDescriptionTooltip(descElement, descriptionText, tokenName, tokenTicker) {
		if (!descElement) return;
		
		// Check if mobile/touch device
		const isTouchDevice = ('ontouchstart' in window) || 
													(navigator.maxTouchPoints > 0) ||
													(navigator.msMaxTouchPoints > 0) ||
													(window.matchMedia("(pointer: coarse)").matches);
		
		// Disable tooltip entirely on mobile
		if (isTouchDevice) {
			descElement.style.cursor = 'default';
			descElement.classList.remove('has-overflow');
			
			// Check for overflow
			setTimeout(() => {
				if (descElement.scrollHeight > descElement.clientHeight + 1) {
					descElement.classList.add('has-overflow');
					// Add title attribute as mobile fallback
					descElement.title = 'Tap "Generation Details" to read full description';
				}
			}, 0);
			
			return; // Exit early, no tooltip setup
		}
     
     // Desktop tooltip code continues...
     const tooltip = this.globalTooltip;

     const computeOverflow = () => descElement.scrollHeight > (descElement.clientHeight + 1);

     const positionTooltip = () => {
       const rect = descElement.getBoundingClientRect();
       tooltip.style.display = 'block';
       const ttRect = tooltip.getBoundingClientRect();
       const spaceAbove = rect.top;
       const spaceBelow = window.innerHeight - rect.bottom;
       const placeBelow = spaceBelow >= Math.max(spaceAbove, 150);

       let top = placeBelow ? rect.bottom + 8 : rect.top - ttRect.height - 8;
       let left = rect.left;

       if (left + ttRect.width > window.innerWidth - 8) {
         left = window.innerWidth - ttRect.width - 8;
       }
       if (left < 8) left = 8;
       if (top < 8) top = 8;

       tooltip.style.top = `${top}px`;
       tooltip.style.left = `${left}px`;
     };

     const hasText = () => ((descriptionText || descElement.textContent || '').trim().length > 0);

     const buildTooltipContent = (normalizedText) => {
       tooltip.innerHTML = '';
       tooltip.dataset.hasHeader = 'true';

       const card = descElement.closest('.token-card');
       const cardImgEl = card ? card.querySelector('.token-image img') : null;
       const imgSrc = cardImgEl ? cardImgEl.src : '';

       const header = document.createElement('div');
       header.className = 'tt-header';

       let thumbEl;
       if (imgSrc) {
         thumbEl = document.createElement('img');
         thumbEl.className = 'tt-thumb';
         thumbEl.width = 64;
         thumbEl.height = 64;
         thumbEl.alt = (tokenName || tokenTicker) ? `${tokenName || ''} ${tokenTicker ? `($${tokenTicker})` : ''}`.trim() : 'Token image';
         thumbEl.src = imgSrc;
       } else {
         thumbEl = document.createElement('div');
         thumbEl.className = 'tt-thumb placeholder';
         thumbEl.setAttribute('aria-hidden', 'true');
         thumbEl.textContent = '—';
       }

       const titleBox = document.createElement('div');
       titleBox.className = 'tt-title';

       if (tokenName) {
         const nameEl = document.createElement('div');
         nameEl.className = 'tt-name';
         nameEl.textContent = tokenName;
         titleBox.appendChild(nameEl);
       }

       if (tokenTicker) {
         const tickEl = document.createElement('div');
         tickEl.className = 'tt-ticker';
         tickEl.textContent = `$${tokenTicker}`;
         titleBox.appendChild(tickEl);
       }

       header.appendChild(thumbEl);
       header.appendChild(titleBox);
       tooltip.appendChild(header);

       const body = document.createElement('div');
       body.className = 'tt-body';
       body.textContent = normalizedText;
       tooltip.appendChild(body);
     };

     const show = () => {
       if (!hasText()) return hide();

       descElement.classList.toggle('has-overflow', computeOverflow());

       if (!descElement.id) {
         descElement.id = `desc-${Math.random().toString(36).slice(2)}`;
       }

       const text = this._sanitizeDescription(
         (descriptionText || descElement.textContent || '').trim()
       );

       const normalizedText = (() => {
         const s = String(text || '')
           .replace(/\r\n/g, '\n')
           .replace(/[ \t]+\n/g, '\n')
           .replace(/\n[ \t]+/g, '\n')
           .trim();

         const paragraphs = s
           .split(/\n{2,}/)
           .map(p => p.replace(/\n+/g, ' ').replace(/[ \t]{2,}/g, ' ').trim())
           .filter(p => p.length > 0);
         return paragraphs.join('\n\n');
       })();

       buildTooltipContent(normalizedText);
       tooltip.dataset.show = 'true';
       tooltip.setAttribute('aria-hidden', 'false');
       descElement.setAttribute('aria-describedby', tooltip.id);
       positionTooltip();
      };

     const hide = () => {
       tooltip.dataset.show = 'false';
       tooltip.setAttribute('aria-hidden', 'true');
       tooltip.style.display = 'none';
       tooltip.dataset.hasHeader = 'false';
     };

     if (descElement._ttBound) {
       descElement.removeEventListener('mouseenter', descElement._ttBound.on);
       descElement.removeEventListener('mouseleave', descElement._ttBound.off);
       descElement.removeEventListener('focus', descElement._ttBound.on);
       descElement.removeEventListener('blur', descElement._ttBound.off);
     }

     const on = () => window.requestAnimationFrame(show);
     const off = hide;

     descElement.setAttribute('tabindex', '0');
     descElement.addEventListener('mouseenter', on);
     descElement.addEventListener('mouseleave', off);
     descElement.addEventListener('focus', on);
     descElement.addEventListener('blur', off);

     descElement._ttBound = { on, off };

     setTimeout(() => {
       if (computeOverflow()) {
         descElement.classList.add('has-overflow');
       } else {
         descElement.classList.remove('has-overflow');
       }
     }, 0);
   }


  _cleanupTooltipObservers(card) {
    const descP = card.querySelector('.token-description');
    if (descP) {
      if (descP._resizeObserver) {
        descP._resizeObserver.disconnect();
        delete descP._resizeObserver;
      }
      if (descP._ttBound) {
        descP.removeEventListener('mouseenter', descP._ttBound.on);
        descP.removeEventListener('mouseleave', descP._ttBound.off);
        descP.removeEventListener('focus', descP._ttBound.on);
        descP.removeEventListener('blur', descP._ttBound.off);
        delete descP._ttBound;
      }
    }
  }  
  
  _formatDetailsForCopy(fields) {
    let text = `Token: ${fields.name} ($${fields.ticker})\n`;
    text += `ID: #${fields.id || 'N/A'}\n`;
    text += `Contract: ${fields.contract_address || 'N/A'}\n`;
    text += `Created: ${fields.created_at || 'N/A'}\n\n`;
    
    if (fields.prompt) {
      text += `Prompt:\n${fields.prompt}\n\n`;
    }
    
    if (fields.negative_prompt) {
      text += `Negative Prompt:\n${fields.negative_prompt}\n\n`;
    }
    
    text += `Model: ${fields.model || 'N/A'}\n`;
    text += `Sampler: ${fields.sampler || 'N/A'}\n`;
    text += `Steps: ${fields.steps || 'N/A'}\n`;
    text += `CFG Scale: ${fields.cfg_scale || 'N/A'}\n`;
    text += `Seed: ${fields.seed || 'N/A'}\n`;
    
    return text;
  }

  initializePipelineState() {
    const lastStage = localStorage.getItem('lastPipelineStage');
    if (lastStage) {
      this.updatePipelineStatus(lastStage);
    }
  }

  _getTokenKey(token) {
    if (token.id !== undefined && token.id !== null) {
      return `id_${token.id}`;
    }
    if (token.contract_address) {
      return `contract_${token.contract_address}`;
    }
    const ticker = token.ticker || 'UNK';
    const name = token.name || 'UNKNOWN';
    const timestamp = token.created_at || new Date().toISOString();
    return `${ticker}_${name}_${timestamp}`;
  }

  rekeyCard(oldKey, newKey) {
    if (!oldKey || !newKey || oldKey === newKey) return;
    
    const existing = this.tokenStore.get(oldKey);
    const card = this.cardsByKey.get(oldKey);
    if (!existing || !card) return;
    
    this.tokenStore.delete(oldKey);
    this.cardsByKey.delete(oldKey);
    this.tokenStore.set(newKey, existing);
    this.cardsByKey.set(newKey, card);
    card.setAttribute('data-token-key', newKey);
  }

  computeKeyFromRaw(raw) {
    const fields = this._extractTokenFields(raw);
    return this._getTokenKey(fields);
  }

  upsertTokenCard(tokenData) {
    const fields = this._extractTokenFields(tokenData);
    const key = this._getTokenKey(fields);

    const existingData = this.tokenStore.get(key);
    const existingCard = this.cardsByKey.get(key);

    if (existingData && existingCard) {
      const merged = { ...existingData, ...fields };

      if (this._isDataEquivalent(existingData, merged)) {
        return existingCard;
      }

      this.tokenStore.set(key, merged);
      this._updateCardInDOM(existingCard, merged);

      console.log(`Updated token ${key}:`, { before: existingData, after: merged });
      return existingCard;
    } else {
      this.tokenStore.set(key, fields);

      if (this.tokenStore.size > 500) {
        const firstKey = this.tokenStore.keys().next().value;
        this.tokenStore.delete(firstKey);
        const oldCard = this.cardsByKey.get(firstKey);
        if (oldCard && oldCard.parentNode) oldCard.parentNode.removeChild(oldCard);
        this.cardsByKey.delete(firstKey);
      }

      const card = this._createCardInDOM(fields);
      card.setAttribute('data-token-key', key);
      this.cardsByKey.set(key, card);

      this.elements.tokenGrid.insertBefore(card, this.elements.tokenGrid.firstChild);
      
      const descEl = card.querySelector('.token-description');
      if (descEl && fields.description) {
        this._setupDescriptionTooltip(descEl, fields.description, fields.name, fields.ticker);
      }
      
      this._trimCards();
      return card;
    }
  }

  _isDataEquivalent(data1, data2) {
    const criticalFields = ['image_path', 'prompt', 'description', 'animal_class'];
    for (const field of criticalFields) {
      if (data1[field] !== data2[field]) return false;
    }
    return true;
  }

  _updateCardInDOM(card, fields) {
    const isPartial = this._isPartialToken(fields);
    if (!isPartial && card.classList.contains('partial')) {
      card.classList.remove('partial');
      card.removeAttribute('aria-busy');
      const warning = card.querySelector('.partial-warning');
      if (warning) warning.remove();
    }

    const imageDiv = card.querySelector('.token-image');
    if (imageDiv) {
      if (fields.width && fields.height) {
        imageDiv.style.aspectRatio = `${fields.width} / ${fields.height}`;
      }
      
      let imgSrc = '';
      if (fields.image_path) {
        if (fields.image_path.startsWith('/')) imgSrc = fields.image_path;
        else if (fields.image_path.includes('/images/')) imgSrc = fields.image_path;
        else imgSrc = `/images/memefactory/${fields.image_path}`;
      } else if (fields.image_filename) {
        imgSrc = `/images/memefactory/${fields.image_filename}`;
      }

      if (imgSrc) {
        imageDiv.classList.remove('processing');
        const existingImg = imageDiv.querySelector('img');
        if (existingImg) {
          const oldURL = new URL(existingImg.src, window.location.origin).href;
          const newURL = new URL(imgSrc, window.location.origin).href;
          if (oldURL !== newURL) {
            existingImg.src = imgSrc;
            existingImg.alt = `${fields.name} ($${fields.ticker}) image`;
          }
        } else {
          imageDiv.innerHTML = '';
          const img = document.createElement('img');
          img.src = imgSrc;
          img.alt = `${fields.name} ($${fields.ticker}) image`;
          img.loading = 'lazy';
          img.decoding = 'async';
          imageDiv.appendChild(img);
        }
      }
    }

    const nameEl = card.querySelector('.token-name');
    if (nameEl) nameEl.textContent = fields.name;

    const tickerEl = card.querySelector('.token-ticker');
    if (tickerEl) tickerEl.textContent = `$${fields.ticker}`;

    const idEl = card.querySelector('.token-id');
    if (fields.id && !idEl) {
      const header = card.querySelector('.token-header');
      if (header) {
        const newIdEl = document.createElement('span');
        newIdEl.className = 'token-id';
        newIdEl.textContent = `#${fields.id}`;
        newIdEl.style.fontSize = '0.8em';
        newIdEl.style.opacity = '0.6';
        newIdEl.style.marginLeft = '0.5em';
        header.appendChild(newIdEl);
      }
    } else if (idEl && fields.id) {
      idEl.textContent = `#${fields.id}`;
    }

    const descP = card.querySelector('.token-description');
    if (descP) {
      const currentScrollTop = descP.scrollTop;
      descP.textContent = fields.description || '';
      descP.scrollTop = currentScrollTop;
      this._setupDescriptionTooltip(descP, fields.description, fields.name, fields.ticker);
    }

    const addrDiv = card.querySelector('.token-address');
    if (addrDiv) {
      addrDiv.innerHTML = '';
      addrDiv.title = fields.contract_address || '';
      if (fields.contract_address) {
        const addr = String(fields.contract_address);
        addrDiv.appendChild(document.createTextNode(`${addr.slice(0, 6)}...${addr.slice(-4)}`));
        const copyBtn = document.createElement('button');
        copyBtn.className = 'copy-btn';
        copyBtn.type = 'button';
        copyBtn.textContent = '📋';
        copyBtn.title = 'Copy full address';
        copyBtn.onclick = () => navigator.clipboard?.writeText(addr).catch(() => {});
        addrDiv.appendChild(copyBtn);
      } else {
        addrDiv.textContent = '—';
      }
    }

    let classDiv = card.querySelector('.token-class-indicator');
    if (!classDiv) {
      const addrDivRef = card.querySelector('.token-address');
      if (addrDivRef && addrDivRef.parentNode) {
        classDiv = document.createElement('div');
        classDiv.className = 'token-class-indicator';
        addrDivRef.parentNode.insertBefore(classDiv, addrDivRef.nextSibling);
      }
    }
    if (classDiv) {
      classDiv.innerHTML = '';
      if (fields.animal_class) {
        const badge = document.createElement('span');
        badge.className = `class-badge class-${fields.animal_class.toLowerCase()}`;
        badge.textContent = fields.animal_class.toUpperCase();
        badge.title = `${fields.animal_class} token`;
        classDiv.appendChild(badge);
      } else {
        classDiv.remove();
      }
    }

    const tsEl = card.querySelector('.token-timestamp');
    if (tsEl) {
      const created = fields.created_at ? new Date(fields.created_at) : null;
      tsEl.textContent = created ? created.toLocaleString() : '—';
    }

    card._tokenFields = fields;
    
    this._updateModalIfOpen(card);

    if (fields.animal_class) {
      card.dataset.class = fields.animal_class.toLowerCase();
    }

    const prevMeta = card._tokenData && card._tokenData.generation_meta;
    const nextMetaObj = (fields.generation_meta !== undefined)
      ? fields.generation_meta
      : prevMeta;

    card._tokenData = Object.assign({}, card._tokenData, fields);
    card._tokenData.generation_meta = nextMetaObj;
    card._tokenId = (fields.id !== undefined) ? fields.id : card._tokenId;

    const hasMeta = !!(nextMetaObj && typeof nextMetaObj === 'object' && Object.keys(nextMetaObj).length);

    if (hasMeta) {
      card.setAttribute('data-has-metadata', 'true');
    } else {
      card.removeAttribute('data-has-metadata');
    }
  }

  _trimCards() {
    const maxCards = 50;
    while (this.elements.tokenGrid.children.length > maxCards) {
      const lastCard = this.elements.tokenGrid.lastChild;
      const key = lastCard.getAttribute('data-token-key');

      this._cleanupTooltipObservers(lastCard);

      if (key) {
        this.cardsByKey.delete(key);
      }
      this.elements.tokenGrid.removeChild(lastCard);
    }
  }

  setConnectionStatus(connected) {
    const container = document.querySelector('.connection-status');
    if (container) container.classList.toggle('connected', !!connected);

    if (connected) {
      this.elements.connectionDot.classList.add('connected');
      this.elements.connectionText.textContent = 'Connected';
      if (this.elements.systemStatus) {
        this.elements.systemStatus.textContent = 'ONLINE';
      }
    } else {
      this.elements.connectionDot.classList.remove('connected');
      this.elements.connectionText.textContent = 'Disconnected';
      if (this.elements.systemStatus) {
        this.elements.systemStatus.textContent = 'OFFLINE';
      }
    }
  }

  renderSystemMetrics(data) {
    if (!data) return;

    const resTotal = document.getElementById('res-total');
    const res24h = document.getElementById('res-24h');
    const resRatio = document.getElementById('res-ratio');
    const resTime = document.getElementById('res-avgtime');
    const resStatus = document.getElementById('res-status');

    if (data.cpu && resTotal) {
      const cpuPercent = data.cpu.usage_percent.toFixed(1);
      resTotal.textContent = `${cpuPercent}%`;

      if (data.cpu.usage_percent > 85) {
        resTotal.className = 'resource-value critical';
      } else if (data.cpu.usage_percent > 70) {
        resTotal.className = 'resource-value warning';
      } else if (data.cpu.usage_percent > 50) {
        resTotal.className = 'resource-value medium';
      } else {
        resTotal.className = 'resource-value good';
      }
    }

    if (data.mem && res24h) {
      const memPercent = data.mem.used_percent.toFixed(1);
      res24h.textContent = `${memPercent}%`;

      if (data.mem.used_percent > 85) {
        res24h.className = 'resource-value critical';
        res24h.title = 'Critical: No swap available!';
      } else if (data.mem.used_percent > 70) {
        res24h.className = 'resource-value warning';
        res24h.title = 'Warning: Memory pressure building';
      } else if (data.mem.used_percent > 50) {
        res24h.className = 'resource-value medium';
        res24h.title = 'Memory usage elevated';
      } else {
        res24h.className = 'resource-value good';
        res24h.title = `${(data.mem.available_bytes / (1024**3)).toFixed(1)}GB available`;
      }
    }

    if (data.mem && resRatio) {
      const usedGB = (data.mem.used_bytes / (1024 ** 3)).toFixed(1);
      const totalGB = (data.mem.total_bytes / (1024 ** 3)).toFixed(1);
      const availableGB = (data.mem.available_bytes / (1024 ** 3)).toFixed(1);

      resRatio.textContent = `${usedGB}/${totalGB}GB`;
      resRatio.title = `${availableGB}GB available • No swap`;
      resRatio.className = 'resource-value';
    }

    if (data.load && resTime) {
      const load1 = data.load.load_avg_1m;
      const load5 = data.load.load_avg_5m;
      const load15 = data.load.load_avg_15m;

      resTime.textContent = `${load1.toFixed(2)}/${load5.toFixed(2)}/${load15.toFixed(2)}`;
      resTime.title = '1min/5min/15min load averages (4 cores)';

      const loadPerCore = load1 / 4;
      if (loadPerCore > 0.85) {
        resTime.className = 'resource-value critical';
      } else if (loadPerCore > 0.70) {
        resTime.className = 'resource-value warning';
      } else if (loadPerCore > 0.50) {
        resTime.className = 'resource-value medium';
      } else {
        resTime.className = 'resource-value good';
      }
    }

    if (resStatus && data.uptime_seconds) {
      const totalSeconds = Math.floor(data.uptime_seconds);
      const days = Math.floor(totalSeconds / 86400);
      const hours = Math.floor((totalSeconds % 86400) / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);

      let uptimeStr;
      if (days > 0) uptimeStr = `${days}d ${hours}h ${minutes}m`;
      else if (hours > 0) uptimeStr = `${hours}h ${minutes}m`;
      else uptimeStr = `${minutes}m`;

      const cpuPercent = data.cpu ? data.cpu.usage_percent : 0;
      const memPercent = data.mem ? data.mem.used_percent : 0;
      const loadPerCore = data.load ? (data.load.load_avg_1m / 4) : 0;

      const maxStress = Math.max(cpuPercent, memPercent, loadPerCore * 100);

      if (maxStress > 85) {
        resStatus.className = 'resource-value critical';
        resStatus.textContent = `CRITICAL`;
        resStatus.title = `Uptime: ${uptimeStr} • System critical!`;
      } else if (maxStress > 70) {
        resStatus.className = 'resource-value warning';
        resStatus.textContent = `HIGH LOAD`;
        resStatus.title = `Uptime: ${uptimeStr} • System stressed`;
      } else if (maxStress > 50) {
        resStatus.className = 'resource-value medium';
        resStatus.textContent = `MODERATE`;
        resStatus.title = `Uptime: ${uptimeStr} • Elevated usage`;
      } else {
        resStatus.className = 'resource-value good';
        resStatus.textContent = `UP ${uptimeStr}`;
        resStatus.title = `System healthy • Xeon 8358 4C/16GB`;
      }
    } else if (resStatus) {
      resStatus.textContent = 'ONLINE';
      resStatus.className = 'resource-value good';
    }

    if (data.mem && data.mem.used_percent > 85) {
      const availableGB = (data.mem.available_bytes / (1024**3)).toFixed(1);
      this.addTerminalLine(`api: memory critical: ${availableGB}GB available (no swap configured)`, 'error');
    }
  }

  addTerminalLine(text, type = 'info') {
    const sourceMatch = text.match(/^(ws|ui|backend|api|metrics|op):\s*/);
    const source = sourceMatch ? sourceMatch[1].toUpperCase() : 'SYSTEM';
    const message = sourceMatch ? text.substring(sourceMatch[0].length) : text;
    
    const severityMap = {
      'info': 'INFO',
      'warning': 'WARN', 
      'error': 'ERROR',
      'success': 'INFO',
      'operator': 'OP',
	  'dreaming': 'DREAMING'
    };
    const severity = severityMap[type] || 'INFO';
    
    let finalType = type;
    // Do not override our special 'dreaming' type
    if (finalType !== 'dreaming') {
      if (source === 'OP' || message.includes('operator speaking')) {
        finalType = 'operator';
      } else if (type === 'success') {
        finalType = 'info';
      }
    }
    
    const line = document.createElement('div');
    line.className = `terminal-line terminal-${finalType}`;
    
    const ts = new Date().toLocaleTimeString('en-US', {
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit'
    });
    
    // Special rendering: DREAMING shows no SOURCE, always yellow
    if (finalType === 'dreaming') {
      // Exact format requested: "DREAMING:" (without "BACKEND")
      const dreamingText = `[${ts}] DREAMING: ${message}`;
      line.textContent = dreamingText;
      // Force yellow even if CSS lacks a rule
      line.style.color = '#FFD700';
      // keep class for future theming
      line.className = 'terminal-line terminal-dreaming';
    } else {
      const formattedText = `[${ts}] ${severity} ${source}: ${message}`;
      line.textContent = formattedText;
    }
    
    this.elements.terminal.appendChild(line);
    this.elements.terminal.scrollTop = this.elements.terminal.scrollHeight;
    
    while (this.elements.terminal.children.length > 200) {
      this.elements.terminal.removeChild(this.elements.terminal.firstChild);
    }
  }

	updatePipelineStatus(active) {
		const norm = (active || '').toLowerCase().trim();
		
		// Clear all active states
		document.querySelectorAll('.pipeline-cell').forEach(s => s.classList.remove('active')); 
		
		if (!norm || norm === 'idle' || norm === 'done') {
			console.log('Pipeline idle/done, clearing all highlights');
			return;
		}
		
		// Comprehensive mapping for all possible backend stage names
		const stageMap = {
			// Full names
			'fetch': 'fetch',
			'llm': 'llm',
			'prompt': 'prompt', 
			'render': 'render',
			'save': 'save',
			
			// Abbreviated names (2-letter codes shown in UI)
			'ft': 'fetch',
			'lm': 'llm',
			'pr': 'prompt',
			'im': 'render',  // "im" = image generation
			'sv': 'save',
			
			// Alternative names
			'image': 'render',
			'store': 'save',
			'generate': 'llm',
			'text': 'llm'
		};
		
		const mappedStage = stageMap[norm] || norm;
		const step = document.getElementById(`step-${mappedStage}`);
		
		if (step) {
			step.classList.add('active');
			console.log(`Pipeline stage activated: ${norm} -> ${mappedStage}`);
		} else {
			console.warn(`Unknown pipeline stage: ${norm}, tried to find: step-${mappedStage}`);
		}
	}

  renderMetrics(metrics) {
    if (!metrics) return;

    if (metrics.tokens_generated !== undefined) {
      this.elements.tokenCount.textContent = metrics.tokens_generated;
    }
    
    if (metrics.gen_rate_per_24h !== undefined) {
      this.elements.tokensToday.textContent = metrics.gen_rate_per_24h;
    }
    
    if (metrics.cat_dog_ratio) {
      const parts = String(metrics.cat_dog_ratio).split(' / ');
      const catPercent = Number.parseInt(parts[0].replace('%', ''), 10);
      if (Number.isFinite(catPercent)) {
        const dogPercent = Math.max(0, Math.min(100, 100 - catPercent));
        const catPctEl = document.getElementById('cat-percent');
        const dogPctEl = document.getElementById('dog-percent');
        const catBar = document.getElementById('cat-bar');
        const dogBar = document.getElementById('dog-bar');

        if (catPctEl) catPctEl.textContent = `${catPercent}%`;
        if (dogPctEl) dogPctEl.textContent = `${dogPercent}%`;
        if (catBar) {
          catBar.style.width = `${catPercent}%`;
        }
      }
    }
    
    if (metrics.avg_gen_time !== undefined && metrics.avg_gen_time !== null) {
      const timeStr = `${Number(metrics.avg_gen_time).toFixed(1)}s`;
      this.elements.avgTime.textContent = timeStr;
    }
  }

  _extractTokenFields(data) {
    // Backend always sends flattened structure, no schema versions
    return {
      id: data.id,
      name: data.name || 'UNKNOWN',
      ticker: data.ticker || 'UNK',
      description: data.description || '',
      contract_address: data.contract_address || '',
      animal_class: (data.animal_class || '').toLowerCase(),
      image_path: data.image_path,
      image_filename: data.image_filename,
      created_at: data.created_at || new Date().toISOString(),
      prompt: data.prompt,
      negative_prompt: data.negative_prompt,
      lora_id: data.lora_id,
      lora_scale: data.lora_scale,
      cfg_scale: data.cfg_scale,
      steps: data.steps,
      seed: data.seed,
      sampler: data.sampler,
      model: data.model,
      width: data.width,
      height: data.height,
      llm_model: data.llm_model,
      llm_temperature: data.llm_temperature,
      llm_top_p: data.llm_top_p,
      llm_presence_penalty: data.llm_presence_penalty,
      llm_frequency_penalty: data.llm_frequency_penalty,
      llm_repeat_penalty: data.llm_repeat_penalty,
      llm_max_tokens: data.llm_max_tokens,
      llm_seed: data.llm_seed,
      generation_meta: data.generation_meta || null,
      // Backend context fields
      trending_words_shown: data.trending_words_shown,
      trending_words_all: data.trending_words_all,
      user_prompt: data.user_prompt,
      template_key: data.template_key,
      trending_words_count: data.trending_words_count,
      name_style_target: data.name_style_target,
      persona_text: data.persona_text,
      persona_index: data.persona_index,
      description_style: data.description_style,
      persona_weight: data.persona_weight,
      style_weight: data.style_weight,
      negative_prompt_variant: data.negative_prompt_variant,
      lora_disabled: data.lora_disabled,
      prompt_truncated: data.prompt_truncated,
      truncated_components: data.truncated_components
    };
  }

  _isPartialToken(fields) {
    // Check for partial token (missing id or prompt)
    return fields.id === undefined || fields.id === null ||
           fields.prompt === undefined || fields.prompt === null;
  }

  _createCardInDOM(fields) {
    const isPartial = this._isPartialToken(fields);

    if (isPartial) {
      console.warn('Partial token detected:', {
        hasId: fields.id !== undefined && fields.id !== null,
        hasPrompt: fields.prompt !== undefined && fields.prompt !== null,
        ticker: fields.ticker
      });
    }

    const card = document.createElement('div');
    card.className = 'token-card';
    if (isPartial) {
      card.classList.add('partial');
      card.setAttribute('aria-busy', 'true');
    }

    const tokenClass = fields.animal_class;
    card.dataset.class = (tokenClass === 'dog' || tokenClass === 'cat') ? tokenClass : 'unknown';

    let imgSrc = '';
    if (fields.image_path) {
      if (fields.image_path.startsWith('/')) imgSrc = fields.image_path;
      else if (fields.image_path.includes('/images/')) imgSrc = fields.image_path;
      else imgSrc = `/images/memefactory/${fields.image_path}`;
    } else if (fields.image_filename) {
      imgSrc = `/images/memefactory/${fields.image_filename}`;
    }

    const imageDiv = document.createElement('div');
    imageDiv.className = `token-image ${imgSrc ? '' : 'processing'}`;
    imageDiv.setAttribute('aria-label', `${tokenClass} image`);
    
    if (fields.width && fields.height) {
      imageDiv.style.aspectRatio = `${fields.width} / ${fields.height}`;
    }
   
    if (imgSrc) {
      const img = document.createElement('img');
      img.src = imgSrc;
      img.alt = `${fields.name} ($${fields.ticker}) image`;
      img.loading = 'lazy';
      img.decoding = 'async';
      imageDiv.appendChild(img);
    } else {
      const noise = document.createElement('div');
      noise.className = 'noise-overlay';
      imageDiv.appendChild(noise);

      const cls = document.createElement('span');
      cls.className = 'token-class';
      cls.textContent = tokenClass;
      imageDiv.appendChild(cls);

      const synth = document.createElement('span');
      synth.style.color = '#333';
      synth.style.fontSize = '14px';
      synth.textContent = 'SYNTHESIZING...';
      imageDiv.appendChild(synth);
    }

    const infoDiv = document.createElement('div');
    infoDiv.className = 'token-info';

    const header = document.createElement('div');
    header.className = 'token-header';

    const nameEl = document.createElement('span');
    nameEl.className = 'token-name';
    nameEl.textContent = fields.name;

    const tickerEl = document.createElement('span');
    tickerEl.className = 'token-ticker';
    tickerEl.textContent = `$${fields.ticker}`;

    header.appendChild(nameEl);
    header.appendChild(tickerEl);

    if (fields.id) {
      const idEl = document.createElement('span');
      idEl.className = 'token-id';
      idEl.textContent = `#${fields.id}`;
      idEl.style.fontSize = '0.8em';
      idEl.style.opacity = '0.6';
      idEl.style.marginLeft = '0.5em';
      header.appendChild(idEl);
    }

    const descP = document.createElement('p');
    descP.className = 'token-description';
    descP.textContent = fields.description;

    const addrDiv = document.createElement('div');
    addrDiv.className = 'token-address';
    addrDiv.title = fields.contract_address || '';

    if (fields.contract_address) {
      const addr = String(fields.contract_address);
      addrDiv.textContent = `${addr.slice(0, 6)}...${addr.slice(-4)}`;

      const copyBtn = document.createElement('button');
      copyBtn.className = 'copy-btn';
      copyBtn.textContent = '📋';
      copyBtn.title = 'Copy full address';
      copyBtn.type = 'button';
      copyBtn.onclick = () => navigator.clipboard?.writeText(addr).catch(() => {});
      addrDiv.appendChild(copyBtn);
    } else {
      addrDiv.textContent = '—';
    }

    const classDiv = document.createElement('div');
    classDiv.className = 'token-class-indicator';
    if (fields.animal_class) {
      const badge = document.createElement('span');
      badge.className = `class-badge class-${fields.animal_class.toLowerCase()}`;
      badge.textContent = fields.animal_class.toUpperCase();
      badge.title = `${fields.animal_class} token`;
      classDiv.appendChild(badge);
    }

    const metaBox = document.createElement('div');
    metaBox.className = 'token-metadata';

    const ts = document.createElement('span');
    ts.className = 'token-timestamp';
    const timestamp = fields.created_at ? new Date(fields.created_at) : new Date();
    ts.textContent = timestamp.toLocaleString();
    metaBox.appendChild(ts);

    if (isPartial) {
      const warning = document.createElement('div');
      warning.className = 'partial-warning';
      warning.style.cssText = 'color: #ff6b35; font-size: 0.9em; margin-top: 0.5em; font-style: italic;';
      warning.textContent = '⚠ Some details unavailable in live view. Will appear after snapshot.';
      metaBox.appendChild(warning);
    }

    const detailsBtn = document.createElement('button');
    detailsBtn.className = 'token-details-btn';
    detailsBtn.type = 'button';
    detailsBtn.textContent = 'Generation Details';
    detailsBtn.setAttribute('aria-label', `View generation details for ${fields.name}`);
    detailsBtn.setAttribute('data-token-id', fields.id || '');
    
    card._tokenFields = fields;
    
    detailsBtn.addEventListener('click', () => {
      this.openDetailsModal(card, fields);
    });

    infoDiv.appendChild(header);
    infoDiv.appendChild(descP);
    infoDiv.appendChild(addrDiv);
    if (classDiv.children.length > 0) infoDiv.appendChild(classDiv);
    infoDiv.appendChild(metaBox);
    infoDiv.appendChild(detailsBtn);

    card.appendChild(imageDiv);
    card.appendChild(infoDiv);

    card._tokenData = fields;
    card._tokenId = fields.id;

    const hasCreateMeta = !!(fields.generation_meta && Object.keys(fields.generation_meta).length);
    if (hasCreateMeta) {
      card.setAttribute('data-has-metadata', 'true');
    } else {
      card.removeAttribute('data-has-metadata');
    }

    return card;
  }

  getTokenStats() {
    return {
      totalStored: this.tokenStore.size,
      cardsDisplayed: this.cardsByKey.size,
      domCount: this.elements.tokenGrid.children.length
    };
  }

  renderWordPool(words) {
    this.elements.wordPool.innerHTML = '';
    const wordsArray = Array.isArray(words) ? words : (words.words || []);
    
    wordsArray.slice(0, 9).forEach((word, i) => {
      const el = document.createElement('div');
      el.className = 'word';
      el.style.animationDelay = `${i}s`;
      el.textContent = typeof word === 'string' ? word : word.word || '';
      this.elements.wordPool.appendChild(el);
    });
  }

  hideLoading() {
    if (this.elements.loading) {
      this.elements.loading.style.display = 'none';
    }
  }

  setApiClient(apiClient) {
    this.apiClient = apiClient;
  }

  initBinaryStream() {
    const container = document.getElementById('binary-stream');
    if (!container) {
      console.warn('Binary stream container not found - feature disabled');
      return false;
    }
    
    this._updateBinaryStream();
    
    this.startBinaryStream();
				return true;
  }
  
  _generateBinaryString(length = 32) {
    let result = '';
    for (let i = 0; i < length; i++) {
      result += Math.random() < 0.5 ? '0' : '1';
    }
    return result;
  }
  
  _updateBinaryStream() {
    const container = document.getElementById('binary-stream');
    if (!container) return;
    
    const binary = this._generateBinaryString(32);
    
    const html = binary.split('').map(bit => 
      bit === '1' ? `<span class="bit-1">${bit}</span>` : bit
    ).join('');
    
    container.innerHTML = `[${html}]`;
  }
  
  startBinaryStream() {
    if (this.binaryStreamInterval) return;
    
    this.binaryStreamActive = true;
    const container = document.getElementById('binary-stream');
    if (container) container.classList.add('active');
    
    this.binaryStreamInterval = setInterval(() => {
      this._updateBinaryStream();
    }, this.binaryStreamSpeed);
  }
  
  stopBinaryStream() {
    if (this.binaryStreamInterval) {
      clearInterval(this.binaryStreamInterval);
      this.binaryStreamInterval = null;
    }
    
    this.binaryStreamActive = false;
    const container = document.getElementById('binary-stream');
    if (container) container.classList.remove('active');
  }
  
  setBinaryStreamSpeed(speed) {
    this.binaryStreamSpeed = Math.max(50, Math.min(2000, speed));
    
    if (this.binaryStreamActive) {
      this.stopBinaryStream();
      this.startBinaryStream();
    }
  }
}