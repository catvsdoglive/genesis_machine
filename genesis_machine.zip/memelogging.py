# memelogging.py
"""
Logging configuration for Meme Factory using Loguru.

This module relies on config.py to load and validate environment variables
exactly once (via the _MEMEFACTORY_ENV_LOADED flag). No local dotenv handling.

Python: 3.12
"""

import sys
from pathlib import Path
from loguru import logger
from config import LOG_PATH  # ensures .env is already loaded & validated

# Ensure log directory exists
log_path = Path(LOG_PATH)
log_path.mkdir(parents=True, exist_ok=True)

# Remove default handlers
logger.remove()

# All-level rotating file with full backtrace & context
logger.add(
    str(log_path / "memefactory.log"),
    rotation="10 MB",
    retention="30 days",
    level="DEBUG",
    backtrace=True,
    diagnose=True,
    enqueue=True,
    format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level} | {module}:{function}:{line} - {message}",
)

# Errors-only rotating file
logger.add(
    str(log_path / "memefactory.error.log"),
    rotation="10 MB",
    retention="30 days",
    level="ERROR",
    backtrace=True,
    diagnose=True,
    enqueue=True,
    format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level} | {module}:{function}:{line} - {message}",
)

# Also send ERRORs to stderr so you see them live
logger.add(
    sys.stderr,
    level="ERROR",
    format="{time:HH:mm:ss.SSS} | {level} | {module}:{function}:{line} - {message}",
)
