# camera.py
"""
Camera Module for Stable Diffusion 1.5 Prompt Generation (Optimized)

Compressed camera specifications using SD1.5 tag format.
All technical descriptions reduced to essential keywords.

Position in prompt: Combined with LIGHTING
Token budget: 2-4 tokens per camera specification
"""

from __future__ import annotations
from typing import Final

__all__ = ["CAMERA"]

CAMERA: Final[list[str]] = [
    # Extreme Close-ups
    "extreme macro eyes",
    "ultra closeup nose",
    "whisker macro shot",
    "macro lens fur",
    "extreme closeup eye",
    "macro paw pad",
    "super macro ear",
    "microscopic fur strand",
    "extreme closeup nose",
    "macro tongue texture",
    
    # Portrait Distances  
    "tight headshot",
    "medium closeup chest",
    "medium shot waist",
    "american shot knees",
    "bust shot shoulders",
    "choker closeup neck",
    "medium long three-quarter",
    "head shoulders portrait",
    "two-shot framing",
    "over-shoulder shot",
    
    # Full Body
    "full body standing",
    "full figure action",
    "wide establishing",
    "full body profile",
    "full length portrait",
    "head toe shot",
    "complete figure",
    "environmental full",
    "full silhouette",
    "figure study full",
    
    # Cinematic Distances
    "cowboy shot hip",
    "italian shot knee",
    "extreme wide landscape",
    "master shot full",
    "establishing wide",
    "ultra wide environmental",
    "epic wide tiny",
    "aerial establishing",
    "helicopter above",
    "crane high angle",
    
    # Technical Camera Lenses (focal lengths and apertures)
    "85mm portrait f1.4",
    "35mm standard wide",
    "200mm telephoto compression",
    "14mm ultrawide distortion",
    "50mm standard f1.8",
    "24mm wide angle",
    "135mm telephoto portrait",
    "300mm super telephoto",
    "600mm wildlife telephoto",
    "8mm fisheye lens",
    "16-35mm zoom",
    "24-70mm versatile",
    "70-200mm telephoto",
    "100mm macro 1:1",
    "90mm tilt-shift",
    "58mm noct f0.95",
    "40mm pancake lens",
    "28mm classic wide",
    "105mm portrait telephoto",
    
    # Camera Angles (pure positioning)
    "low angle hero",
    "high angle down",
    "dutch angle tilted",
    "worms eye view",
    "birds eye view",
    "eye level straight",
    "hip level medium",
    "ground level perspective",
    "overhead top-down",
    "45 degree angle",
    "profile side view",
    "three-quarter angle",
    "frontal facing",
    "back view behind",
    "diagonal composition",
    "canted angle",
    "oblique angle",
    "perpendicular view",
    "parallel view",
    
    # Camera Movements
    "tracking shot",
    "dolly push",
    "dolly pull",
    "pan left",
    "pan right",
    "tilt up",
    "tilt down",
    "zoom in",
    "zoom out",
    "handheld shake",
    "steadicam smooth",
    "gimbal stabilized",
    "slider lateral",
    "jib arm",
    "cable cam",
    
    # Lens Effects (technical)
    "tilt-shift miniature",
    "split diopter dual",
    "lensbaby selective",
    "anamorphic flares",
    "oval bokeh",
    "swirly bokeh",
    "petzval swirl",
    "mirror lens donuts",
    
    # Depth of Field (technical settings)
    "shallow dof f1.2",
    "deep dof f16",
    "bokeh balls blur",
    "selective focus",
    "hyperfocal sharp",
    "focus stacking",
    "zone focusing",
    "split focus",
    "soft focus",
    "critical focus",
    "front focus",
    "back focus",
    "follow focus",
    
    # Shutter Speed Effects
    "freeze 1/8000",
    "motion blur 1/15",
    "panning blur",
    "long exposure",
    "high speed capture",
    "slow shutter",
    "rear curtain",
    "front curtain",
    "bulb exposure",
    
    # Professional Camera Setups
    "studio camera",
    "tripod mounted",
    "handheld documentary",
    "shoulder rig",
    "crane mounted",
    "drone aerial",
    "underwater housing",
    "remote trap",
    
    # Framing Techniques
    "rule thirds",
    "golden ratio",
    "centered composition",
    "off-center framing",
    "negative space",
    "tight framing",
    "loose framing",
    "symmetrical framing",
    "asymmetrical balance",
    
    # Perspective Control
    "one-point perspective",
    "two-point perspective",
    "three-point perspective",
    "forced perspective",
    "perspective correction",
    "keystone correction",
    "barrel distortion",
    "pincushion distortion",
    "rectilinear projection",
    
    # Aspect Ratios
    "16:9 widescreen",
    "21:9 ultrawide",
    "4:3 standard",
    "1:1 square",
    "2.39:1 cinemascope",
    "1.85:1 theatrical",
    "9:16 vertical",
    "3:2 photo",
    "5:4 large format",
    
    # Focus Techniques
    "center point focus",
    "face detection",
    "eye detection",
    "continuous autofocus",
    "single point",
    "zone focus",
    "manual focus",
    "back button",
    "focus peaking",
    
    # Camera Height
    "ground level",
    "knee height",
    "waist level",
    "chest height",
    "eye level",
    "overhead high",
    "ceiling mounted",
    "elevated platform",
    
    # Multi-Camera
    "single camera",
    "multi-camera coverage",
    "a-camera main",
    "b-camera alternate",
    "c-camera cutaway",
    "roaming camera",
    
    # Technical Specifications
    "full frame",
    "crop sensor",
    "medium format",
    "large format",
    "micro four thirds",
    "super 35",
    "65mm format",
    "imax 70mm",
    
    # Specialized Mounts
    "monopod support",
    "slider rail",
    "car mount",
    "helmet pov",
    "chest pov",
    "suction mount",
    "clamp mount",
]