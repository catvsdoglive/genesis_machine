# colour.py
"""
Colour Module for Stable Diffusion 1.5 Prompt Generation (Optimized)

Compressed colour descriptors using SD1.5 tag format.
Simplified to essential colour keywords.

Position in prompt: Flexible, often with style or attributes
Token budget: 1-2 tokens per colour
"""

from __future__ import annotations
from typing import Final

__all__ = ["COLOURS"]

COLOURS: Final[list[str]] = [
    # REDS
    "crimson", "scarlet", "blood red", "cherry red",
    "wine red", "ruby", "brick red", "rose red",
    "vermillion", "cardinal", "burgundy", "maroon",
    
    # ORANGES  
    "bright orange", "burnt orange", "tangerine", "peach",
    "amber", "rust", "coral", "sunset orange",
    "copper", "pumpkin", "apricot", "terracotta",
    
    # YELLOWS
    "golden", "lemon", "butter yellow", "canary",
    "honey", "mustard", "cream", "sunflower",
    "banana", "corn yellow", "blonde", "straw",
    
    # GREENS
    "emerald", "lime", "forest green", "mint",
    "olive", "sage", "jade", "neon green",
    "grass green", "pine", "seafoam", "moss",
    "hunter green", "kelly green", "spring green", "jungle green",
    
    # BLUES
    "navy", "royal blue", "sky blue", "cobalt",
    "electric blue", "powder blue", "ocean blue", "midnight blue",
    "sapphire", "steel blue", "baby blue", "cornflower",
    "prussian blue", "cerulean", "azure", "denim",
    
    # PURPLES
    "violet", "lavender", "plum", "grape",
    "orchid", "amethyst", "royal purple", "iris",
    "eggplant", "lilac", "mauve", "wisteria",
    
    # TEALS/CYANS
    "teal", "turquoise", "cyan", "aqua",
    "peacock", "arctic blue", "robin egg", "aquamarine",
    
    # PINKS
    "hot pink", "rose", "blush", "bubblegum",
    "flamingo", "carnation", "coral pink", "salmon",
    "magenta", "fuchsia", "candy pink", "ballet pink",
    
    # BROWNS
    "chocolate", "coffee", "caramel", "chestnut",
    "cinnamon", "bronze", "cocoa", "hazelnut",
    "mahogany", "walnut", "sienna", "umber",
    
    # GRAYS
    "silver", "charcoal", "slate", "ash",
    "smoke", "stone gray", "graphite", "platinum",
    "pewter", "steel gray", "concrete", "gunmetal",
    
    # BLACK/WHITE
    "pure black", "jet black", "pitch black", "carbon black",
    "pure white", "snow white", "ivory", "pearl white",
    "cream white", "bone white", "chalk white", "milk white",
    
    # METALLICS
    "gold metallic", "silver metallic", "bronze metallic", "copper metallic",
    "brass metallic", "chrome", "platinum metallic", "pewter metallic",
    "rose gold", "gunmetal metallic", "titanium", "iron metallic",
    
    # NEONS
    "neon pink", "neon green", "neon blue", "neon yellow",
    "neon orange", "neon purple", "neon red", "neon cyan",
    
    # PASTELS
    "pastel pink", "pastel blue", "pastel yellow", "pastel green",
    "pastel purple", "pastel orange", "pastel peach", "pastel mint",
    "pastel lavender", "pastel coral", "pastel sage", "pastel cream",
    
    # EARTH TONES
    "earth brown", "sand beige", "clay red", "stone gray",
    "moss green", "mud brown", "dust", "desert tan",
    "terracotta", "ochre", "sienna", "umber",
    
    # JEWEL TONES
    "emerald", "sapphire", "ruby", "amethyst",
    "topaz", "garnet", "pearl", "opal",
    "jade", "turquoise", "citrine", "onyx",
    
    # GRADIENTS (simplified)
    "sunset gradient", "sunrise gradient", "ocean gradient", "forest gradient",
    "fire gradient", "ice gradient", "rainbow gradient", "twilight gradient",
    "aurora gradient", "desert gradient", "storm gradient", "cosmic gradient",
    
    # COLOR SCHEMES
    "warm colors", "cool colors", "monochrome", "complementary",
    "analogous", "triadic", "split complementary", "muted",
    "vibrant", "saturated", "desaturated", "high contrast",
    
    # SPECIAL EFFECTS
    "holographic", "iridescent", "pearlescent", "opalescent",
    "prismatic", "chromatic", "fluorescent", "phosphorescent",
    "glowing", "luminous", "reflective", "translucent",
    
    # VINTAGE/RETRO
    "sepia", "vintage fade", "retro colors", "faded",
    "film colors", "polaroid", "kodachrome", "technicolor",
    
    # NATURE INSPIRED
    "autumn colors", "spring colors", "summer colors", "winter colors",
    "sunset colors", "sunrise colors", "ocean colors", "forest colors",
    "sky colors", "fire colors", "ice colors", "earth colors",
]